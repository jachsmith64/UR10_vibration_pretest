"""
一键 XY 微动闭环能力测试（micro_closed_loop）。

目的：判断 UR10 CB3 在视觉反馈下能否通过反复小幅纠偏逼近 5 / 20 / 50 μm，
以及是否因最小有效运动尺度形成持续极限环。

要回答的不是"最终误差是多少"，而是三件事：
1. 完整迭代序列长什么样（例如 0 → +13 → −2 → +12 → −1 → +14 …）；
2. 每个真实命令 ↔ 真实视觉响应的对应关系（据此可反推 2/3/5/8/10 μm 命令实际走多少）；
3. 达不到目标时，卡住的是"控制器忽略了命令"还是"机械柔性吸收掉了"。

本模块与既有实验的关系：
- 复用 robot.py 的 MoveL 微动链路（URRobot / Waypoint / validate_trajectory），
  不切换到 servoj / RTDE 高速伺服，也不改动 robot.py 本身；
- 复用 camera.py 已经过预实验验证的棋盘格亚像素链路（CheckerboardTracker.process），
  不重新设计识别算法；
- **不复用 batch_camera_worker**：那套把编解码器写死为 BATCH_VIDEO_CODEC。

录制格式：**未压缩 RAW**。原因是 OpenCV 的 VideoWriter_fourcc('FFV1') 写 Mono8 时
会经 swscale 转成 YUV420P（色度抽样 + 有限范围 16–235），并非位精确；而本实验要的
分辨率是 3 μm ≈ 0.044 px，这种系统性量化是实打实的损失，抽检帧比对也查不出来。
未压缩 RAW 位精确、不依赖编解码器行为。编码在这里本来也不受实时约束——采集先把帧
缓冲进内存，落盘发生在片段结束之后——所以 RAW 的唯一代价（体积）由"用后即删"吸收。

为什么采集要先缓冲进内存：实测全幅 1936×1464 实时写盘每帧均值 2.27 ms、峰值 7.38 ms，
而相机周期是 7.56 ms，会丢掉 6.11% 的帧。memcpy 进内存只需约 0.3 ms，余量 25 倍。
识别与录制**完全串行**：片段关闭之后，父进程才逐帧跑棋盘格，识别再慢也挤不掉采集。

**本模块有意绕过手电筒门禁**：batch_camera_worker 的 _FlashGate 会硬抛
"手电筒门禁未完成"。微动闭环不需要那套门禁（它依赖操作者打手电筒，而本实验的
时间对齐由全机共享的 perf_counter_ns 保证），所以新相机进程不构造 _FlashGate。
这是有意的设计决定，不是安全回归——若将来有人要给本模式加回门禁，请连同这段说明一起改。
"""

from __future__ import annotations

import csv
import gc
import json
import math
import os
import shutil
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from queue import Empty
from typing import Any, Callable, Iterator, Sequence

import numpy as np

import config


# =============================================================================
# 0. 常量
# =============================================================================

AXIS_INDEX: dict[str, int] = {"X": 0, "Y": 1}
AXES: tuple[str, ...] = ("X", "Y")
AMPLITUDES_UM: tuple[int, ...] = (5, 20, 50)
DIRECTIONS: tuple[int, ...] = (1, -1)

# 迭代终止状态。前面 8 个是"已结束"，STILL_SHRINKING 表示"还没结束，继续迭代"。
TERMINAL_CONVERGED = "CONVERGED"
TERMINAL_CONVERGED_NOISE_LIMITED = "CONVERGED_NOISE_LIMITED"
TERMINAL_LIMIT_CYCLE = "LIMIT_CYCLE"
TERMINAL_STALLED = "STALLED_MIN_EFFECTIVE_MOTION"
TERMINAL_DIVERGING = "DIVERGING"
TERMINAL_MAX_ITER = "MAX_ITER"
TERMINAL_MEASUREMENT_LOST = "MEASUREMENT_LOST"
TERMINAL_ABORTED = "ABORTED"
TERMINAL_STILL_SHRINKING = "STILL_SHRINKING"

# 单次迭代的执行结果（与终止状态是两回事：一个目标可以有很多次 NO_MOTION 迭代）。
STEP_VALID = "VALID"
STEP_NO_MOTION = "NO_MOTION_BELOW_RESOLUTION"
STEP_MEASUREMENT_LOST = "MEASUREMENT_LOST"
STEP_INVALID_JUMP = "INVALID_JUMP"
STEP_SMALL = "INVALID_SMALL"
STEP_LARGE = "INVALID_LARGE"
STEP_SIGN = "INVALID_SIGN"
STEP_TIMEOUT = "INVALID_TIMEOUT"

ITERATION_COLUMNS: tuple[str, ...] = (
    "iteration_id",
    "axis",
    "direction",
    "target_amplitude_um",
    "target_um",
    "measured_position_um",
    "error_before_um",
    "command_um",
    "achieved_robot_um",
    "actual_visual_displacement_um",
    "error_after_um",
    "robot_tcp_before",
    "robot_tcp_after",
    "transverse_um",
    "g_obs",
    "n_valid_frames",
    "n_tail_frames",
    "sigma_tail_um",
    "timestamp",
    "step_status",
    "termination_state",
    "note",
)

FRAME_COLUMNS: tuple[str, ...] = (
    "iteration_id",
    "frame_index",
    "frame_id",
    "host_ns",
    "t_rel_s",
    "camera_timestamp_raw",
    "checker_dx_mm",
    "checker_dy_mm",
    "checker_is_valid",
    "accepted",
    "checker_quality",
    "checker_residual_px",
    "checker_angle_deg",
    "checker_scale",
    "checker_found_by",
    "in_tail_window",
)

STATIC_FRAME_COLUMNS: tuple[str, ...] = (
    "frame_index",
    "frame_id",
    "host_ns",
    "t_rel_s",
    "camera_timestamp_raw",
    "checker_dx_mm",
    "checker_dy_mm",
    "checker_is_valid",
    "accepted",
    "checker_quality",
    "checker_residual_px",
    "checker_found_by",
)

# 相机进程自己的逐帧时间戳旁车（临时文件，随 RAW 一起删除）。
RAW_FRAME_COLUMNS: tuple[str, ...] = (
    "segment_frame_index",
    "frame_id",
    "host_ns",
    "camera_timestamp_raw",
)

MASTER_COLUMNS: tuple[str, ...] = (
    "axis",
    "target_amplitude_um",
    "target_direction",
    "iteration_count",
    "termination_state",
    "final_mean_error_um",
    "final_abs_error_um",
    "final_error_peak_to_peak_um",
    "max_overshoot_um",
    "smallest_command_issued_um",
    "corresponding_actual_motion_um",
    "actual_frames",
    "expected_frames",
    "frame_ratio",
    "valid_chessboard_frames",
    "chessboard_detection_rate",
    "initial_error_um",
    "residual_snr",
    "est_sigma_um",
    "limit_cycle_amplitude_um",
    "plateau_um",
    "min_effective_motion_limit_um",
    "drift_um_per_min",
    "ref_cross_group_delta_um",
    "converged_verified",
    "axis_reference_um",
    "temp_bytes_peak",
    "trash_bytes",
    "note",
)

TEMP_DIR_NAME = "_micro_temp"
TRASH_DIR_NAME = "_micro_trash"

# 证据帧用途标签（每个目标最多 MICRO_LOOP_EVIDENCE_MAX 张）。
EVIDENCE_START = "01_start_stable"
EVIDENCE_PEAK = "02_max_offset_or_overshoot"
EVIDENCE_FINAL = "03_final_converged_or_limit_cycle"


# =============================================================================
# 1. 纯计算层（不 import 相机 SDK / ur_rtde，可离线单测）
# =============================================================================

def build_targets(
    *,
    axes: Sequence[str] = AXES,
    amplitudes_um: Sequence[int] = AMPLITUDES_UM,
    directions: Sequence[int] = DIRECTIONS,
) -> list[dict[str, Any]]:
    """
    生成 12 个核心目标：X:+5,−5,+20,−20,+50,−50 然后 Y 同样。

    输入：轴、幅值、方向（默认都取本模块常量）。
    输出：目标字典列表，按执行顺序排列。

    实验作用：±A 不是"一条命令"，而是"一个视觉目标位置 + 允许反复闭环纠偏"。
    同一个幅值的 +A 与 −A 共用同一个局部参考，不重新定义参考——
    这样 +A→−A 的切换才真正检验反向时的死区/回差。
    """

    targets: list[dict[str, Any]] = []
    for axis in axes:
        for amplitude_um in amplitudes_um:
            for direction in directions:
                targets.append(
                    {
                        "target_id": f"{axis}_{int(amplitude_um):03d}um_{'pos' if direction > 0 else 'neg'}",
                        "axis": str(axis),
                        "amplitude_um": int(amplitude_um),
                        "direction": int(direction),
                        "target_um": float(direction) * float(amplitude_um),
                    }
                )
    return targets


def build_groups(
    *,
    axes: Sequence[str] = AXES,
    amplitudes_um: Sequence[int] = AMPLITUDES_UM,
) -> list[dict[str, Any]]:
    """
    按"一个幅值一组"分组，组内先 +A 后 −A。

    输入：轴、幅值。
    输出：组列表，每组含 axis / amplitude_um / 两个目标。

    实验作用：参考只在组的开头建立一次。组内 +A 与 −A 共用它，
    幅度切换时才重新建立新参考——这正是操作者要求的流程。
    """

    groups: list[dict[str, Any]] = []
    for axis in axes:
        for amplitude_um in amplitudes_um:
            groups.append(
                {
                    "axis": str(axis),
                    "amplitude_um": int(amplitude_um),
                    "targets": build_targets(
                        axes=(axis,), amplitudes_um=(amplitude_um,), directions=DIRECTIONS
                    ),
                }
            )
    return groups


def command_for_error(
    error_um: float,
    *,
    sign: float = 1.0,
    kp: float | None = None,
    max_correction_um: float | None = None,
    min_command_um: float | None = None,
) -> float:
    """
    由剩余误差算出这一轮要发的笛卡尔修正量（μm）。

    输入：误差（μm，视觉坐标系）、轴向符号、Kp、限幅、死区。
    输出：有符号修正量（μm）。死区内或非法输入返回 0.0。

    控制律就是操作者指定的 command = Kp · error，这里不做 PID、不做滤波、
    不做死区补偿、不做自适应。sign 来自启动时的轴向探针，只负责把视觉坐标
    翻到机器人基座坐标——符号反了闭环会每步翻倍直冲限幅，必须先测出来。

    死区是必需的，不是调参：robot.validate_trajectory 拒绝 length <= 1e-6 m
    （"两点位置重合"）。而收敛时 |error| 可能只有 1 μm，Kp=1 时命令 1 μm，
    正好撞在这条硬线上——那会在一个目标即将成功的时刻把整轮弄死。
    """

    kp = float(config.MICRO_LOOP_KP) if kp is None else float(kp)
    max_correction_um = (
        float(config.MICRO_LOOP_MAX_CORRECTION_UM)
        if max_correction_um is None
        else float(max_correction_um)
    )
    min_command_um = (
        float(config.MICRO_LOOP_MIN_COMMAND_UM)
        if min_command_um is None
        else float(min_command_um)
    )

    if not math.isfinite(float(error_um)):
        return 0.0

    raw = float(sign) * kp * float(error_um)
    clamped = max(-max_correction_um, min(max_correction_um, raw))
    if abs(clamped) < min_command_um:
        return 0.0
    return clamped


def effective_tolerance_um(tol_um: float, noise_um: float) -> float:
    """
    把标称容差放宽到噪声底之上，返回实际使用的收敛容差。

    输入：配置容差、本组实测测量噪声（μm）。
    输出：有效容差（μm）。

    实验作用：如果一次闭环测量的不确定度本身就有 4 μm，那么"误差 ≤ 3 μm"
    这个判据只是在筛噪声，不是判收敛。取 mode 决定是绝对容差还是随噪声放宽。
    """

    tol_um = float(tol_um)
    noise_um = float(noise_um)
    if not math.isfinite(noise_um) or noise_um <= 0.0:
        return tol_um
    if str(config.MICRO_LOOP_POSITION_TOL_MODE) == "absolute":
        return tol_um
    return max(tol_um, float(config.MICRO_LOOP_NOISE_SIGMA_MULT) * noise_um)


def median_of_tail(values: Sequence[float], times_ns: Sequence[int], window_s: float) -> float | None:
    """
    取"最后 window_s 时间内有效值"的中位数。

    输入：值与对应时间戳（同长）、尾部窗口秒数。
    输出：中位数；窗口内没有值则 None。

    实验作用：操作者明确要求用"最后一段有效数据的中位数"而不是单帧。
    单帧既受噪声影响，又可能正好落在一次偶发误检上；中位数对两者都稳。
    按时间戳而不是"最后 N 帧"取窗口，是因为相机实测会零星丢帧，
    "最后 N 帧"在丢帧时对应的真实时长会变。
    """

    if not values or not times_ns or len(values) != len(times_ns):
        return None
    cutoff_ns = int(times_ns[-1]) - int(float(window_s) * 1_000_000_000)
    tail = [float(v) for v, t in zip(values, times_ns) if int(t) >= cutoff_ns]
    if not tail:
        return None
    return float(np.median(tail))


def expected_frames(record_start_ns: int, record_stop_ns: int, fps: float) -> int:
    """
    按本段真实的录制起止时间和实际帧率推算应有多少帧。

    输入：录制起、止的 host_ns，相机实际帧率。
    输出：预期帧数。

    实验作用：不假设所有片段一样长。每段都记自己的起止时间，
    "实际帧数 / 预期帧数"才是有意义的成对指标。
    """

    if fps <= 0.0:
        return 0
    span_s = (int(record_stop_ns) - int(record_start_ns)) / 1_000_000_000.0
    if span_s <= 0.0:
        return 0
    return int(round(span_s * float(fps)))


def estimate_window_bytes(width: int, height: int, fps: float, seconds: float) -> int:
    """
    估算一段全幅 Mono8 未压缩 RAW 的字节数。

    输入：宽、高、帧率、秒数。
    输出：字节数（1 字节/像素）。

    实验作用：磁盘保护按峰值而不是稳态核算——同时可能存在的
    有一段正在录、有上一段还没删掉。
    """

    return int(round(float(width) * float(height) * float(fps) * float(seconds)))


def disk_free_bytes(path: Path | str) -> int:
    """
    返回给定路径所在卷的可用字节数。

    输入：任意路径，**不要求它已经存在**。
    输出：字节数。

    磁盘检查必须发生在创建任何目录之前，而 OUTPUT_ROOT 可能还没被建出来，
    所以这里向上找到最近一个真实存在的祖先再问文件系统。
    """

    probe = Path(path).resolve()
    while not probe.exists():
        parent = probe.parent
        if parent == probe:
            break
        probe = parent
    return int(shutil.disk_usage(str(probe)).free)


def free_gb(path: Path | str) -> float:
    """返回给定路径所在卷的可用空间（GiB）。"""

    return disk_free_bytes(path) / (1024.0 ** 3)


def format_gib(value: int | float) -> str:
    """把字节数格式化成 GiB 字符串。"""

    return f"{float(value) / (1024.0 ** 3):.2f} GiB"


def allocate_closed_loop_run(
    output_root: Path, now: datetime | None = None
) -> tuple[str, Path]:
    """
    创建本次运行的输出目录，绝不覆盖已有目录。

    输入：输出根目录、可选时间戳。
    输出：(运行 id, 运行目录)。目录已存在时依次追加 _02、_03。
    """

    output_root = Path(output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    stamp = (now or datetime.now()).strftime("%Y%m%d_%H%M%S")
    run_id = f"micro_motion_{stamp}"
    candidate = output_root / run_id
    counter = 2
    while candidate.exists():
        run_id = f"micro_motion_{stamp}_{counter:02d}"
        candidate = output_root / run_id
        counter += 1
    candidate.mkdir(parents=True)
    return run_id, candidate


def target_dir(run_dir: Path, axis: str, amplitude_um: int) -> Path:
    """目标组目录，例如 <run>/X/005um。"""

    return Path(run_dir) / str(axis) / f"{int(amplitude_um):03d}um"


def direction_slug(direction: int) -> str:
    """方向对应的文件名前缀：+1 → positive，−1 → negative。"""

    return "positive" if int(direction) > 0 else "negative"


def write_rows_csv(
    path: Path,
    rows: Sequence[dict[str, Any]],
    columns: Sequence[str],
    *,
    overwrite: bool = True,
) -> None:
    """写一个通用 CSV；实验中途反复重写，以便崩溃后仍留有已完成的数据。"""

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    mode = "w" if overwrite else "x"
    with path.open(mode, encoding="utf-8-sig", newline="", buffering=65_536) as file:
        writer = csv.DictWriter(file, fieldnames=list(columns), extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
        file.flush()
        os.fsync(file.fileno())


def read_rows_csv(path: Path) -> list[dict[str, str]]:
    """读取一个通用 CSV，返回字符串行。"""

    with Path(path).open("r", encoding="utf-8-sig", newline="") as file:
        return [dict(row) for row in csv.DictReader(file)]


def write_json(path: Path, payload: Any) -> None:
    """写一个 JSON（先落盘再返回，供崩溃后仍可读）。"""

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=True, default=str)
    with path.open("w", encoding="utf-8") as file:
        file.write(text)
        file.flush()
        os.fsync(file.fileno())


def append_log(path: Path, text: str) -> None:
    """向实验日志追加一行（带时间戳，落盘）。"""

    stamp = datetime.now().strftime("%H:%M:%S")
    with Path(path).open("a", encoding="utf-8", buffering=1) as file:
        file.write(f"[{stamp}] {text}\n")


def _format_pose(pose: Any) -> str:
    """把一个 6 维 TCP 位姿写成 CSV 里的单个字段（分号分隔，9 位小数）。"""

    if pose is None:
        return ""
    try:
        return ";".join(f"{float(value):.9f}" for value in pose)
    except (TypeError, ValueError):
        return ""


def mad_sigma(values: Sequence[float]) -> float:
    """用 MAD 估计标准差（1.4826 × 中位绝对偏差），对离群点比 std 稳。"""

    data = np.asarray([float(v) for v in values if math.isfinite(float(v))], dtype=float)
    if data.size == 0:
        return float("nan")
    return float(np.median(np.abs(data - np.median(data))) * 1.4826)


def estimate_measurement_sigma_um(
    values: Sequence[float], tail_frames: int, *, every_n: int = 1
) -> float:
    """
    用"闭环自己的估计量"实测一次测量的不确定度。

    输入：参考片段的合格帧位移序列（μm）、尾部窗口应有帧数、抽帧步长。
    输出：一次闭环测量的标准差估计（μm）。

    做法：对整条序列做块自助——把每一个可能位置的"尾部窗口中位数"都算出来，
    取这些中位数的标准差。这正是闭环每一步真正在做的事，所以这个数才是
    闭环的测量不确定度，而不是单帧噪声。用实测而不是假设，
    是因为它直接决定 POSITION_TOL 能不能被判据满足。
    """

    data = np.asarray([float(v) for v in values if math.isfinite(float(v))], dtype=float)
    window = max(1, int(tail_frames) // max(1, int(every_n)))
    if data.size < window + 1:
        return float("nan")
    windows = [float(np.median(data[i : i + window])) for i in range(data.size - window + 1)]
    return float(np.std(windows))


def evaluate_termination(
    errors_um: Sequence[float],
    valid: Sequence[bool],
    *,
    tol_um: float,
    noise_um: float,
) -> str:
    """
    判断闭环该不该停，以及为什么停。

    输入：误差序列（第 0 项是迭代前的初始误差，之后每项是上一次迭代后的残差）、
          与它等长的有效标志、有效容差、本组测量噪声。
    输出：终止状态常量；返回 STILL_SHRINKING 表示继续迭代。

    判据不只是"换号 + 峰峰值不缩"。5 μm 档最可能出现的其实不是极限环，而是
    单边平台：控制器忽略了小于阈值的命令，误差于是冻结在一个恒定值上，
    **一次号都不换**——原始判据永远不会触发，最后报 MAX_ITER，而 MAX_ITER
    完全掩盖了"这里有一个最小有效运动尺度"这个结论。所以单边平台独立成桶。

    两道防早期误判的门（这才是判据能不能用的关键）：
    1. 先过噪声底：最近的误差已经低到噪声量级时，换号是噪声，不是极限环。
    2. 先过"无进展"：必须至少走到路程一半，才允许判极限环。否则
       "误差还很大但在单调收缩"会被早期误判成极限环。
    """

    cycle_window = int(config.MICRO_LOOP_CYCLE_WINDOW)
    min_sign_changes = int(config.MICRO_LOOP_CYCLE_MIN_SIGN_CHANGES)
    ptp_keep = float(config.MICRO_LOOP_CYCLE_PTP_KEEP)
    abs_keep = float(config.MICRO_LOOP_CYCLE_ABS_KEEP)
    converge_count = int(config.MICRO_LOOP_CONVERGE_COUNT)

    tol_eff = effective_tolerance_um(tol_um, noise_um)
    noise_floor = tol_eff

    pairs = [(index, float(value)) for index, value in enumerate(errors_um) if valid[index]]
    if not pairs:
        return TERMINAL_STILL_SHRINKING

    # 收敛判据：连续 converge_count 次落在有效容差内。
    tail = pairs[-converge_count:]
    if len(tail) == converge_count and all(abs(value) <= tol_eff for _, value in tail):
        return TERMINAL_CONVERGED

    if len(pairs) < 2 * cycle_window:
        return TERMINAL_STILL_SHRINKING

    recent_pairs = pairs[-cycle_window:]
    prior_pairs = pairs[-2 * cycle_window : -cycle_window]

    # 不允许跨测量缺口比较：中间有太多无效迭代时，前后两组根本不是同一段过程。
    span = recent_pairs[-1][0] - recent_pairs[0][0]
    if span > cycle_window + 4:
        return TERMINAL_STILL_SHRINKING

    recent = [value for _, value in recent_pairs]
    prior = [value for _, value in prior_pairs]
    first_error = pairs[0][1]

    # 门 1（对下面所有分支生效）：已经低到噪声量级时，换号就是噪声，不是现象。
    if min(abs(value) for value in recent) <= noise_floor:
        return TERMINAL_STILL_SHRINKING

    sign_changes = sum(1 for a, b in zip(recent, recent[1:]) if a * b < 0.0)
    ptp_recent = max(recent) - min(recent)
    ptp_prior = max(prior) - min(prior)
    abs_recent = float(np.median([abs(value) for value in recent]))
    abs_prior = float(np.median([abs(value) for value in prior]))

    # 发散的判据是"幅值在长大"，与"有没有走够路程"无关，所以必须排在门 2 之前。
    # 排在后面的话：发散序列的 min|recent| 恰好总是大于首误差的一半，
    # 会被门 2 当成 STILL_SHRINKING 吞掉，而这个状态是最该被报出来的。
    if abs_recent > 1.2 * abs_prior:
        return TERMINAL_DIVERGING

    if sign_changes >= min_sign_changes:
        # 门 2（只对极限环生效）：必须至少走到路程一半，才允许下极限环结论。
        # 这一道专门杀掉"误差还很大但在单调收缩、只是因为噪声换了一两次号"的早期误判。
        if abs(first_error) > 0.0 and min(abs(value) for value in recent) >= 0.5 * abs(first_error):
            return TERMINAL_STILL_SHRINKING
        # 真极限环：反复换号，且峰峰值与中位幅值都不再收缩。
        # 这两条同时把"增益略大于 1 但仍在收敛"的振荡排除掉：
        # 那种情况下 6 步包络会缩到 |1−Kp·g|^6（|1−Kp·g| = 0.85 时是 0.38），
        # 远低于 0.5 与 0.7，只有约等于单位环路增益的真极限环能存活。
        if ptp_recent >= ptp_keep * ptp_prior and abs_recent >= abs_keep * abs_prior:
            return TERMINAL_LIMIT_CYCLE
        return TERMINAL_STILL_SHRINKING

    # 单边平台：一次号都不换、窗口很窄、但幅值仍在容差之上——
    # 控制器忽略了小于某个阈值的命令，误差冻结在一个恒定值上。
    # **这一条不能受门 2 管辖**：停在 32 μm 而目标是 50 μm 时，
    # min|recent| 恰好大于首误差的一半，门 2 会把 5 μm 档最可能出现的这个结果
    # 一直压到 MAX_ITER，而 MAX_ITER 完全掩盖了"存在最小有效运动尺度"这个结论。
    if ptp_recent <= 0.25 * abs_recent and abs_recent > tol_eff:
        return TERMINAL_STALLED

    return TERMINAL_STILL_SHRINKING


def convergence_quality(
    errors_um: Sequence[float],
    valid: Sequence[bool],
    *,
    noise_um: float,
) -> tuple[float, float]:
    """
    判断"收敛"是真不动点还是运气好落进噪声里。

    输入：误差序列、有效标志、本组测量噪声。
    输出：(有符号残差 μm, 残差信噪比)。

    实验作用：残差信噪比低于 2 时，残差与零在统计上不可分，
    只能诚实地记作 CONVERGED_NOISE_LIMITED；信噪比高且残差大于容差，
    说明存在一个可重复的物理下限——那才是本实验最有价值的单个数。
    """

    converge_count = int(config.MICRO_LOOP_CONVERGE_COUNT)
    recent = [float(v) for i, v in enumerate(errors_um) if valid[i]][-converge_count:]
    if not recent:
        return float("nan"), float("nan")
    residual_um = float(np.median(recent))
    sigma = float(noise_um) / math.sqrt(len(recent)) if noise_um and math.isfinite(noise_um) else float("nan")
    if not math.isfinite(sigma) or sigma <= 0.0:
        snr = math.inf if abs(residual_um) > 0.0 else 0.0
    else:
        snr = abs(residual_um) / sigma
    return residual_um, snr


@dataclass
class ProbeGains:
    """启动探针测出的视觉↔机器人映射。"""

    gain: dict[str, dict[str, float]] = field(default_factory=dict)
    sign: dict[str, float] = field(default_factory=dict)
    vision_axis: dict[str, str] = field(default_factory=dict)
    hysteresis: dict[str, float] = field(default_factory=dict)
    cross_coupling: dict[str, float] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)

    def to_json(self) -> dict[str, Any]:
        return {
            "gain_matrix": self.gain,
            "sign": self.sign,
            "vision_axis_for_robot_axis": self.vision_axis,
            "hysteresis_ratio": self.hysteresis,
            "cross_coupling_ratio": self.cross_coupling,
            "notes": list(self.notes),
        }


def evaluate_probe_gains(
    baseline: dict[str, float],
    forward: dict[str, dict[str, float]],
    backward: dict[str, dict[str, float]],
) -> ProbeGains:
    """
    由探针片段位移算出增益矩阵并逐项过门禁。

    输入：
    - baseline：探针参考片段的 (x_um, y_um)；
    - forward：每个机器人轴正向移动后的 (x_um, y_um)；
    - backward：每个机器人轴反向回到起点后的 (x_um, y_um)。
    输出：ProbeGains；任一门禁不通过时抛 RuntimeError（具名中止，不继续）。

    增益矩阵 G[视觉轴][机器人轴] = 视觉位移(μm) / 机器人位移(μm)。
    这里同时定三件事：轴向对应、符号、以及增益量级是否落在闭环能收敛的范围内。
    |g| 明显大于 1 意味着过冲振荡风险，明显小于 1 意味着 20 次迭代也走不完 50 μm。
    """

    probe_um = float(config.MICRO_LOOP_PROBE_UM)
    gain_min = float(config.MICRO_LOOP_GAIN_MIN)
    gain_max = float(config.MICRO_LOOP_GAIN_MAX)
    hysteresis_ratio = float(config.MICRO_LOOP_PROBE_HYSTERESIS_RATIO)

    def delta(after: dict[str, float], before: dict[str, float]) -> dict[str, float]:
        return {
            "x": float(after.get("x", 0.0)) - float(before.get("x", 0.0)),
            "y": float(after.get("y", 0.0)) - float(before.get("y", 0.0)),
        }

    gains = ProbeGains()
    forward_delta: dict[str, dict[str, float]] = {}
    backward_delta: dict[str, dict[str, float]] = {}
    position = {"x": float(baseline.get("x", 0.0)), "y": float(baseline.get("y", 0.0))}

    for robot_axis in ("X", "Y"):
        moved = delta(forward.get(robot_axis, position), position)
        back = delta(backward.get(robot_axis, position), forward.get(robot_axis, position))
        forward_delta[robot_axis] = moved
        backward_delta[robot_axis] = back
        gains.gain[robot_axis] = {
            "x": moved["x"] / probe_um,
            "y": moved["y"] / probe_um,
        }

        # 选主响应轴。注意下面全部门禁比的都是**增益**（视觉位移 ÷ 机器人位移，无量纲），
        # 不是位移本身——探针位移是 1000 μm 量级，拿它去比 [0.3, 2.0] 的增益带，
        # 无论机器多好都会判定"超出范围"而在启动时中止整轮实验。
        main_fwd = max(((abs(moved[vision]), vision) for vision in ("x", "y")), default=(0.0, "x"))
        main_bwd = max(((abs(back[vision]), vision) for vision in ("x", "y")), default=(0.0, "x"))
        gains.vision_axis[robot_axis] = main_fwd[1]

        signed_gain = moved[main_fwd[1]] / probe_um
        fwd_gain = abs(signed_gain)
        bwd_gain = main_bwd[0] / probe_um
        gains.sign[robot_axis] = 1.0 if signed_gain >= 0.0 else -1.0

        if fwd_gain <= 0.0:
            raise RuntimeError(
                f"轴向探针：机器人 {robot_axis} 轴走 {probe_um:g} μm，视觉上没有任何位移。"
                "可能相机视野外、镜头被遮挡，或该轴与像平面近乎平行。"
            )

        if not gain_min <= fwd_gain <= gain_max:
            raise RuntimeError(
                f"轴向探针：机器人 {robot_axis} 轴 → 视觉 {main_fwd[1]} 的增益为 "
                f"{fwd_gain:+.3f}（机器人走 {probe_um:g} μm，视觉测到 "
                f"{main_fwd[0]:+.1f} μm），超出允许范围 [{gain_min:g}, {gain_max:g}]。"
                "增益过大意味着闭环振荡风险，过小意味着 20 次迭代也走不完目标幅值。"
            )

        if bwd_gain > 0.0:
            hysteresis = abs(fwd_gain - bwd_gain) / fwd_gain
            gains.hysteresis[robot_axis] = float(hysteresis)
            if hysteresis > hysteresis_ratio:
                raise RuntimeError(
                    f"轴向探针：机器人 {robot_axis} 轴正向增益 {fwd_gain:.3f}、"
                    f"反向增益 {bwd_gain:.3f}，相差 {hysteresis:.1%}，"
                    f"超过允许的 {hysteresis_ratio:.0%}。回差大到这个程度时闭环不是良定的。"
                )
        else:
            gains.hysteresis[robot_axis] = float("nan")

        other = [vision for vision in ("x", "y") if vision != main_fwd[1]]
        if other:
            cross = abs(moved[other[0]]) / main_fwd[0]
            gains.cross_coupling[robot_axis] = float(cross)
            if cross >= 0.3:
                gains.notes.append(
                    f"机器人 {robot_axis} 轴对视觉 {other[0]} 的交叉耦合为 {cross:.2f}，"
                    "已记录但未补偿（本实验只按被测轴纠偏）。"
                )

    if gains.vision_axis.get("X") == gains.vision_axis.get("Y"):
        raise RuntimeError(
            f"轴向探针：机器人 X 与 Y 都主要映射到视觉 {gains.vision_axis.get('X')} 轴，"
            "说明像平面与机器人 XY 平面接近侧视，两个自由度不可分辨，闭环无法工作。"
        )
    return gains


# =============================================================================
# 2. 视觉测量层（复用已验证的棋盘格亚像素链路）
# =============================================================================

def _accept_frame(
    result: dict[str, Any],
    *,
    ref_found_by: str | None,
) -> tuple[bool, str]:
    """
    判断一帧的棋盘格结果能不能进入测量。

    输入：CheckerboardTracker.process() 返回的结果字典、参考帧的检测方法。
    输出：(是否接受, 拒绝原因)。

    为什么每一帧都要过这一套：棋盘格**索引错位一格**时，所有角点位移同一个向量
    （约一个方格 3 mm），estimateAffinePartial2D 会拟合成一个残差≈0、内点率 1.0、
    质量分≈1.0、转角≈0、尺度≈1 的**纯平移**——它和"真的移动了 3 mm"
    在返回字典里完全无法区分。3000 μm 的假误差喂进限幅 100 μm 的闭环，
    就是 20 步朝任意方向走 2 mm。

    其中 found_by 相等这一条最廉价也最关键：findChessboardCornersSB 与传统兜底
    findChessboardCorners 不保证角点排序一致，参考帧若来自 sb、某帧回落到 legacy，
    配对就可能被置换。
    """

    if not result.get("checker_is_valid"):
        return False, "识别失败"

    found_by = result.get("checker_found_by")
    if ref_found_by is not None and found_by != ref_found_by:
        return False, f"检测方法从 {ref_found_by} 变为 {found_by}，角点排序可能不同"

    quality = result.get("checker_quality")
    if quality is None or not math.isfinite(float(quality)) or float(quality) < float(
        config.MICRO_LOOP_QUALITY_MIN
    ):
        return False, f"质量分 {quality} 低于 {config.MICRO_LOOP_QUALITY_MIN}"

    angle = result.get("checker_angle_deg")
    if angle is None or not math.isfinite(float(angle)) or abs(float(angle)) > float(
        config.MICRO_LOOP_ANGLE_MAX_DEG
    ):
        return False, f"转角 {angle}° 超过 {config.MICRO_LOOP_ANGLE_MAX_DEG}°"

    scale = result.get("checker_scale")
    if scale is None or not math.isfinite(float(scale)) or abs(float(scale) - 1.0) > float(
        config.MICRO_LOOP_SCALE_TOL
    ):
        return False, f"尺度 {scale} 偏离 1 超过 {config.MICRO_LOOP_SCALE_TOL}"

    dx_mm = result.get("checker_dx_mm")
    dy_mm = result.get("checker_dy_mm")
    if dx_mm is None or dy_mm is None or not (
        math.isfinite(float(dx_mm)) and math.isfinite(float(dy_mm))
    ):
        return False, "位移为非法值"
    shift_um = max(abs(float(dx_mm)), abs(float(dy_mm))) * 1000.0
    if shift_um > float(config.MICRO_LOOP_MAX_PLAUSIBLE_SHIFT_UM):
        return False, f"位移 {shift_um:.1f} μm 超过物理不可能值"

    return True, ""


def _tracker_process(tracker: Any, frame: np.ndarray) -> tuple[dict[str, Any], Any, Any]:
    """
    走一帧棋盘格识别：模糊 → 固定 RNG → CheckerboardTracker.process。

    这里刻意不复用 camera.preprocess_frame：它在本项目当前配置下
    （CAMERA_MATRIX 与 VISION_ROI 都是 None）实际只做「灰度 → 高斯模糊 → 画质指标」，
    而画质指标是 4 次全幅遍历（实测约 40 ms/帧），对闭环毫无用处。
    识别部分与 preprocess_frame 逐字等价：同样的高斯模糊核，同一个
    CheckerboardTracker.process。这不是"换了识别流程"，只是不算那份显示用的统计量。

    fixed RNG：_estimate_rigid_motion 用 estimateAffinePartial2D(method=RANSAC)，
    内点集抖动会让 88 点均值位移跳动约 (2/88)·0.5 px·0.0685 ≈ 0.8 μm。
    固定种子让同一帧永远得到同一结果——对 3 μm 容差不是小数目。
    """

    import cv2

    gray = frame if frame.ndim == 2 else cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    if gray.dtype != np.uint8:
        raise RuntimeError(f"闭环微动只支持 uint8 帧，实际 dtype={gray.dtype}。")
    blurred = cv2.GaussianBlur(gray, (3, 3), 0)
    cv2.setRNGSeed(0)
    return tracker.process(blurred)


@dataclass
class RawClip:
    """一段临时 RAW 及其旁车信息。"""

    raw_path: Path
    meta: dict[str, Any]
    frame_rows: list[dict[str, Any]]

    @property
    def frame_count(self) -> int:
        return int(self.meta.get("frame_count", len(self.frame_rows)))

    @property
    def width(self) -> int:
        return int(self.meta["width"])

    @property
    def height(self) -> int:
        return int(self.meta["height"])


def open_raw_clip(raw_path: Path, *, require_sidecar: bool = True) -> RawClip:
    """
    打开一段临时 RAW 及其旁车元数据和逐帧时间戳。

    输入：RAW 路径。
    输出：RawClip。

    实验作用：形状一律从相机写的元数据读，不靠猜；猜错会让整体错位。
    """

    raw_path = Path(raw_path)
    meta_path = raw_path.with_name(raw_path.stem + "_raw_meta.json")
    frames_path = raw_path.with_name(raw_path.stem + "_frames.csv")
    if require_sidecar and not meta_path.exists():
        raise FileNotFoundError(f"找不到 {meta_path.name}，无法确定 RAW 的形状。")
    meta = json.loads(meta_path.read_text(encoding="utf-8")) if meta_path.exists() else {}
    rows: list[dict[str, Any]] = []
    if frames_path.exists():
        rows = read_rows_csv(frames_path)
    return RawClip(raw_path=raw_path, meta=meta, frame_rows=rows)


def iter_clip_frames(
    clip: RawClip, *, every_n: int = 1
) -> Iterator[tuple[int, dict[str, Any], np.ndarray]]:
    """
    逐帧读出一段 RAW。

    输入：RawClip、抽帧步长。
    输出：迭代 (段内帧序号, 逐帧时间戳行, 帧数组)。

    用 memmap 而不是把整段读进内存：一段 1.6 s 的全幅片段是 600 MB，
    而父进程同时还要持有上一段的结果。
    """

    frame_count = clip.frame_count
    mapped = np.memmap(
        clip.raw_path,
        dtype=np.uint8,
        mode="r",
        shape=(frame_count, clip.height, clip.width),
    )
    try:
        for index in range(0, frame_count, max(1, int(every_n))):
            row = clip.frame_rows[index] if index < len(clip.frame_rows) else {}
            yield index, row, np.asarray(mapped[index])
    finally:
        del mapped
        gc.collect()


def _row_time_ns(row: dict[str, Any]) -> int:
    """从逐帧时间戳行里取出 host_ns（子进程与父进程共享同一时钟）。"""

    value = row.get("host_ns")
    if value in (None, ""):
        return 0
    return int(float(value))


def scan_corners(clip: RawClip, *, every_n: int = 1) -> list[tuple[int, Any]]:
    """
    用一次性 tracker 扫出每一帧的原始角点，用于挑参考帧。

    输入：RawClip、抽帧步长。
    输出：[(段内帧序号, 角点数组)]，只含识别成功的帧。

    注意这里只用 process() 返回的第二个元素（当前帧角点），
    不用它的位移——一次性 tracker 会在自己看到的第一帧上锁存参考，
    而那一帧完全可能是离群帧。这一步的目的就是不要被它左右。
    """

    from camera import CheckerboardTracker

    survey = CheckerboardTracker()
    found: list[tuple[int, Any]] = []
    for index, _, frame in iter_clip_frames(clip, every_n=every_n):
        _, corners, _ = _tracker_process(survey, frame)
        if corners is not None:
            found.append((index, corners))
    return found


def pick_medoid_frame(found: Sequence[tuple[int, Any]]) -> int:
    """
    从识别成功的帧里挑出"最不可能是离群点"的一帧（medoid）。

    输入：[(帧序号, 角点)]。
    输出：medoid 的段内帧序号。

    做法：取所有帧角点的质心，再挑质心离全体质心中位数最近的那一帧。
    为什么不能用"第一帧"：参考一旦锁存就永不更新，且没有公开的 setter，
    所以任何一帧被选为参考，它带来的误差会成为整组的永久零点。
    """

    if not found:
        raise RuntimeError("参考片段里没有任何一帧识别成功。")

    import cv2

    centroids = np.asarray(
        [np.asarray(corners, dtype=float).reshape(-1, 2).mean(axis=0) for _, corners in found],
        dtype=float,
    )
    median_centroid = np.median(centroids, axis=0)
    distances = np.linalg.norm(centroids - median_centroid, axis=1)
    best = int(np.argmin(distances))
    del cv2
    return int(found[best][0])


class GroupVisionMeter:
    """
    一个目标组一个实例的视觉测量器。

    CheckerboardTracker 只在**第一次成功识别**时锁存参考角点与 mm_per_pixel，
    此后永不更新，也没有公开的 setter。所以：
    - 跨片段必须复用同一个实例，否则每段都会重新定义零点；
    - 参考帧用 medoid 挑，不让"碰巧第一帧"变成整组的永久零点。
    """

    def __init__(self, *, label: str = "") -> None:
        from camera import CheckerboardTracker

        self.label = label
        self.tracker = CheckerboardTracker()
        self.ref_found_by: str | None = None
        self.ref_us: dict[str, float] = {"x": 0.0, "y": 0.0}
        self.sigma_ref_um: float = float("nan")
        self.est_sigma_um: float = float("nan")
        self.reference_frame_index: int | None = None
        self.n_primed_frames = 0

    # ---- 参考建立 -------------------------------------------------------

    def prime(self, clip: RawClip, *, every_n: int = 1) -> dict[str, Any]:
        """
        从一段静止片段建立本组的视觉零点。

        输入：参考片段、抽帧步长。
        输出：含零点、噪声底、测量不确定度的字典。

        流程：扫角点 → 挑 medoid → 让正式 tracker 以该帧为第一帧锁存 →
        再走一遍全片段，用中位数定零点、用块自助定测量不确定度。
        """

        found = scan_corners(clip, every_n=every_n)
        if not found:
            raise RuntimeError(f"参考片段里没有任何一帧识别成功（{clip.raw_path.name}）。")
        medoid_index = pick_medoid_frame(found)

        # 正式 tracker 必须"第一眼"就看到 medoid 帧，才能把参考锁在它上面。
        primed = False
        for index, _, frame in iter_clip_frames(clip, every_n=every_n):
            if index != medoid_index:
                continue
            result, _, _ = _tracker_process(self.tracker, frame)
            if result.get("checker_is_valid"):
                self.ref_found_by = result.get("checker_found_by")
                primed = True
            break
        if not primed:
            raise RuntimeError("medoid 参考帧在正式 tracker 上识别失败，参考无法建立。")

        self.reference_frame_index = medoid_index
        measurement = self.measure_clip(clip, every_n=every_n)
        accepted = [
            row for row in measurement.frame_rows if str(row.get("accepted")) == "True"
        ]
        if not measurement.frame_rows:
            raise RuntimeError("参考片段没有任何帧。")

        accept_ratio = len(accepted) / len(measurement.frame_rows)
        if accept_ratio < 0.6:
            raise RuntimeError(
                f"参考片段合格帧比例只有 {accept_ratio:.1%}，低于 60%。"
                "零点建立不可信，本组不继续。"
            )

        dx_values = [float(row["checker_dx_mm"]) * 1000.0 for row in accepted]
        dy_values = [float(row["checker_dy_mm"]) * 1000.0 for row in accepted]
        self.ref_us = {
            "x": float(np.median(dx_values)) if dx_values else 0.0,
            "y": float(np.median(dy_values)) if dy_values else 0.0,
        }
        spread = max(mad_sigma(dx_values), mad_sigma(dy_values))
        if math.isfinite(spread) and spread > float(config.MICRO_LOOP_MAX_PLAUSIBLE_SHIFT_UM) / 100.0:
            raise RuntimeError(
                f"参考片段自身抖动 {spread:.1f} μm 过大，零点不可信，本组不继续。"
            )
        self.sigma_ref_um = float(spread)
        self.n_primed_frames = len(accepted)

        tail_frames = max(1, int(round(float(config.MICRO_LOOP_TAIL_WINDOW_S) * self._fps(clip))))
        self.est_sigma_um = estimate_measurement_sigma_um(
            dx_values if len(dx_values) >= len(dy_values) else dy_values,
            tail_frames,
            every_n=every_n,
        )
        return {
            "label": self.label,
            "reference_frame_index": medoid_index,
            "ref_found_by": self.ref_found_by,
            "reference_us": dict(self.ref_us),
            "sigma_ref_um": self.sigma_ref_um,
            "est_sigma_um": self.est_sigma_um,
            "primed_valid_frames": self.n_primed_frames,
            "primed_total_frames": len(measurement.frame_rows),
            "accept_ratio": accept_ratio,
        }

    @staticmethod
    def _fps(clip: RawClip) -> float:
        return float(
            clip.meta.get("camera_actual_fps")
            or config.EXPECTED_VISION_FPS
            or 132.0
        )

    def _to_reference_us(self, dx_mm: Any, dy_mm: Any) -> dict[str, float]:
        """把一帧的原始位移换算成相对本组零点的 μm 坐标。"""

        return {
            "x": float(dx_mm) * 1000.0 - self.ref_us["x"],
            "y": float(dy_mm) * 1000.0 - self.ref_us["y"],
        }

    # ---- 片段测量 -------------------------------------------------------

    def measure_clip(
        self,
        clip: RawClip,
        *,
        every_n: int = 1,
        iteration_id: str = "",
        prev_measured_um: float | None = None,
    ) -> "ClipMeasurement":
        """
        逐帧测量一段临时 RAW。

        输入：片段、抽帧步长、迭代标识、上一轮的稳定位置（用于连续性联锁）。
        输出：ClipMeasurement。

        连续性联锁：单次迭代最大合法变化就是 100 μm 限幅再加上漂移，
        超过 3 倍限幅一定是检测出了问题。这类帧标为不可信并剔除，
        **绝不用来发命令**。这是控制安全门，不是"识别率低就重测"——
        质量指标只记录，不参与实验控制。
        """

        positions: list[dict[str, float]] = []
        times_ns: list[int] = []
        rows: list[dict[str, Any]] = []
        axis_positions: list[float] = []
        axis_times: list[int] = []
        valid_count = 0
        jump_limit_um = float(config.MICRO_LOOP_MAX_ITER_JUMP_UM)

        for index, frame_row, frame in iter_clip_frames(clip, every_n=every_n):
            result, _, _ = _tracker_process(self.tracker, frame)
            accepted, reason = _accept_frame(result, ref_found_by=self.ref_found_by)
            host_ns = _row_time_ns(frame_row)

            dx_mm = result.get("checker_dx_mm")
            dy_mm = result.get("checker_dy_mm")
            position: dict[str, float] | None = None
            if accepted:
                position = self._to_reference_us(dx_mm, dy_mm)
                if prev_measured_um is not None and math.isfinite(prev_measured_um):
                    if abs(position["x"] - float(prev_measured_um)) > jump_limit_um:
                        accepted = False
                        reason = (
                            f"相对上一轮稳定位置跳变 "
                            f"{abs(position['x'] - float(prev_measured_um)):.1f} μm，"
                            f"超过 {jump_limit_um:g} μm"
                        )
                        position = None

            if accepted and position is not None:
                valid_count += 1
                positions.append(position)
                times_ns.append(host_ns)
                axis_positions.append(position["x"])
                axis_times.append(host_ns)

            rows.append(
                {
                    "iteration_id": iteration_id,
                    "frame_index": index,
                    "frame_id": frame_row.get("frame_id", ""),
                    "host_ns": host_ns,
                    "camera_timestamp_raw": frame_row.get("camera_timestamp_raw", ""),
                    "checker_dx_mm": dx_mm,
                    "checker_dy_mm": dy_mm,
                    "checker_is_valid": result.get("checker_is_valid"),
                    "accepted": accepted,
                    "checker_quality": result.get("checker_quality"),
                    "checker_residual_px": result.get("checker_residual_px"),
                    "checker_angle_deg": result.get("checker_angle_deg"),
                    "checker_scale": result.get("checker_scale"),
                    "checker_found_by": result.get("checker_found_by"),
                    "reject_reason": reason,
                }
            )

        tail_window_s = float(config.MICRO_LOOP_TAIL_WINDOW_S)
        measured = median_of_tail(axis_positions, axis_times, tail_window_s)
        cutoff_ns = (axis_times[-1] - int(tail_window_s * 1e9)) if axis_times else 0
        n_tail = sum(1 for t in axis_times if t >= cutoff_ns)

        tail_values = [v for v, t in zip(axis_positions, axis_times) if t >= cutoff_ns]
        sigma_tail = float(np.std(tail_values)) if len(tail_values) >= 2 else float("nan")

        transverse = median_of_tail(
            [p["y"] for p in positions], times_ns, tail_window_s
        )
        peak_um = max((abs(v) for v in axis_positions), default=float("nan"))

        for row in rows:
            row["in_tail_window"] = bool(
                row.get("accepted") is True and int(row.get("host_ns") or 0) >= cutoff_ns
            )
            row["t_rel_s"] = (
                round((int(row["host_ns"]) - times_ns[0]) / 1e9, 6) if times_ns else ""
            )

        return ClipMeasurement(
            raw_path=clip.raw_path,
            frame_count=len(rows),
            n_valid=valid_count,
            measured_um=measured,
            transverse_um=transverse,
            n_tail=n_tail,
            sigma_tail_um=sigma_tail,
            peak_axis_um=peak_um,
            positions=positions,
            times_ns=times_ns,
            frame_rows=rows,
            first_row_ns=int(times_ns[0]) if times_ns else 0,
            last_row_ns=int(times_ns[-1]) if times_ns else 0,
            truncated=bool(clip.meta.get("truncated", False)),
        )


@dataclass
class ClipMeasurement:
    """一段临时 RAW 的逐帧测量结果。"""

    raw_path: Path
    frame_count: int
    n_valid: int
    measured_um: float | None
    transverse_um: float | None
    n_tail: int
    sigma_tail_um: float
    peak_axis_um: float
    positions: list[dict[str, float]]
    times_ns: list[int]
    frame_rows: list[dict[str, Any]]
    first_row_ns: int
    last_row_ns: int
    truncated: bool = False

    @property
    def detection_rate(self) -> float:
        """棋盘格有效识别率（含被接受判据剔除的帧）。"""

        if not self.frame_rows:
            return 0.0
        valid = sum(1 for row in self.frame_rows if row.get("checker_is_valid") is True)
        return valid / len(self.frame_rows)

    @property
    def accept_rate(self) -> float:
        """通过全部接受判据的比例。"""

        if not self.frame_rows:
            return 0.0
        accepted = sum(1 for row in self.frame_rows if row.get("accepted") is True)
        return accepted / len(self.frame_rows)

    @property
    def tail_static(self) -> bool:
        """
        尾部窗口自身是否足够静止。

        这是"这一轮测到的是停稳后的位置"的直接证据。编码器侧的稳定判据可能
        超时降级，而这里看的是**视觉数据本身**——闭环本来就该以视觉为准。
        """

        if self.n_tail < int(config.MICRO_LOOP_MIN_TAIL_FRAMES):
            return False
        if not math.isfinite(self.sigma_tail_um):
            return False
        return self.sigma_tail_um <= float(config.MICRO_LOOP_TAIL_SIGMA_MAX_UM)

    @property
    def is_usable(self) -> bool:
        """
        本轮测量能不能用来发命令。

        四个条件缺一不可：没被缓冲写满截断、尾部有足够多的合格帧、
        尾部确实静止、以及拿到的是一个有限的数值。
        """

        if self.truncated or self.measured_um is None:
            return False
        if not math.isfinite(float(self.measured_um)):
            return False
        return self.tail_static


def last_accepted_frame_index(measurement: "ClipMeasurement") -> int | None:
    """取最后一个通过接受判据的帧序号（即"停稳后"的代表帧）。"""

    for row in reversed(measurement.frame_rows):
        if row.get("accepted") is True:
            return int(row["frame_index"])
    return None


def peak_frame_index(
    measurement: "ClipMeasurement",
    *,
    axis: str = "X",
    reference_um: float = 0.0,
    target_um: float | None = None,
) -> int | None:
    """
    取本次迭代里偏离目标最远的那一帧（过冲或最大误差的代表帧）。

    输入：逐帧测量、被测轴、本组视觉零点、目标位置。
    输出：段内帧序号；没有合格帧时 None。

    偏离要相对**目标**而不是相对参考零点算：参考零点离目标可能有 50 μm，
    按它算的话每一帧的"峰值"都是同一帧，证据图就失去意义了。
    """

    key = "checker_dx_mm" if str(axis).upper() == "X" else "checker_dy_mm"
    best: tuple[float, int] | None = None
    for row in measurement.frame_rows:
        if row.get("accepted") is not True:
            continue
        value = row.get(key)
        if value in (None, ""):
            continue
        position = float(value) * 1000.0 - float(reference_um)
        deviation = (
            abs(position - float(target_um)) if target_um is not None else abs(position)
        )
        if best is None or deviation > best[0]:
            best = (deviation, int(row["frame_index"]))
    return None if best is None else best[1]


def save_evidence_png(clip: RawClip, frame_index: int, path: Path) -> bool:
    """
    保存一张全分辨率 PNG 证据帧（绝不用 JPEG）。

    输入：片段、段内帧序号、目标路径。
    输出：是否保存成功。
    """

    import cv2

    try:
        for index, _, frame in iter_clip_frames(clip, every_n=1):
            if index != int(frame_index):
                continue
            Path(path).parent.mkdir(parents=True, exist_ok=True)
            return bool(cv2.imwrite(str(path), frame))
        return False
    except Exception:
        return False


def analyze_static_clip(
    clip: RawClip,
    clip_measurement: ClipMeasurement,
    *,
    fps: float,
    record_start_ns: int,
    record_stop_ns: int,
) -> dict[str, Any]:
    """
    把静止基线的逐帧位移时序压成一份可以判读的统计。

    输入：片段、逐帧测量、帧率、录制起止。
    输出：含均值/中位数/标准差/峰峰值/帧数/识别率的字典。

    实验作用：确认去掉 MJPG 之后，全分辨率静止画面本身的微振动与视觉噪声有多少。
    这个数直接决定后面 3 μm 容差到底是不是在筛噪声。
    """

    accepted = [row for row in clip_measurement.frame_rows if row.get("accepted") is True]
    dx = np.asarray([float(row["checker_dx_mm"]) * 1000.0 for row in accepted], dtype=float)
    dy = np.asarray([float(row["checker_dy_mm"]) * 1000.0 for row in accepted], dtype=float)
    expected = expected_frames(record_start_ns, record_stop_ns, fps)
    actual = clip_measurement.frame_count
    tail_frames = max(1, int(round(float(config.MICRO_LOOP_TAIL_WINDOW_S) * float(fps))))

    def stats(values: np.ndarray) -> dict[str, Any]:
        if values.size == 0:
            return {
                "mean_um": None,
                "median_um": None,
                "std_um": None,
                "mad_sigma_um": None,
                "peak_to_peak_um": None,
            }
        return {
            "mean_um": float(values.mean()),
            "median_um": float(np.median(values)),
            "std_um": float(values.std()),
            "mad_sigma_um": mad_sigma(values.tolist()),
            "peak_to_peak_um": float(values.max() - values.min()),
        }

    return {
        "kind": "MICRO_CLOSED_LOOP_STATIC_BASELINE",
        "clip": str(clip_measurement.raw_path),
        "width": clip.width,
        "height": clip.height,
        "codec": "UNCOMPRESSED_RAW",
        "actual_frames": actual,
        "expected_frames": expected,
        "frame_ratio": (actual / expected) if expected else None,
        "valid_chessboard_frames": len(accepted),
        "chessboard_detection_rate": clip_measurement.detection_rate,
        "chessboard_accept_rate": clip_measurement.accept_rate,
        "x": stats(dx),
        "y": stats(dy),
        "est_sigma_um": estimate_measurement_sigma_um(dx.tolist(), tail_frames),
        "record_start_ns": int(record_start_ns),
        "record_stop_ns": int(record_stop_ns),
        "duration_s": (int(record_stop_ns) - int(record_start_ns)) / 1e9,
    }


# =============================================================================
# 3. 命令接缝：唯一的 μm → m 转换点
# =============================================================================

def _wait_until_position_stable(
    robot: Any,
    stop_event: Any,
    write_state: Callable[[dict[str, Any]], None],
    *,
    timeout_s: float,
    description: str,
) -> dict[str, Any] | None:
    """
    基于位置的稳定判据。超时返回 None，由调用方降级处理，不抛错。

    输入：机器人、停止事件、状态写盘回调、超时、描述。
    输出：稳定时的最后一条状态；超时返回 None。

    为什么不用 robot.motion_in_progress()：它带固定 200 ms 宽限期，
    是 5 μm 运动全程（约 14 ms）的 14 倍，对微动零信息量。

    为什么超时不致命：窗口取 5 μm 而不是既有微动实验的 1 μm，
    因为 CB3 的 actual_tcp_pose 由关节编码器换算，笛卡尔分辨率本身
    可能就有几 μm，1 μm 窗口可能永远无法满足。即便如此，超时也只降级为
    "按固定时间等一等"，真正的有效性由**视觉片段自身的窗内标准差**判定——
    闭环本来就该以视觉为准，编码器稳定性只是旁证。
    """

    window_ns = int(float(config.MICRO_LOOP_STABLE_WINDOW_MS) * 1_000_000)
    window_m = float(config.MICRO_LOOP_STABLE_WINDOW_UM) / 1_000_000.0
    speed_limit_m_s = float(config.MICRO_LOOP_STABLE_SPEED_MM_S) / 1000.0
    hold_ns = int(float(config.MICRO_LOOP_STABLE_HOLD_SECONDS) * 1_000_000_000)

    samples: deque[tuple[int, np.ndarray]] = deque()
    stable_since: int | None = None
    deadline = time.perf_counter() + float(timeout_s)

    while True:
        if stop_event.is_set():
            raise RuntimeError(f"{description}期间收到停止请求。")
        if time.perf_counter() >= deadline:
            return None

        state = robot.read_state()
        write_state(state)
        now_ns = int(state["host_ns"])
        position = np.asarray(state["actual_tcp_pose"][:3], dtype=float)
        samples.append((now_ns, position))
        while samples and samples[0][0] < now_ns - window_ns:
            samples.popleft()

        gap_m = max(
            (float(np.linalg.norm(position - other)) for _, other in samples), default=0.0
        )
        speed_values = state.get("actual_tcp_speed") or []
        speed_m_s = (
            float(np.linalg.norm(np.asarray(speed_values[:3], dtype=float)))
            if len(speed_values) >= 3
            else math.inf
        )

        if gap_m <= window_m and speed_m_s <= speed_limit_m_s:
            if stable_since is None:
                stable_since = now_ns
            elif now_ns - stable_since >= hold_ns:
                return state
        else:
            stable_since = None

        time.sleep(0.002)


def send_cartesian_micro_correction(
    robot: Any,
    axis: str,
    delta_um: float,
    *,
    stop_event: Any,
    write_state: Callable[[dict[str, Any]], None],
    settle_timeout_s: float | None = None,
) -> dict[str, Any]:
    """
    把一个 μm 级笛卡尔修正发下去。**这是本模块唯一的 μm → m 转换点。**

    输入：机器人、轴名（"X"/"Y"）、有符号修正量（μm）、停止事件、状态写盘回调。
    输出：含 tcp_before/tcp_after/achieved_um/transverse_um/status 的字典。

    为什么要单独封成一层：将来若要比较 MoveL 与 servoj，只需要替换这一个函数。
    它现在用的是与既有微动实验完全相同的链路——URRobot 的 MoveL，
    两点 Waypoint，validate_trajectory + verify_controller_safety_limits——
    不切换到任何新的执行接口。

    两个必须做对的细节：
    1. 轨迹必须是**两点**。robot.execute_trajectory 对长度 ≤1 的轨迹静默 no-op
       （它发送 trajectory[1:]），一点轨迹等于什么都没发。
    2. 发完必须验证命令真的下去了。execute_trajectory 在"成功"和"静默忽略"
       两条路径上都返回 None，唯一能区分的是 motion_command_time 有没有推进。
       检查这一项，才能把"控制器没理我"和"我根本没发出去"分开。
    """

    from robot import Waypoint, validate_trajectory

    axis = str(axis).upper()
    if axis not in AXIS_INDEX:
        raise ValueError(f"未知轴 {axis!r}，只能是 X 或 Y。")

    axis_index = AXIS_INDEX[axis]
    delta_m = float(delta_um) / 1_000_000.0
    if delta_m == 0.0:
        raise ValueError("修正量为 0 不应调用本函数；死区判断在 command_for_error 里做。")

    # 只读一次位姿：它同时充当记录用的 tcp_before、轨迹起点来源和 achieved 断言基线。
    # 读两次会让"实际位移"不等于指令 Δ——两次 RTDE 读之间隔几十微秒，
    # 而本实验的步长只有 5 μm。
    settled = _wait_until_position_stable(
        robot,
        stop_event,
        write_state,
        timeout_s=float(config.MICRO_LOOP_PRE_STABLE_TIMEOUT_S),
        description="微动前的稳定等待",
    )
    if settled is None:
        time.sleep(float(config.MICRO_LOOP_MOTION_SETTLE_SECONDS))

    before_state = robot.read_state()
    write_state(before_state)
    tcp_before = [float(value) for value in before_state["actual_tcp_pose"]]

    current = list(tcp_before)
    target = list(current)
    target[axis_index] = current[axis_index] + delta_m
    trajectory = [
        Waypoint(
            "P0",
            current,
            float(config.MICRO_LOOP_SPEED_MM_S) / 1000.0,
            float(config.MICRO_LOOP_ACCELERATION_M_S2),
            0.0,
        ),
        Waypoint(
            "P1",
            target,
            float(config.MICRO_LOOP_SPEED_MM_S) / 1000.0,
            float(config.MICRO_LOOP_ACCELERATION_M_S2),
            0.0,
        ),
    ]
    if len(trajectory) != 2:
        raise RuntimeError("内部错误：微动轨迹必须是两点。")
    validate_trajectory(trajectory, for_real_robot=True, pose_source="relative")
    robot.verify_controller_safety_limits(trajectory)

    command_start_ns = time.perf_counter_ns()
    stamp_before = robot.motion_command_time
    robot.execute_trajectory(trajectory)
    if robot.motion_command_time == stamp_before:
        raise RuntimeError(
            "moveL 被静默忽略：execute_trajectory 没有推进 motion_command_time。"
            "这通常意味着轨迹点被丢弃（例如只有一个路径点），本步未真正执行。"
        )

    timeout_s = (
        float(config.MICRO_LOOP_STEP_TIMEOUT_S)
        if settle_timeout_s is None
        else float(settle_timeout_s)
    )
    period = 1.0 / float(config.ROBOT_RECORD_HZ)
    deadline = time.perf_counter() + timeout_s
    while robot.motion_in_progress():
        if stop_event.is_set():
            robot.stop_motion()
            raise RuntimeError("闭环微动收到停止请求，已调用 stopL。")
        if time.perf_counter() >= deadline:
            robot.stop_motion()
            raise TimeoutError("单步微动超过超时上限，已调用 stopL。")
        write_state(robot.read_state())
        time.sleep(period)

    after_state = _wait_until_position_stable(
        robot,
        stop_event,
        write_state,
        timeout_s=float(config.MICRO_LOOP_POST_STABLE_TIMEOUT_S),
        description="微动后的稳定等待",
    )
    settle_ok = after_state is not None
    if after_state is None:
        time.sleep(float(config.MICRO_LOOP_MOTION_SETTLE_SECONDS))
        after_state = robot.read_state()
        write_state(after_state)

    tcp_after = [float(value) for value in after_state["actual_tcp_pose"]]
    achieved_um = (tcp_after[axis_index] - tcp_before[axis_index]) * 1_000_000.0
    transverse = [
        tcp_after[index] - tcp_before[index] for index in range(3) if index != axis_index
    ]
    transverse_um = float(np.linalg.norm(np.asarray(transverse, dtype=float))) * 1_000_000.0

    status, note = evaluate_achieved_robot_side(float(delta_um), achieved_um)
    return {
        "command_start_ns": command_start_ns,
        "command_end_ns": int(after_state["host_ns"]),
        "tcp_before": tcp_before,
        "tcp_after": tcp_after,
        "achieved_um": achieved_um,
        "expected_um": float(delta_um),
        "transverse_um": transverse_um,
        "settle_ok": settle_ok,
        "status": status,
        "note": note,
    }


def evaluate_achieved_robot_side(delta_um: float, achieved_um: float) -> tuple[str, str]:
    """
    在机器人一侧判断这一步是否真的按指令走了。

    输入：指令位移、实测位移（都由 actual_tcp_pose 得出，μm）。
    输出：(状态码, 说明)。

    与视觉侧的 measured_um 并排，就得到本次实验最有用的三分表：
      机器人没动 + 视觉没看到 → 控制器忽略了命令（最小有效运动尺度）
      机器人动了 + 视觉没看到 → 机械柔性/夹具间隙吸收，或视觉噪声底
      机器人动了 + 视觉看到但量不对 → 增益误差或交叉耦合
    """

    magnitude = abs(float(delta_um))
    got = abs(float(achieved_um))
    if magnitude <= 0.0:
        return STEP_VALID, ""

    low = max(float(config.MICRO_LOOP_ACHIEVED_FLOOR_UM),
              float(config.MICRO_LOOP_ACHIEVED_MIN_RATIO) * magnitude)
    high = float(config.MICRO_LOOP_ACHIEVED_MAX_RATIO) * magnitude + float(
        config.MICRO_LOOP_ACHIEVED_SLACK_UM
    )
    if got < low:
        return STEP_SMALL, f"实测位移 {achieved_um:+.2f} μm 低于下限 {low:.2f} μm。"
    if got > high:
        return STEP_LARGE, f"实测位移 {achieved_um:+.2f} μm 高于上限 {high:.2f} μm。"
    if got >= float(config.MICRO_LOOP_ACHIEVED_FLOOR_UM) and (
        (float(achieved_um) > 0.0) != (float(delta_um) > 0.0)
    ):
        return STEP_SIGN, (
            f"指令 {delta_um:+.2f} μm 但实测 {achieved_um:+.2f} μm，方向相反；"
            "检查基座/工具坐标系或轴符号。"
        )
    return STEP_VALID, ""


# =============================================================================
# 4. 临时文件管理（Windows 句柄是真实风险）
# =============================================================================

def temp_workspace(output_root: Path) -> tuple[Path, Path]:
    """
    返回临时文件目录和回收目录。

    输入：输出根目录。
    输出：(临时目录, 回收目录)。

    两者都放在输出根目录下（与运行目录同一个卷），
    这样 os.replace 是原子的、不跨卷，而且**运行目录里永远不会出现视频文件**——
    即使进程崩溃，运行目录也是干净的。
    """

    output_root = Path(output_root)
    return output_root / TEMP_DIR_NAME, output_root / TRASH_DIR_NAME


def prepare_temp_workspace(output_root: Path) -> tuple[Path, Path]:
    """
    实验开始时建立并清空临时工作区。

    输入：输出根目录。
    输出：(临时目录, 回收目录)。

    只在**启动时**清空。循环中途绝不清空——那会把别人正在用的文件删掉。
    """

    temp_dir, trash_dir = temp_workspace(output_root)
    for path in (temp_dir, trash_dir):
        path.mkdir(parents=True, exist_ok=True)
    sweep_directory(trash_dir)
    return temp_dir, trash_dir


def sweep_directory(path: Path) -> int:
    """尽力删除目录下的所有文件，返回释放的字节数。"""

    released = 0
    path = Path(path)
    if not path.exists():
        return 0
    for entry in path.iterdir():
        try:
            if entry.is_file():
                released += int(entry.stat().st_size)
                entry.unlink()
        except OSError:
            continue
    return released


def directory_bytes(path: Path) -> int:
    """统计目录下所有文件的总字节数。"""

    total = 0
    path = Path(path)
    if not path.exists():
        return 0
    for entry in path.iterdir():
        try:
            if entry.is_file():
                total += int(entry.stat().st_size)
        except OSError:
            continue
    return total


def drop_temp_files(paths: Sequence[Path], trash_dir: Path, *, log: Callable[[str], None] | None = None) -> None:
    """
    把临时文件移进回收目录，而不是直接删除。

    输入：文件路径列表、回收目录、可选日志回调。

    为什么用移动而不是 unlink：np.memmap 持有文件句柄，CPython 不保证
    在 del / 关闭之后立刻释放，WinError 32（文件被占用）会随机出现。
    在一个 200 多次迭代的循环里，这意味着第 137 次把整轮弄死。
    移到同卷的回收目录是原子的、不依赖句柄是否已经释放。
    回收目录在实验结束时统一清空。

    调用前必须已经关闭所有句柄，并且已经把该轮结果 flush + fsync 落盘——
    否则中途崩溃会同时丢掉数据和文件。
    """

    trash_dir = Path(trash_dir)
    trash_dir.mkdir(parents=True, exist_ok=True)
    for path in paths:
        path = Path(path)
        if not path.exists():
            continue
        moved = False
        for attempt in range(10):
            try:
                os.replace(str(path), str(trash_dir / path.name))
                moved = True
                break
            except PermissionError:
                gc.collect()
                time.sleep(0.1)
            except OSError:
                gc.collect()
                time.sleep(0.1)
        if not moved:
            if log is not None:
                log(f"临时文件无法释放（句柄未释放）：{path}")
            continue

    quota_bytes = int(float(config.MICRO_LOOP_TRASH_QUOTA_GB) * (1024 ** 3))
    used = directory_bytes(trash_dir)
    if used > quota_bytes:
        raise RuntimeError(
            f"临时文件回收目录已达 {format_gib(used)}，超过配额 "
            f"{float(config.MICRO_LOOP_TRASH_QUOTA_GB):g} GiB。"
            "这说明临时文件没有按预期释放，继续下去会写满磁盘，已安全终止。"
        )


def clip_temp_paths(temp_dir: Path, stem: str) -> dict[str, Path]:
    """
    一段临时录制的三个文件路径。

    输入：临时目录、文件名主干。
    输出：{raw, meta, frames}。
    """

    temp_dir = Path(temp_dir)
    return {
        "raw": temp_dir / f"{stem}.raw",
        "meta": temp_dir / f"{stem}_raw_meta.json",
        "frames": temp_dir / f"{stem}_frames.csv",
    }


def next_clip_stem(run_id: str, label: str, counter: int) -> str:
    """生成唯一的临时片段名，避免任何形式的覆盖。"""

    safe = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in str(label))
    return f"{run_id}_{safe}_{int(counter):05d}"


# =============================================================================
# 5. 相机进程：内存缓冲 → 未压缩 RAW（无编码器、无手电筒门禁）
# =============================================================================

def _closed_loop_camera_status(status_queue: Any, event: str, **extra: Any) -> None:
    """向主进程发一条相机状态确认。"""

    status_queue.put(
        {"source": "camera", "event": event, "host_ns": time.perf_counter_ns(), **extra},
        timeout=1.0,
    )


def micro_closed_loop_camera_worker(
    error_queue: Any,
    command_queue: Any,
    status_queue: Any,
    stop_event: Any,
) -> None:
    """
    闭环微动的相机子进程：一次连接，按窗口把帧缓冲进内存再落盘。

    输入：错误队列、命令队列、状态队列、停止事件。
    输出：每个窗口一个 `{stem}.raw` + `{stem}_frames.csv` + `{stem}_raw_meta.json`（都是临时文件）。

    命令：
    - OPEN_WINDOW：开始把帧写进内存缓冲；
    - CLOSE_WINDOW：停止采集，把缓冲落盘成未压缩 RAW 并回报 WINDOW_SAVED；
    - SHUTDOWN：收尾退出。

    为什么不是边采边写盘：实测全幅 1936×1464 实时写盘每帧均值 2.27 ms、
    峰值 7.38 ms，而相机周期 7.56 ms —— 会丢 6.11% 的帧。memcpy 进内存约 0.3 ms，
    余量 25 倍。所以采集阶段只做"取帧 + 拷贝"，识别与落盘全部挪到片段结束之后。

    为什么在片段之间仍然持续取帧：MVS SDK 的节点队列会积压，
    下一次开录时就会拿到运动之前拍到的陈旧帧。持续取帧并丢弃是唯一可靠的做法，
    与 batch_camera_worker 的空闲预览一致。
    """

    import cv2

    from camera import HikCameraSource, _resize_for_preview

    buffer: np.ndarray | None = None
    active: dict[str, Any] | None = None
    previous_frame_id: int | None = None
    preview_last_ns = 0
    preview_period_ns = int(1_000_000_000 / float(config.MICRO_LOOP_PREVIEW_FPS))
    preview_window_name = "UR10 micro closed-loop camera"

    def close_window() -> None:
        """封口当前窗口：把内存缓冲落盘成未压缩 RAW，写旁车文件，回报主程序。"""

        nonlocal active, buffer, previous_frame_id
        if active is None:
            raise RuntimeError("没有可关闭的相机窗口。")

        width = int(active["width"])
        height = int(active["height"])
        frame_count = int(active["count"])
        raw_path: Path = active["raw_path"]
        frames_path: Path = active["frames_path"]
        meta_path: Path = active["meta_path"]

        with raw_path.open("xb") as raw_file:
            if frame_count and buffer is not None:
                raw_file.write(memoryview(buffer[:frame_count]).cast("B"))
        bytes_written = int(raw_path.stat().st_size)
        expected_bytes = frame_count * width * height
        if bytes_written != expected_bytes:
            raise RuntimeError(
                f"RAW 文件大小与帧数不一致：{raw_path.name} 实际 {bytes_written} 字节，"
                f"按 {frame_count} 帧 × {width}×{height} 应为 {expected_bytes} 字节。"
            )

        meta = {
            "kind": "MICRO_CLOSED_LOOP_RAW_META",
            "clip_label": active["clip_label"],
            "raw_path": str(raw_path),
            "width": width,
            "height": height,
            "dtype": "uint8",
            "frame_count": frame_count,
            "bytes_written": bytes_written,
            "expected_bytes": expected_bytes,
            "first_frame_id": active["first_frame_id"],
            "last_frame_id": active["last_frame_id"],
            "record_start_ns": active["record_start_ns"],
            "record_stop_ns": active["record_stop_ns"],
            "camera_actual_fps": active["camera_fps"],
            "buffer_capacity": int(active["capacity"]),
            "truncated": bool(active["truncated"]),
            "dropped_after_full": int(active["dropped"]),
            "readme": (
                "离线读取：np.memmap(raw_path, dtype=np.uint8, mode='r', "
                f"shape=(frame_count, {height}, {width}))。"
                "未压缩位精确数据，不含任何有损编码；本文件是临时文件，处理完即删。"
            ),
        }
        meta_path.write_text(
            json.dumps(meta, ensure_ascii=False, indent=2, allow_nan=True), encoding="utf-8"
        )

        _closed_loop_camera_status(
            status_queue,
            "WINDOW_SAVED",
            clip_label=active["clip_label"],
            raw_path=str(raw_path),
            frames_path=str(frames_path),
            meta_path=str(meta_path),
            width=width,
            height=height,
            frame_count=frame_count,
            bytes_written=bytes_written,
            first_frame_id=active["first_frame_id"],
            last_frame_id=active["last_frame_id"],
            record_start_ns=active["record_start_ns"],
            record_stop_ns=active["record_stop_ns"],
            camera_actual_fps=active["camera_fps"],
            truncated=bool(active["truncated"]),
            dropped_after_full=int(active["dropped"]),
        )
        active = None
        # 落盘可能耗时上百毫秒；下一帧属于窗口间空闲期，不把落盘耗时误判成丢帧。
        previous_frame_id = None

    try:
        if config.SHOW_PREVIEW:
            cv2.namedWindow(preview_window_name)

        with HikCameraSource() as source:
            iterator = iter(source)
            fps = float(source.actual_camera_fps or config.EXPECTED_VISION_FPS or 30.0)

            warmup_start_ns: int | None = None
            first = None
            warmup_frames = 0
            print(
                f"[状态] 工业相机正在预热 {config.MICRO_LOOP_CAMERA_WARMUP_SECONDS:g} 秒，"
                "初始化预览并排空启动帧",
                flush=True,
            )
            while first is None:
                packet = next(iterator)
                if stop_event.is_set():
                    return
                warmup_frames += 1
                if warmup_start_ns is None:
                    warmup_start_ns = int(packet.host_ns)
                if (
                    config.SHOW_PREVIEW
                    and int(packet.host_ns) - preview_last_ns >= preview_period_ns
                ):
                    preview_last_ns = int(packet.host_ns)
                    cv2.imshow(
                        preview_window_name,
                        _resize_for_preview(
                            packet.frame, max_width=int(config.MICRO_LOOP_PREVIEW_MAX_WIDTH)
                        ),
                    )
                    if cv2.waitKey(1) & 0xFF in (27, ord("q")):
                        raise RuntimeError("相机预览窗口收到 q/Esc。")
                if (
                    int(packet.host_ns) - warmup_start_ns
                    >= int(float(config.MICRO_LOOP_CAMERA_WARMUP_SECONDS) * 1_000_000_000)
                ):
                    first = packet

            full_height, full_width = int(first.frame.shape[0]), int(first.frame.shape[1])
            _closed_loop_camera_status(
                status_queue,
                "READY",
                actual_camera_fps=fps,
                full_width=full_width,
                full_height=full_height,
                warmup_frames=warmup_frames,
            )
            print(
                f"[状态] 工业相机预热完成（排空 {warmup_frames} 帧），"
                f"实际帧率约 {fps:.3f} fps，全幅 {full_width}×{full_height}"
                "（不裁剪、不缩放，保留完整分辨率）",
                flush=True,
            )

            for packet in (item for pair in ((first,), iterator) for item in pair):
                if stop_event.is_set():
                    break
                frame = packet.frame

                while True:
                    try:
                        command = command_queue.get_nowait()
                    except Empty:
                        break
                    action = str(command.get("action", ""))
                    if action == "SHUTDOWN":
                        stop_event.set()
                        break
                    if action == "OPEN_WINDOW":
                        if active is not None:
                            raise RuntimeError("上一段相机窗口尚未关闭。")
                        paths = clip_temp_paths(Path(command["temp_dir"]), str(command["stem"]))
                        for key in ("raw", "meta", "frames"):
                            if paths[key].exists():
                                raise FileExistsError(f"拒绝覆盖相机输出：{paths[key]}")
                        capacity = int(command["capacity_frames"])
                        if buffer is None or int(buffer.shape[0]) < capacity:
                            # 只分配一次，之后所有窗口复用同一块内存。
                            buffer = np.empty((capacity, full_height, full_width), dtype=np.uint8)
                        frames_file = paths["frames"].open(
                            "x", encoding="utf-8-sig", newline="", buffering=262_144
                        )
                        frames_writer = csv.DictWriter(
                            file=frames_file, fieldnames=list(RAW_FRAME_COLUMNS)
                        )
                        frames_writer.writeheader()
                        active = {
                            "clip_label": str(command.get("clip_label", "")),
                            "raw_path": paths["raw"],
                            "meta_path": paths["meta"],
                            "frames_path": paths["frames"],
                            "frames_file": frames_file,
                            "frames_writer": frames_writer,
                            "width": full_width,
                            "height": full_height,
                            "capacity": capacity,
                            "count": 0,
                            "truncated": False,
                            "dropped": 0,
                            "first_frame_id": None,
                            "last_frame_id": None,
                            "record_start_ns": None,
                            "record_stop_ns": None,
                            "camera_fps": fps,
                        }
                        previous_frame_id = None
                        _closed_loop_camera_status(
                            status_queue,
                            "WINDOW_OPENED",
                            clip_label=active["clip_label"],
                            width=full_width,
                            height=full_height,
                            capacity=capacity,
                        )
                    elif action == "CLOSE_WINDOW":
                        close_window()
                    else:
                        raise ValueError(f"未知相机命令：{action!r}")

                if active is not None and buffer is not None:
                    gray = frame if frame.ndim == 2 else cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                    if gray.dtype != np.uint8:
                        raise RuntimeError(f"闭环微动只支持 uint8 帧，实际 dtype={gray.dtype}。")
                    if gray.shape != (full_height, full_width):
                        raise RuntimeError(
                            f"帧尺寸在实验中途变化：{gray.shape} vs "
                            f"({full_height}, {full_width})，数据不可用。"
                        )
                    # 唯一在采集路径上的操作：一次 memcpy。不做灰度转换之外的任何处理。
                    if int(active["count"]) >= int(active["capacity"]):
                        # 缓冲写满：**不是致命错误，也绝不静默丢弃**。
                        # RAW 与逐帧 CSV 必须等长，所以两者一起停写，并如实计数上报。
                        # 上层看到 truncated 就把这一轮标成 MEASUREMENT_LOST 继续跑，
                        # 因为正常窗口（约 2 s）离上限（6 s）还有 3 倍余量，
                        # 真写满说明机械臂在反复拖长稳定等待，那是被测现象的一部分。
                        if not active["truncated"]:
                            active["truncated"] = True
                            print(
                                f"[状态] 相机缓冲写满（{active['capacity']} 帧），"
                                f"本段后续帧不再记录；这一轮将标记为测量丢失。",
                                flush=True,
                            )
                        active["dropped"] = int(active["dropped"]) + 1
                    else:
                        buffer[int(active["count"])] = gray
                        active["frames_writer"].writerow(
                            {
                                "segment_frame_index": int(active["count"]),
                                "frame_id": int(packet.frame_id),
                                "host_ns": int(packet.host_ns),
                                "camera_timestamp_raw": packet.camera_timestamp_raw,
                            }
                        )
                        if active["first_frame_id"] is None:
                            active["first_frame_id"] = int(packet.frame_id)
                            active["record_start_ns"] = int(packet.host_ns)
                        active["last_frame_id"] = int(packet.frame_id)
                        active["record_stop_ns"] = int(packet.host_ns)
                        active["count"] = int(active["count"]) + 1
                    previous_frame_id = int(packet.frame_id)

                if (
                    config.SHOW_PREVIEW
                    and int(packet.host_ns) - preview_last_ns >= preview_period_ns
                ):
                    preview_last_ns = int(packet.host_ns)
                    cv2.imshow(
                        preview_window_name,
                        _resize_for_preview(
                            frame, max_width=int(config.MICRO_LOOP_PREVIEW_MAX_WIDTH)
                        ),
                    )
                    if cv2.waitKey(1) & 0xFF in (27, ord("q")):
                        raise RuntimeError("相机预览窗口收到 q/Esc。")
    except StopIteration:
        try:
            error_queue.put("闭环微动相机没有返回任何图像。", timeout=1.0)
        except Exception:
            pass
        stop_event.set()
    except Exception as exc:
        try:
            error_queue.put(f"闭环微动相机进程异常：{type(exc).__name__}: {exc}", timeout=1.0)
        except Exception:
            pass
        stop_event.set()
    finally:
        if active is not None:
            try:
                active["frames_file"].close()
            except Exception:
                pass
        cv2.destroyAllWindows()


# =============================================================================
# 6. 机器人进程：单点 moveL 微动 + 基于位置的稳定判据
# =============================================================================

def _closed_loop_robot_status(status_queue: Any, event: str, **extra: Any) -> None:
    """向主进程发一条机器人状态确认。"""

    status_queue.put(
        {"source": "robot", "event": event, "host_ns": time.perf_counter_ns(), **extra},
        timeout=1.0,
    )


def micro_closed_loop_robot_worker(
    error_queue: Any,
    command_queue: Any,
    status_queue: Any,
    stop_event: Any,
    run_dir: Path,
) -> None:
    """
    闭环微动的机器人子进程：一次连接，按命令执行单轴微动。

    输入：错误/命令/状态队列、停止事件、运行目录。
    输出：`robot_log.csv`（125 Hz 全速率状态）和每条命令的确认消息。

    命令：
    - STABILIZE：等位置稳定（不运动），用于每组开始前把画面定住；
    - MOVE：执行一次 μm 级修正（走 send_cartesian_micro_correction 这一层）；
    - RETURN_START：低速返回实验初始位姿并稳定；
    - SHUTDOWN：收尾退出。
    """

    from robot import (
        URRobot,
        _dashboard_safety_status_is_normal,
        _rtde_safety_mode_is_normal,
        _tcp_speed_norm_m_s,
    )

    robot = URRobot()
    start_pose: list[float] | None = None
    active_file: Any = None
    period = 1.0 / float(config.ROBOT_RECORD_HZ)

    def write_state(state: dict[str, Any]) -> None:
        """把一条 125 Hz 状态写进 robot_log.csv。"""

        if active_file is None:
            return
        pose = list(state.get("actual_tcp_pose") or [None] * 6)
        speed = list(state.get("actual_tcp_speed") or [None] * 6)
        active_file.write(
            ",".join(
                str(value)
                for value in (
                    int(state["host_ns"]),
                    state.get("robot_timestamp_s"),
                    state.get("robot_mode"),
                    state.get("safety_mode"),
                    *pose,
                    *speed,
                )
            )
            + "\n"
        )

    def stabilise(description: str) -> bool:
        """等位置稳定；超时降级为固定等待并如实回报。"""

        settled = _wait_until_position_stable(
            robot,
            stop_event,
            write_state,
            timeout_s=float(config.MICRO_LOOP_STABLE_TIMEOUT_S),
            description=description,
        )
        if settled is None:
            time.sleep(float(config.MICRO_LOOP_MOTION_SETTLE_SECONDS))
            return False
        return True

    try:
        if not config.ROBOT_RELATIVE_MOTION_ENABLED:
            raise PermissionError(
                "ROBOT_RELATIVE_MOTION_ENABLED=False，XY 微动闭环测试被锁定。"
            )

        robot.connect(require_control=True)
        state = robot.read_state()
        write_state(state)

        dashboard_normal = _dashboard_safety_status_is_normal(robot.read_dashboard_status())
        rtde_normal = _rtde_safety_mode_is_normal(state)
        if dashboard_normal is False or rtde_normal is False:
            raise RuntimeError("机器人安全状态不是 NORMAL，拒绝开始自动微动。")
        if _tcp_speed_norm_m_s(state) > float(config.ROBOT_EXPERIMENT_STOP_SPEED_MM_S) / 1000.0:
            raise RuntimeError("机器人当前不处于静止状态，拒绝开始自动微动。")

        start_pose = [float(value) for value in robot.current_tcp_pose()]
        active_file = (Path(run_dir) / "robot_log.csv").open(
            "x", encoding="utf-8", newline="", buffering=262_144
        )
        active_file.write(
            ",".join(
                ["host_ns", "robot_timestamp_s", "robot_mode", "safety_mode"]
                + [f"tcp_{name}" for name in ("x", "y", "z", "rx", "ry", "rz")]
                + [f"tcp_speed_{name}" for name in ("x", "y", "z", "rx", "ry", "rz")]
            )
            + "\n"
        )
        active_file.flush()

        _closed_loop_robot_status(
            status_queue, "READY", start_pose=start_pose, safety=state.get("safety_mode")
        )
        print(
            f"[状态] UR10 已连接并确认静止，实验初始 TCP 位姿 "
            f"({start_pose[0]:.6f}, {start_pose[1]:.6f}, {start_pose[2]:.6f}) m",
            flush=True,
        )

        while not stop_event.is_set():
            try:
                command = command_queue.get(timeout=0.2)
            except Empty:
                continue
            action = str(command.get("action", ""))

            if action == "SHUTDOWN":
                break

            if action == "STABILIZE":
                ok = stabilise("闭环微动前的稳定等待")
                _closed_loop_robot_status(
                    status_queue,
                    "STABILIZED",
                    settle_ok=ok,
                    pose=[float(value) for value in robot.current_tcp_pose()],
                )
                continue

            if action == "MOVE":
                axis = str(command["axis"])
                delta_um = float(command["delta_um"])
                result = send_cartesian_micro_correction(
                    robot,
                    axis,
                    delta_um,
                    stop_event=stop_event,
                    write_state=write_state,
                )
                _closed_loop_robot_status(
                    status_queue,
                    "MOVE_DONE",
                    axis=axis,
                    delta_um=delta_um,
                    achieved_um=result["achieved_um"],
                    tcp_before=result["tcp_before"],
                    tcp_after=result["tcp_after"],
                    transverse_um=result["transverse_um"],
                    settle_ok=result["settle_ok"],
                    command_start_ns=result["command_start_ns"],
                    command_end_ns=result["command_end_ns"],
                    command_status=result["status"],
                    note=result["note"],
                )
                continue

            if action == "RETURN_START":
                if start_pose is None:
                    raise RuntimeError("尚未记录实验初始位姿，无法返回。")
                from robot import Waypoint, validate_trajectory

                current = [float(value) for value in robot.current_tcp_pose()]
                trajectory = [
                    Waypoint(
                        "P0",
                        current,
                        float(config.MICRO_LOOP_RETURN_SPEED_MM_S) / 1000.0,
                        float(config.MICRO_LOOP_ACCELERATION_M_S2),
                        0.0,
                    ),
                    Waypoint(
                        "P1",
                        list(start_pose),
                        float(config.MICRO_LOOP_RETURN_SPEED_MM_S) / 1000.0,
                        float(config.MICRO_LOOP_ACCELERATION_M_S2),
                        0.0,
                    ),
                ]
                validate_trajectory(trajectory, for_real_robot=True, pose_source="relative")
                robot.verify_controller_safety_limits(trajectory)
                robot.execute_trajectory(trajectory)
                deadline = time.perf_counter() + float(config.ROBOT_MOTION_TIMEOUT_S)
                while robot.motion_in_progress():
                    if stop_event.is_set():
                        robot.stop_motion()
                        break
                    if time.perf_counter() >= deadline:
                        robot.stop_motion()
                        raise TimeoutError("返回实验初始位姿超时，已调用 stopL。")
                    write_state(robot.read_state())
                    time.sleep(period)
                settle_ok = stabilise("返回实验初始位姿后的稳定等待")
                final_pose = [float(value) for value in robot.current_tcp_pose()]
                drift_mm = float(
                    np.linalg.norm(
                        np.asarray(final_pose[:3], dtype=float)
                        - np.asarray(start_pose[:3], dtype=float)
                    )
                    * 1000.0
                )
                _closed_loop_robot_status(
                    status_queue,
                    "RETURNED",
                    pose=final_pose,
                    drift_mm=drift_mm,
                    settle_ok=settle_ok,
                )
                continue

            raise ValueError(f"未知机器人命令：{action!r}")

    except Exception as exc:
        try:
            error_queue.put(f"闭环微动机器人进程异常：{type(exc).__name__}: {exc}", timeout=1.0)
        except Exception:
            pass
        stop_event.set()
    finally:
        if active_file is not None:
            try:
                active_file.close()
            except Exception:
                pass
        try:
            robot.stop_motion()
        except Exception:
            pass
        try:
            robot.disconnect()
        except Exception:
            pass
