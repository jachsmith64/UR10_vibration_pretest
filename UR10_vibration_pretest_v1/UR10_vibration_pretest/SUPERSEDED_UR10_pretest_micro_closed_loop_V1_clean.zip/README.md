# UR10 预实验工程 — 本轮版本说明（一键 XY 微动闭环能力测试）

本包是 `UR10_vibration_pretest` 的源码交付包，供人工或其它模型复核本轮新增的
**一键 XY 微动闭环能力测试（`micro_closed_loop`）**。根目录扁平，全部源码在根下，
单测在 `tests/`，不含任何输出数据与图片。

**本轮是替换，不是叠加**：上一轮的 `micro_motion_experiment`（11 档位开环微动）
与其导出工具 `micro_motion_export.py` 已**完全删除**，相关单测一并删除。
若你在别处看到这两个名字，那份代码已经过时。

---

## 1. 这个实验要回答什么

**UR10 CB3 在视觉反馈下，能否通过反复小幅纠偏逼近 5 / 20 / 50 μm 的目标？
如果不能，是不是因为存在一个"最小有效运动尺度"，导致误差冻结在一个恒定值上？**

做法是"走一步 → 停稳 → 测量 → 再走一步"的慢速离散闭环。刻意不做轨迹规划、
不做 MPC、不做 PID、不做自适应增益——用最朴素的比例律
`command = Kp · error`（Kp = 1.0）把机械臂本身的能力边界测出来。

产出的核心**不是最终误差**，而是**完整迭代序列**（例如
`0 → +13 → −2 → +12 → −1 → +14 → …`）与**每条真实命令 ↔ 真实视觉响应的对应**。
据此可以反推：UR10 收到 2 / 3 / 5 / 8 / 10 μm 的命令时，实际移动了多少。

### 与上一轮被舍弃方案的区别

| | 旧 `micro_motion_experiment` | 本轮 `micro_closed_loop` |
|---|---|---|
| 结构 | 开环，11 个预设档位 | **闭环**，迭代逼近，最多 20 次/目标 |
| 目标 | 看清各档位响应 | 判**能否收敛**、是否形成**持续极限环** |
| 幅值 | 11 档（200…5 μm） | 3 档（5 / 20 / 50 μm）× 2 方向 × 2 轴 = **12 目标** |
| 参考 | 每段独立 | 每个幅值组锁定一次视觉参考，组内 ± 共用 |

闭环迭代会自然产生大量不同幅值的小命令，比开环档位表信息量更大。

---

## 2. 一次运行会做什么

```
前置门禁 → 磁盘检查 → 机器人+相机启动与预热 → 5 s 全分辨率静止基线
→ ★ 轴向/符号探针（自动测出视觉↔机器人的对应与正负号）
→ for 轴 in (X, Y):
     for 幅值 in (5, 20, 50):
        建视觉参考（组内只建一次）
        for 方向 in (+1, −1):
            闭环迭代 k = 1..20：
              误差 → 比例律 → (可选)发微动命令 → 录一段连续片段
              → 逐帧棋盘格测量 → 取尾部中位数 → 存数据 → 判终止
   每换一个幅值回到初始位姿
→ 全部完成：回到初始位姿 → 汇总 master_summary.csv
```

### 终止状态

| 状态 | 含义 |
|---|---|
| `CONVERGED` | 连续 3 次误差落在有效容差内 |
| `CONVERGED_NOISE_LIMITED` | 收敛了，但残差与零在统计上不可分（信噪比 < 2） |
| `LIMIT_CYCLE` | 真极限环：反复换号，且峰峰值与中位幅值都不再收缩 |
| `STALLED_MIN_EFFECTIVE_MOTION` | **单边不收缩的平台**——控制器忽略了小于阈值的命令 |
| `DIVERGING` | 近期中位幅值 > 前窗 1.2 倍 |
| `MAX_ITER` / `MEASUREMENT_LOST` / `ABORTED` | 到顶 / 测不到 / 联锁中止 |

`STALLED_MIN_EFFECTIVE_MOTION` 这个桶是必需的：5 μm 档最可能出现的结果其实是
**单边平台**（误差冻结在一个恒定值、一次号都不换），而"换号 + 峰峰值不缩"
的原始判据永远不会触发，最后只会报 `MAX_ITER`——那完全掩盖了"存在最小有效运动
尺度"这个结论。

### 两道防早期误判的门

1. **先过噪声底**：误差已经低到噪声量级时的换号是噪声，不是极限环。
2. **先过"无进展"**：必须至少走到路程一半，才允许判极限环。这杀掉"误差还很大
   但在单调收缩"的早期误判。

另有一道用来区分"增益略大于 1 的**收敛**振荡"与"真极限环"：收敛振荡的 6 步包络
会缩到 `|1−Kp·g|⁶`（`Kp·g = 1.5` 时是 0.016），远低于阈值 0.7。**这三条都有单测**。

### 收敛验证（零命令复测）

判 `CONVERGED` 后不再发任何命令，再录一段静止片段比对：`|复测 − 残差| ≤ 2σ`
才算真不动点，否则重开闭环（最多 3 次，**不重置迭代预算**，所以不会拖长总时长）。
`converged_verified` 列写进汇总。这是唯一能把"真不动点"与"运气好落进去"分开的动作。

### 运行期联锁（防闭环发散）

- 连续 2 次指令与实测方向相反 → 中止（`SIGN_INVERTED`）
- 组累计指令量超过 2000 μm → 中止（`WALKED_AWAY`）
- **每次修正后**跑一次全局漂移守卫（以组起始位姿为基准）→ 越限中止
- 连续 2 轮测量丢失 → 中止该目标
- `DIVERGING` 由终止判据本身报出

`WALKED_AWAY` 与漂移守卫是必要的：`robot.validate_trajectory` 的 ±0.20 m
相对工作区在**每次调用时都以当时位姿重新锚定**（`robot.py:215-220`），
结构上无法察觉缓慢的棘轮式走位。

---

## 3. 输出目录

```
outputs/micro_motion_<YYYYmmdd_HHMMSS>/
├─ config.json            本次运行的全部生效参数
├─ master_summary.csv     每个目标一行（全部列见下）
├─ experiment_log.txt
├─ static/{static_frames.csv, static_summary.json, evidence/*.png}
└─ X/005um/  X/020um/  X/050um/  Y/005um/  Y/020um/  Y/050um/
     ├─ positive_iterations.csv / negative_iterations.csv
     ├─ positive_frames.csv     / negative_frames.csv
     ├─ positive_summary.json   / negative_summary.json
     └─ evidence/*.png
```

**实验结束后目录中不存在任何完整视频**（没有 `.mkv` / `.avi` / `.raw`）。
临时 RAW 只存在于 `outputs/_micro_temp/`，用完即移入 `outputs/_micro_trash/`
并在启动时与结束时各清空一次。

### 关键交付列

`*_iterations.csv`（每轮一行）——**这四列并排就是本次实验的科学核心**：

```
iteration_id, axis, direction, target_amplitude_um, target_um,
measured_position_um,      ← 视觉侧：停稳后测到的位置
error_before_um, command_um,
achieved_robot_um,         ← 机器人侧：编码器实测位移
actual_visual_displacement_um,
error_after_um, robot_tcp_before, robot_tcp_after, transverse_um,
g_obs,                     ← 有效环路增益 = Δ实测 / Δ指令
n_valid_frames, n_tail_frames, sigma_tail_um,
timestamp, step_status, termination_state, note
```

`achieved_robot_um` 与 `actual_visual_displacement_um` 并排，直接给出三分表：

| 机器人动了吗 | 视觉看到了吗 | 结论 |
|---|---|---|
| 没动 | 没看到 | 控制器忽略了命令 → **最小有效运动尺度** |
| 动了 | 没看到 | 机械柔性 / 夹具间隙吸收，或视觉噪声底 |
| 动了 | 看到但量不对 | 增益误差 / 交叉耦合 |

`*_frames.csv`（每帧一行，离线重算无需视频）：

```
iteration_id, frame_index, frame_id, host_ns, t_rel_s, camera_timestamp_raw,
checker_dx_mm, checker_dy_mm, checker_is_valid, accepted,
checker_quality, checker_residual_px, checker_angle_deg, checker_scale,
checker_found_by, in_tail_window
```

`master_summary.csv` 含 `termination_state` / `final_abs_error_um` /
`smallest_command_issued_um` / `corresponding_actual_motion_um` /
`residual_snr` / `est_sigma_um` / `limit_cycle_amplitude_um` / `plateau_um` /
`min_effective_motion_limit_um` / `drift_um_per_min` / `converged_verified` 等 29 列。

`min_effective_motion_limit_um` 大概是本实验最有价值的**单个**数：收敛且残差信噪比
≥ 2 时，那就是一个**可重复**的物理下限，而不是噪声。

---

## 4. 为什么用未压缩 RAW，而不是 MJPG / FFV1

**绝对不退回 MJPG**（用户硬约束）。FFV1 也不行：OpenCV 的
`VideoWriter_fourcc('FFV1')` 写 Mono8 时会经 swscale 转成 `YUV420P`
（色度抽样 + 有限范围 16–235），**并非位精确**。本实验要的分辨率是
3 μm ≈ 0.044 px，这种系统性量化是实打实的损失，而且抽检帧比对查不出它。

所以：**内存缓冲 → 未压缩 RAW 临时文件 → 处理 → 删除**。

丢帧由架构隔离，不靠压缩解决：

| 路径 | 每帧成本 | 结果 |
|---|---|---|
| 全幅 RAW **实时写盘** | 均值 2.27 ms / 峰值 7.38 ms（预算 7.56 ms） | 丢 6.11% |
| 全幅 **memcpy 进内存**（本方案） | ≈ 0.3 ms | 零丢帧，余量 25× |

录制阶段只做取帧 + memcpy：不灰度、不识别、不写盘。识别与录制**完全串行**——
片段关掉之后父进程才逐帧跑棋盘格，识别再慢也挤不掉采集。编码不再受实时约束，
所以 RAW 唯一的代价（体积）由"用后即删"吸收。

### 不裁剪、不 resize

实测同一批 20 帧，冻结一个以棋盘格为中心的原分辨率裁剪框（720×722）：

| | 全幅 1936×1464 | 裁剪 720×722 |
|---|---|---|
| 识别成功率 | **20/20 = 100%** | **7/20 = 35%** |
| 耗时 | 203 ms | 164 ms（只快 19%） |

原因是 `CALIB_CB_NORMALIZE_IMAGE` 的归一化基准是整幅图，裁掉背景后对比度基准
改变、检测阈值随之漂移。**保持全幅**。全幅 100% 识别率远好于原先引用的 88.1%。

---

## 5. 视觉链路：只用公开 API，复用已验证流程

`GroupVisionMeter` 每帧走的是：`gray = frame`（Mono8 已是灰度）
→ `cv2.GaussianBlur(gray, (3,3), 0)` → `cv2.setRNGSeed(0)` → `tracker.process(gray)`。

- 与 `camera.preprocess_frame` 的**识别部分逐字等价**，只是不算那份显示用的画质统计
  （`MICRO_LOOP_COMPUTE_METRICS = False`，用户定"图像质量只显示、绝不参与控制"）。
- `setRNGSeed(0)` 的理由：`_estimate_rigid_motion` 用
  `estimateAffinePartial2D(method=RANSAC)`，内点集抖动会让 88 点均值位移跳动
  约 0.8 μm。对 3 μm 容差不是小数目，固定种子让同一帧永远得到同一结果。
- **没有重新设计棋盘格识别算法**，也没改 `camera.py` / `robot.py`。

### 参考帧选取用 medoid，不用"第一帧"

单帧误检若成为永久零点，整组报废。所以先扫一遍参考片段收集角点，取质心最接近
全体质心中位数的帧（medoid）作为参考，再用**新建**的 tracker 把它作为
"这辈子看到的第一帧"喂进去。

### 每帧接受判据（六项）

```python
checker_is_valid
and checker_quality  >= 0.5            # MICRO_LOOP_QUALITY_MIN
and checker_found_by == ref_found_by   # sb / legacy 的角点排序不保证一致
and |checker_angle_deg| <= 1.0
and |checker_scale - 1| <= 0.01
and max(|dx|,|dy|)*1000 <= 2000 μm
```

`found_by` 相等这一条是廉价且关键的一刀：`findChessboardCornersSB` 与传统兜底
`findChessboardCorners` **不保证角点排序一致**，参考帧若来自 `sb`、某帧回落到
`legacy`，配对可能被置换。

为什么需要这些门禁：棋盘格**索引错位一格**会让所有点位移同一个向量（约 3 mm），
`estimateAffinePartial2D` 会拟合出一个**残差≈0、内点率 1.0、quality≈1.0、
angle≈0、scale≈1 的纯平移**——与"真的移动了 3 mm"在当前返回字典里无法区分。
3000 μm 的假误差喂进限幅 100 μm 的闭环 = 20 步朝任意方向走 2 mm。

另有**迭代间连续性联锁**：`|measured[k] − measured[k−1]| > 300 μm` → 该次迭代标
`INVALID`，**绝不据此发命令**。

---

## 6. 命令接口（单点接缝）

```python
def send_cartesian_micro_correction(robot, axis, delta_um, *, stop_event, write_state) -> dict
```

- **μm → m 只在这一处转换**（`delta_um * 1e-6`），别处禁止混用单位
- 构造 **2 点** `Waypoint`（`execute_trajectory` 对 ≤1 点轨迹**静默 no-op**）
- `validate_trajectory` → `verify_controller_safety_limits` → `execute_trajectory`
- **断言命令真的发下去了**：`execute_trajectory` 在成功与静默 no-op 两条路径上
  都返回 `None`，只能靠 `robot.motion_command_time` 是否推进来区分。
  没推进就抛错，绝不静默当作走了。
- 完成判据**不用** `motion_in_progress()`（它带 200 ms 固定宽限，对 14 ms 量级的
  微动毫无信息量），改用基于位置与速度的稳定判据；超时**降级为记录**，
  由视觉片段自身的尾部标准差决定这次测量是否有效。

以后要比较 MoveL 与 servoj，只替换这一层。

### 死区 `MIN_COMMAND_UM = 2.0` 是必需的，不是调参

`robot.validate_trajectory` 拒绝 `length <= 1e-6 m`（"两点位置重合"）。而
`command = Kp · error`，收敛时 `|error|` 可能只有 1 μm → 命令 1 μm → 正好撞在
这条硬线上，**会在一个目标即将成功的时刻把整轮弄死**。所以
`|command| < 2 μm` 时不发运动，但仍照常录前后段、照常测量、照常判收敛。

---

## 7. 轴向 / 符号探针（必做）

视觉 +x/+y 与机器人 base X/Y 的对应关系（含符号）**无法从代码推出**，且符号反了
会让误差每步翻倍直冲 100 μm 限幅。所以启动时用一次 1000 μm 的探针测出来。

门禁（任一不过则**具名中止**，不继续）：两个机器人轴必须映射到**不同**的视觉轴
（否则像平面近似侧视）；增益必须落在 `[0.3, 2.0]`；正反向增益差 < 20%；
交叉耦合 ≥ 0.3 时**记录并提示**但不中止。

**不做 `/g` 自标定**——不做自适应增益控制，命令律严格保持 `Kp · error`。

---

## 8. 本轮改动的文件

| 文件 | 改动 |
|---|---|
| `micro_closed_loop.py` | **新增**：纯计算层 + 视觉层 + 命令接缝 + 两个 worker |
| `config.py` | 删 `MICRO_*` 与 `micro_motion_experiment`；加 `MICRO_LOOP_*` 与新模式注册 |
| `main.py` | 删 `run_micro_motion_experiment_mode` 与 `--micro-levels`；加 `run_micro_closed_loop_mode` |
| `launcher_ui.py` | 换按钮为「E. XY 微动闭环能力测试」；重写使用说明第 8 条；修分区标签重复 |
| `tests/test_micro_closed_loop.py` | **新增**（115 个用例） |
| `micro_motion.py`、`micro_motion_export.py`、`tests/test_micro_motion_plan.py` | **删除** |

**没有修改 `robot.py` 与 `camera.py`**，也没有改动任何其它实验模式的逻辑。

### 有意绕过手电筒门禁

`batch_camera_worker` 的 `_FlashGate` 会硬抛"手电筒门禁未完成"。新的相机 worker
**不构造它**——闭环的时间对齐由全机共享的 `time.perf_counter_ns()`
（Windows `QueryPerformanceCounter`，跨进程一致）保证，不依赖操作者打手电筒。
**这是设计决定，不是安全回归**，在模块 docstring 里也写明了。

---

## 9. 怎么跑

```
python launcher_ui.py        （或双击 run_launcher_ui.cmd）
→ A. 硬件检查 → 连接成功后才解锁运动按钮
→ E. XY 微动闭环能力测试 → 填幅值列表（默认 5,20,50）
→ 「开始 XY 微动闭环测试」 → 二次确认
```

命令行等价形式：

```
python main.py --mode micro_closed_loop --ui-confirmed
```

**前置条件**（任一不满足即在创建任何目录之前被拒）：
`ROBOT_RELATIVE_MOTION_ENABLED = True`、`CONTROL_MODE != "sfc"`、
`VISION_METHOD == "checkerboard"`、输出卷剩余 ≥ 20 GiB。

日志区只接收子进程 stdout 文本，`[状态]` 前缀的行会镜像到状态栏，所以每次迭代
打一行（不是每帧）：

```
[状态] X +5 μm 目标｜迭代 3/20｜位置 +0.30 μm｜误差 +4.70 μm｜指令 -4.70 μm
[状态] 探针结果：X→视觉x 增益 +0.97（正反向差 3%）｜Y→视觉y 增益 +1.02
[状态] 本组噪声底 sigma = 0.6 μm｜有效测量分辨率约 1.2 μm
[状态] 最近片段：实际 152/预期 152 帧｜棋盘格识别率 99.3%
[状态] 磁盘剩余 58.4 GB
```

### 时长预估

每轮一段连续片段（约 0.9–1.6 s ≈ 120–210 帧）× 约 250 ms/帧 ≈
**30–53 s/迭代**。12 个目标若平均 8 次 ≈ **1 小时**；
全部跑满 20 次最坏 ≈ **2.5–3 小时**。
`MICRO_LOOP_PROCESS_EVERY_N_FRAMES` 是线性降耗开关（默认 1 = 逐帧）。

---

## 10. 验证状态

| 项目 | 结果 |
|---|---|
| `python -m unittest discover -s tests` | **140 个用例全绿**（25 基线 + 115 新增） |
| `py_compile`（4 个改动文件 + 新单测） | 通过 |
| `main.py --help` | 出现 `micro_closed_loop`，`micro_motion_experiment` 已消失 |
| 无硬件干跑 | 4 个入口门禁逐一被拒，且**目录未被创建** |
| 探针门禁 | 6 种坏增益矩阵逐一具名中止（含"不可分辨"与"回差过大"） |
| 终止判据 | 全分支覆盖，**含两个必需反例**（早期单调收缩不得误判极限环；噪声底以下的换号不得判极限环） |
| 实机 | **尚未进行**（需要操作者在场） |

> 单测请用 `.venv/Scripts/python.exe`。系统 `C:\Python314` 没装 `cv2`，
> 会导致 `test_batch_camera_startup` / `test_batch_offline_vision` 报
> `ModuleNotFoundError`——那是环境问题，不是回归。

### 实机首次运行请重点确认

1. 参考片段能否稳定识别（识别率应接近 100%）
2. **探针符号是否正确**（这是闭环会不会发散的分水岭）
3. `actual_visual_displacement_um` 与 `command_um` 的量级关系（`g_obs` 应接近 1）
4. 结束是否回到初始位姿
5. 目录里是否**没有**任何残留视频

---

## 11. 已知局限

1. **`GAUSSIAN_BLUR_KERNEL = 3` 在检测前就抹掉了换取亚像素精度所需的高频。**
2. **`CAMERA_MATRIX = None`，未做畸变校正。** 镜头畸变会让刚体平移**不**产生
   均匀像素平移，给均值带来系统性**增益**偏差（不是噪声，平均消不掉）。

这两项都会在探针增益与 `est_sigma_um` 上留下痕迹。**若探针测出的 `|g|`
偏离几何预测 > 10%，先跑一次内参标定**（仓库里已有 `calibrate_camera_intrinsics.py`）
再解读闭环结果。本说明不主张已排除这个偏差。

3. `MICRO_LOOP_KP` 固定为 1.0（用户指定）。`g_obs` 每轮都记录，
   因此有效环路增益可以从数据反推，但**运行期不做任何自适应**。
