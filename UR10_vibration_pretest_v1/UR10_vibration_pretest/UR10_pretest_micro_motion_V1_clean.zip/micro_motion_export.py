"""
把 micro_motion_experiment 的未压缩 RAW 离线转成可看的无损视频。

为什么录制用 RAW、播放才转码：
- 实时录制必须保证 132.23 fps 不掉帧。实测 FFV1 的吞吐**随画面内容浮动**
  （真实传感器噪声帧约 79 fps，重复内容帧约 181 fps），无法事先保证，
  一旦跟不上就静默丢帧。未压缩 RAW 与内容无关、天然位精确，是唯一稳的实时格式。
- 转码在实验结束之后离线进行，没有实时约束，此时再用 FFV1 就完全安全了。

用法：
    .venv\\Scripts\\python.exe micro_motion_export.py --run-dir outputs\\micro_motion_test_20260917_101530
    .venv\\Scripts\\python.exe micro_motion_export.py --run-dir <目录> --raw <某个.raw 路径>
    .venv\\Scripts\\python.exe micro_motion_export.py --run-dir <目录> --codec FFV1 --verify-frames 200

输出：与每个 .raw 同目录、同名的 .mkv（FFV1 无损）。
默认已存在的 mkv 会被跳过；加 --overwrite 才覆盖。

本脚本只读 RAW 和 _raw_meta.json，不改动实验数据。
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import cv2
import numpy as np

import config


DEFAULT_CODEC = "FFV1"


def read_meta(raw_path: Path) -> dict:
    """
    读取 RAW 的旁车元数据。

    输入：.raw 路径。
    输出：`_raw_meta.json` 解析结果。

    实验作用：宽、高、帧数、dtype 都从相机封口时写的元数据读取，
    而不是靠猜——猜错会让导出的画面整体错位。
    """

    meta_path = raw_path.with_name(raw_path.stem + "_raw_meta.json")
    if not meta_path.exists():
        raise FileNotFoundError(
            f"找不到 {meta_path.name}。导出的形状必须来自相机写的元数据，"
            "不接受猜测；如果元数据丢失，请直接用 np.memmap 按已知 shape 读取 .raw。"
        )
    return json.loads(meta_path.read_text(encoding="utf-8"))


def validate_raw(raw_path: Path, meta: dict) -> int:
    """核对 RAW 文件大小与元数据是否一致，返回帧数。"""

    frame_count = int(meta["frame_count"])
    width = int(meta["width"])
    height = int(meta["height"])
    expected = frame_count * width * height
    actual = int(raw_path.stat().st_size)
    if actual != expected:
        raise RuntimeError(
            f"{raw_path.name} 大小 {actual} 字节与元数据不符："
            f"{frame_count} 帧 × {width}×{height} 应为 {expected} 字节。"
            "文件可能被截断，导出结果不可信。"
        )
    return frame_count


def export_one(
    raw_path: Path,
    *,
    codec: str,
    overwrite: bool,
    verify_frames: int,
    fps_override: float | None,
) -> dict:
    """
    把单个 RAW 转成无损 mkv。

    输入：RAW 路径、FourCC、是否覆盖、抽检帧数、可选 fps 覆盖。
    输出：含输出路径、帧数、耗时和抽检结果的字典。

    抽检：FFV1 应当完全无损，但 OpenCV 对灰度视频在读取时会返回 3 通道，
    容易让人误判“有损”。因此这里对抽检帧做一次真正的往返比对，
    把最大像素差报出来，而不是只靠声称。
    """

    meta = read_meta(raw_path)
    frame_count = validate_raw(raw_path, meta)
    width = int(meta["width"])
    height = int(meta["height"])
    fps = float(fps_override or meta.get("camera_actual_fps") or config.EXPECTED_VISION_FPS or 132.0)

    output_path = raw_path.with_suffix(".mkv")
    if output_path.exists() and not overwrite:
        return {"raw": str(raw_path), "output": str(output_path), "skipped": "已存在"}

    frames = np.memmap(
        raw_path, dtype=np.uint8, mode="r", shape=(frame_count, height, width)
    )
    writer = cv2.VideoWriter(
        str(output_path),
        cv2.VideoWriter_fourcc(*codec),
        fps,
        (width, height),
        False,
    )
    if not writer.isOpened():
        raise RuntimeError(
            f"无法用 {codec} 创建 {output_path}。请换一种无损编码（例如 FFV1）"
            "或确认 OpenCV 是否带该编码器。"
        )

    started = time.perf_counter()
    for index in range(frame_count):
        writer.write(np.ascontiguousarray(frames[index]))
    writer.release()
    elapsed_s = time.perf_counter() - started

    sample_count = min(int(verify_frames), frame_count)
    sample_indices = (
        sorted({int(round(i * (frame_count - 1) / max(1, sample_count - 1))) for i in range(sample_count)})
        if sample_count > 1
        else [0]
    )

    max_diff = 0
    if sample_indices:
        cap = cv2.VideoCapture(str(output_path))
        try:
            for index in sample_indices:
                cap.set(cv2.CAP_PROP_POS_FRAMES, index)
                ok, decoded = cap.read()
                if not ok:
                    raise RuntimeError(f"抽检失败：无法回读 {output_path.name} 第 {index} 帧。")
                # OpenCV 即使以灰度写入，回读也常返回 3 通道；取第 0 通道才是原始灰度。
                decoded_gray = decoded if decoded.ndim == 2 else decoded[:, :, 0]
                diff = int(
                    np.max(
                        np.abs(
                            decoded_gray.astype(np.int16)
                            - frames[index].astype(np.int16)
                        )
                    )
                )
                max_diff = max(max_diff, diff)
                if diff != 0:
                    break
        finally:
            cap.release()

    return {
        "raw": str(raw_path),
        "output": str(output_path),
        "frame_count": frame_count,
        "width": width,
        "height": height,
        "fps": fps,
        "codec": codec,
        "encode_seconds": round(elapsed_s, 3),
        "encode_fps": round(frame_count / elapsed_s, 1) if elapsed_s > 0 else None,
        "verify_frames_checked": len(sample_indices),
        "verify_max_pixel_diff": max_diff,
        "lossless": max_diff == 0,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="把 micro_motion_experiment 的未压缩 RAW 转成可看的无损视频。"
    )
    parser.add_argument("--run-dir", type=Path, required=True, help="微动实验运行目录。")
    parser.add_argument("--raw", type=Path, default=None, help="只转这一个 .raw；省略则转全部。")
    parser.add_argument("--codec", default=DEFAULT_CODEC, help="FourCC，默认 FFV1（无损）。")
    parser.add_argument("--fps", type=float, default=None, help="覆盖元数据里的帧率。")
    parser.add_argument("--overwrite", action="store_true", help="覆盖已存在的 mkv。")
    parser.add_argument(
        "--verify-frames",
        type=int,
        default=64,
        help="每个文件抽检多少帧做往返比对（0 表示不抽检）。",
    )
    arguments = parser.parse_args()

    if arguments.raw is not None:
        raw_paths = [arguments.raw]
    else:
        raw_paths = sorted(Path(arguments.run_dir).rglob("*.raw"))
    if not raw_paths:
        print(f"[导出] {arguments.run_dir} 下没有找到 .raw 文件。")
        return 1

    print(f"[导出] 共 {len(raw_paths)} 个 RAW，编码 {arguments.codec}，输出无损 mkv。")
    failures = 0
    reports: list[dict] = []
    for raw_path in raw_paths:
        if not raw_path.exists():
            print(f"[导出] 跳过不存在的 {raw_path}")
            failures += 1
            continue
        print(f"[导出] 正在处理 {raw_path.name} ……", flush=True)
        try:
            report = export_one(
                raw_path,
                codec=arguments.codec,
                overwrite=arguments.overwrite,
                verify_frames=int(arguments.verify_frames),
                fps_override=arguments.fps,
            )
        except (OSError, RuntimeError, ValueError, KeyError) as exc:
            print(f"[导出] {raw_path.name} 失败：{type(exc).__name__}: {exc}")
            failures += 1
            continue
        reports.append(report)
        if report.get("skipped"):
            print(f"[导出] {Path(report['output']).name} 已存在，跳过。")
        else:
            verdict = "位精确" if report["lossless"] else f"最大像素差 {report['verify_max_pixel_diff']}"
            print(
                f"[导出] {Path(report['output']).name}：{report['frame_count']} 帧，"
                f"{report['fps']:.3f} fps，编码 {report['encode_fps']} fps，"
                f"抽检 {report['verify_frames_checked']} 帧 → {verdict}"
            )

    report_path = Path(arguments.run_dir) / "export_report.json"
    report_path.write_text(
        json.dumps(
            {
                "kind": "MICRO_MOTION_EXPORT",
                "run_dir": str(arguments.run_dir),
                "codec": arguments.codec,
                "files": reports,
                "failure_count": failures,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"[导出] 报告写入 {report_path}")
    if failures:
        print(f"[导出] 有 {failures} 个文件失败。")
        return 1
    print("[导出] 全部完成。RAW 与 mkv 内容一致，mvk 只用于人工观看。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
