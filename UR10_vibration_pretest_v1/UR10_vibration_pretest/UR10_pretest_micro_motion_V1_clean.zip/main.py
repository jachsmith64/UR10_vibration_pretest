"""
UR10 末端振动预实验的唯一总入口。

用户运行 python main.py 后，程序首先来到这里。本文件的职责不是实现视觉算法、
机器人轨迹或频谱分析，而是根据 config.py / 命令行选择，把任务交给对应模块。

从用户操作看，代码大致这样流动：
1. 用户选择模式：config.RUN_MODE 或命令行 --mode。
2. main() 做配置检查：先排除拼写错误、危险真机开关、明显不合理参数。
3. 单模块模式直接转交：
   - vision_test -> camera.py 读取图片/视频/相机并输出视觉结果；
   - robot_dry_run / robot_test -> robot.py 生成轨迹、检查轨迹或连接 UR；
   - analyze -> analyze.py 读取已有记录并输出分析图表。
4. experiment 模式比较特殊：main.py 会同时启动记录、相机、机器人三个子进程，
   并负责 ready、start、motion_done、stop 这些流程信号。

因此读本文件时，重点不是每个算法怎么算，而是“某个模式被选中后，谁先启动、
谁等待谁、数据从哪个队列流到哪个文件”。
"""

from __future__ import annotations

import argparse
import csv
import json
import multiprocessing as mp
import queue
import time
from datetime import datetime, timedelta
from multiprocessing.process import BaseProcess
from pathlib import Path
from typing import Any

import config


# =============================================================================
# 1. 通用记录进程：把多个来源的数据排队写成同一个实验日志
# =============================================================================

def record_writer_worker(record_queue: Any, output_path: Path) -> None:
    """
    完整实验中的“统一写日志工人”。

    输入：
    - record_queue：相机进程、机器人进程和主进程放入的记录字典；
    - output_path：本次实验最终的 run_log.txt 路径。

    输出：
    - 每收到一个记录字典，就写成 run_log.txt 中的一行 JSON。

    实验作用：
    - 让相机数据、机器人状态、实验事件、错误信息最终进入同一个时间序列文件；
    - 多个生产者只负责把记录放进队列，不直接碰文件，避免两条记录互相穿插。
    - 收到 None 表示所有生产者已经停止，可以安全关闭文件。
    """

    # 本段准备输出文件。输入是目标路径；输出是一个已经打开、可逐行写入的日志文件。
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # 本段持续消费记录队列。输入是一条条实验记录；输出是一行行 JSON 文本。
    # 行缓冲能降低异常退出时丢日志的概率，也方便实验中实时打开文件查看新记录。
    with output_path.open("w", encoding="utf-8", buffering=1) as file:
        while True:
            # 没有新记录时这里会阻塞等待，因此写日志进程不会空转占 CPU。
            record = record_queue.get()

            # None 是主进程发送的“日志可以收尾”信号，不是一条真实实验数据。
            if record is None:
                break

            # 每行是一条完整 JSON：人可以用记事本看，程序也可以逐行恢复字段。
            line = json.dumps(record, ensure_ascii=False, allow_nan=True)
            file.write(line + "\n")


def segmented_record_writer_worker(record_queue: Any, batch_dir: Path) -> None:
    """Route interleaved camera/robot/event records to each segment RUNLOG file."""

    batch_dir = Path(batch_dir)
    files: dict[str, Any] = {}
    try:
        while True:
            record = record_queue.get()
            if record is None:
                break
            segment_base = record.get("segment_base")
            if not segment_base:
                continue
            segment_base = str(segment_base)
            file = files.get(segment_base)
            if file is None:
                path = batch_dir / f"{segment_base}_RUNLOG.txt"
                file = path.open("x", encoding="utf-8", buffering=1)
                files[segment_base] = file
            file.write(json.dumps(record, ensure_ascii=False, allow_nan=True) + "\n")
    finally:
        for file in files.values():
            file.close()


def _record_event(record_queue: Any, name: str, **extra: Any) -> None:
    """
    把主程序观察到的实验流程节点写进日志。

    输入：
    - name：事件名称，例如 all_workers_ready、experiment_started、experiment_finished；
    - extra：附加字段，例如轨迹类型或阶段信息。

    输出：
    - 一条 kind="EVENT" 的记录进入 record_queue，最后由 record_writer_worker 写入 run_log.txt。

    实验作用：
    - 给相机帧和机器人状态之间插入“实验流程标尺”，后续 analyze.py 才知道哪些时间属于静止、
      运动或后记录阶段。
    """

    # 本段给事件打上主机单调时钟。它不表示现实日期，而是用于同一台电脑内的相对对时。
    record_queue.put(
        {
            "kind": "EVENT",
            "host_ns": time.perf_counter_ns(),
            "name": name,
            **extra,
        },
        timeout=1.0,
    )


def _pop_worker_error(error_queue: Any) -> str | None:
    """
    主进程用它“顺手看一眼”子进程有没有报错。

    输入：相机进程或机器人进程写入的 error_queue。
    输出：有错误时返回错误文字；没有错误时返回 None。

    实验作用：主程序在等待 ready、等待运动完成、等待后记录结束时都要反复调用它。
    这样一旦某个子进程失败，完整实验会尽快停止，而不是继续等超时。
    """

    try:
        # 只要有一条错误，主程序上层就会把它当成本次实验失败原因。
        return str(error_queue.get_nowait())
    except queue.Empty:
        # 没有错误是正常状态，调用方会继续检查 ready、stop 或超时。
        return None


def _wait_for_worker_error(error_queue: Any, timeout_s: float = 0.5) -> str | None:
    """Allow a multiprocessing Queue feeder to publish an error before masking it."""

    immediate = _pop_worker_error(error_queue)
    if immediate:
        return immediate
    try:
        return str(error_queue.get(timeout=max(0.0, float(timeout_s))))
    except queue.Empty:
        return None


def _wait_ready(
    camera_ready: Any,
    robot_ready: Any,
    error_queue: Any,
    stop_event: Any,
) -> None:
    """
    等待完整实验的两个硬件子进程真正准备好。

    输入：
    - camera_ready：相机进程成功打开图像来源并处理过第一帧后置位。
    - robot_ready：机器人进程完成轨迹检查、连接和起点检查后置位。
    - error_queue：任一子进程失败时会写错误。
    - stop_event：主程序或子进程要求停止时会置位。

    输出：
    - 两个 ready 都置位时正常返回；
    - 任一子进程报错、stop_event 置位或等待超时时抛错。

    实验作用：确保“相机已经能取图、机器人已经准备好”之后，才允许操作者确认并开始运动。
    这个函数只等待信号，不连接相机、不连接机器人、不发运动命令。
    """

    # 本段设置等待上限。输入是配置中的秒数；输出是一个绝对截止时刻。
    deadline = time.perf_counter() + config.WORKER_READY_TIMEOUT_S

    # 本段是 ready 等待循环。它同时观察 ready、错误、停止信号和超时。
    while not (camera_ready.is_set() and robot_ready.is_set()):
        worker_error = _pop_worker_error(error_queue)
        if worker_error:
            raise RuntimeError(worker_error)

        if stop_event.is_set():
            raise RuntimeError("某个子进程在 ready 前要求停止，但没有返回更多错误信息。")

        # 超时时明确说明相机或机器人谁没准备好，便于现场排查。
        if time.perf_counter() >= deadline:
            missing = []
            if not camera_ready.is_set():
                missing.append("相机")
            if not robot_ready.is_set():
                missing.append("机器人")
            raise TimeoutError(f"等待 {'、'.join(missing)} ready 超时。")

        # 0.05 秒检查一次，既能及时响应，也不会让 CPU 忙等。
        time.sleep(0.05)


def _wait_motion_done(
    motion_done: Any,
    error_queue: Any,
    stop_event: Any,
) -> None:
    """
    完整实验运动阶段的“主程序等待逻辑”。

    输入：
    - motion_done：机器人子进程发出的“运动完成”信号；
    - error_queue：子进程异常报告；
    - stop_event：任一进程要求实验停止的信号。

    输出：
    - 机器人报告运动完成时正常返回；
    - 出错、提前停止或超时时抛错。

    实验作用：主程序本身不控制机器人每个采样点，只负责确认运动阶段是否按预期结束。
    如果机器人异常退出但没来得及置位 motion_done，这里也能通过错误、停止信号或超时退出。
    """

    # 本段把“预记录 + 最大运动时间 + 余量”合成主程序等待上限。
    deadline = (
        time.perf_counter()
        + config.PRE_RECORD_SECONDS
        + config.ROBOT_MOTION_TIMEOUT_S
        + 5.0
    )

    # 本段在运动期间持续观察完成信号、错误信号和停止信号。
    while not motion_done.is_set():
        worker_error = _pop_worker_error(error_queue)
        if worker_error:
            raise RuntimeError(worker_error)

        if stop_event.is_set():
            raise RuntimeError("实验在运动完成前收到停止信号。")

        if time.perf_counter() >= deadline:
            raise TimeoutError("主程序等待 motion_done 超时。")

        # 小睡一会儿，避免等待循环占满 CPU。
        time.sleep(0.05)


def _join_or_terminate(process: BaseProcess) -> None:
    """
    完整实验结束时回收一个子进程。

    输入：已经启动过的相机、机器人或写日志子进程。
    输出：该子进程正常退出，或在失去响应时被终止并回收。

    实验作用：优先让子进程执行自己的 finally，释放相机/RTDE/文件句柄；
    terminate 只是最后清理手段，正常流程不会靠它结束硬件连接。
    """

    # 本段先给子进程一个正常收尾窗口，让它自己关闭硬件或文件资源。
    process.join(timeout=config.WORKER_JOIN_TIMEOUT_S)

    # 本段只在子进程失去响应时执行，属于实验收尾的最后保险。
    if process.is_alive():
        print(f"[主程序警告] {process.name} 未按时退出，将终止该子进程。")
        process.terminate()

        # 终止后再 join 一次，尽量把操作系统进程资源回收干净。
        process.join(timeout=2.0)


RELATIVE_MOTION_MODES = {
    "x_line_experiment",
    "xy_line_experiment",
    "xy_l_experiment",
}


def _clear_stop_request_file(path: Path | None) -> None:
    """清理本次 run 专属停止请求文件。"""

    if path is not None and path.exists():
        path.unlink()


def _external_stop_requested(path: Path | None) -> bool:
    """检查启动器为本次 run 写入的停止请求。"""

    return bool(path is not None and path.exists())


def _wait_event_or_error(
    event: Any,
    description: str,
    error_queue: Any,
    stop_event: Any,
    stop_request_path: Path | None,
    *,
    timeout_s: float | None = None,
) -> None:
    """等待一个事件，同时响应 worker 错误和启动器停止请求。"""

    deadline = None if timeout_s is None else time.perf_counter() + timeout_s
    while not event.is_set():
        worker_error = _pop_worker_error(error_queue)
        if worker_error:
            raise RuntimeError(worker_error)
        if _external_stop_requested(stop_request_path):
            stop_event.set()
        if stop_event.is_set():
            worker_error = _pop_worker_error(error_queue)
            if worker_error:
                raise RuntimeError(worker_error)
            raise RuntimeError(f"{description} 期间收到停止请求。")
        if deadline is not None and time.perf_counter() >= deadline:
            raise TimeoutError(f"等待 {description} 超时。")
        time.sleep(0.05)


def _sleep_with_stop_checks(
    seconds: float,
    error_queue: Any,
    stop_event: Any,
    stop_request_path: Path | None,
) -> None:
    """带错误和停止请求检查的短等待。"""

    deadline = time.perf_counter() + seconds
    while time.perf_counter() < deadline:
        worker_error = _pop_worker_error(error_queue)
        if worker_error:
            raise RuntimeError(worker_error)
        if _external_stop_requested(stop_request_path):
            stop_event.set()
        if stop_event.is_set():
            raise RuntimeError("后记录期间收到停止请求。")
        time.sleep(0.05)


def _relative_parameters_from_args(
    arguments: argparse.Namespace,
    selected_mode: str,
) -> dict[str, Any]:
    """把命令行/UI 参数整理给 robot.py 的纯轨迹函数。"""

    default_times = {
        "x_line_experiment": config.ROBOT_EXPERIMENT_DEFAULT_X_LINE_ONE_WAY_TIME_S,
        "xy_line_experiment": config.ROBOT_EXPERIMENT_DEFAULT_XY_LINE_ONE_WAY_TIME_S,
        "xy_l_experiment": config.ROBOT_EXPERIMENT_DEFAULT_L_ONE_WAY_TIME_S,
    }
    one_way_time_s = (
        float(arguments.one_way_time_s)
        if arguments.one_way_time_s is not None
        else float(default_times[selected_mode])
    )

    return {
        "speed_mm_s": arguments.speed_mm_s,
        "one_way_time_s": one_way_time_s,
        "total_time_s": arguments.total_time_s,
        "angle_deg": arguments.angle_deg,
        "x_direction": arguments.x_direction,
        "y_direction": arguments.y_direction,
        "x_speed_mm_s": arguments.x_speed_mm_s,
        "x_one_way_time_s": arguments.x_one_way_time_s,
        "y_speed_mm_s": arguments.y_speed_mm_s,
        "y_one_way_time_s": arguments.y_one_way_time_s,
        "blend_mm": arguments.blend_mm,
        "acceleration_m_s2": config.ROBOT_EXPERIMENT_ACCELERATION_M_S2,
    }


def _update_experiment_parameters_with_camera_fps(run_dir: Path) -> None:
    """相机完成后把实际 fps 回填到 experiment_parameters.json。"""

    parameters_path = run_dir / "experiment_parameters.json"
    metadata_path = run_dir / "camera" / "capture_metadata.json"
    if not parameters_path.exists() or not metadata_path.exists():
        return
    parameters = json.loads(parameters_path.read_text(encoding="utf-8"))
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    parameters["industrial_camera_actual_fps"] = metadata.get("actual_camera_fps")
    parameters_path.write_text(
        json.dumps(parameters, ensure_ascii=False, indent=2, allow_nan=True),
        encoding="utf-8",
    )


# =============================================================================
# 2. 五种模式的高层入口：用户选一个模式，main.py 就转交给一个模块
# =============================================================================

def run_vision_test_mode() -> Path:
    """
    用户选择 vision_test 后进入这里。

    输入：config.py 中的视觉来源、视觉算法、调试图和坐标输出设置。
    输出：camera.py 创建的 vision_test_时间戳 输出目录。

    实验作用：只验证视觉链路。它会让 camera.py 读取图片/视频/相机帧、逐帧识别、
    保存 vision_results.txt 和抽样 debug 图；不会连接机器人。
    """

    # 本段是“入口转交”。只有用户真的选择 vision_test，才加载 camera.py 的视觉代码。
    from camera import run_vision_test

    # 图像读取、识别、结果保存都在 camera.py；main.py 只拿回输出目录。
    return run_vision_test()


def run_vision_capture_mode() -> Path:
    """
    用户选择 vision_capture 后进入这里。

    这个模式只高速采集海康相机原始 Mono8 帧到 RAW 文件，不做棋盘格识别，不连接机器人。
    """

    from camera import run_vision_capture

    return run_vision_capture()


def run_vision_offline_mode() -> Path:
    """
    用户选择 vision_offline 后进入这里。

    这个模式读取 vision_capture 保存的 RAW 帧，离线逐帧完整执行现有视觉识别。
    """

    from camera import run_vision_offline

    return run_vision_offline()


def run_robot_dry_run_mode() -> Path:
    """
    用户选择 robot_dry_run 后进入这里。

    输入：config.py 中的 A/B/C 位姿、轨迹类型、速度、工作区限制。
    输出：robot.py 创建的 dry-run 报告目录。

    实验作用：只做纯软件轨迹体检。它不会创建 URRobot，不会导入 ur_rtde，
    也不会连接任何机器人 IP，适合实机前反复检查坐标是否写得离谱。
    """

    # 本段是“入口转交”。只有选择机器人相关模式，才加载 robot.py。
    from robot import run_robot_dry_run

    # 轨迹生成、工作区检查和报告保存由 robot.py 完成。
    return run_robot_dry_run()


def run_robot_connection_test_mode() -> Path:
    """只读检测机械臂通信，不创建控制接口、不发送运动命令。"""

    from robot import run_robot_connection_test

    return run_robot_connection_test()


def run_robot_test_mode() -> Path:
    """
    用户选择 robot_test 后进入这里。

    输入：机器人连接参数、轨迹端点、安全确认开关。
    输出：robot.py 创建的机器人测试输出目录。

    实验作用：单独验证 UR 连接和状态读取；当安全开关允许时，才执行低速 A→B 测试运动。
    注意：这个模式可能连接真机，是否允许运动由 ROBOT_TEST_ALLOW_MOTION 等开关共同决定。
    """

    # 本段是“入口转交”。只有明确选择 robot_test，才触碰 robot.py 的真机测试入口。
    from robot import run_robot_test

    return run_robot_test()


def run_analysis_mode(analysis_file: Path | None = None) -> Path:
    """
    用户选择 analyze 后进入这里。

    输入：已有的 run_log.txt 或 vision_results.txt，可由 --analysis-file 指定。
    输出：analyze.py 创建的时域图、频域图、summary/metrics 等分析结果。

    实验作用：把已经保存下来的视觉/机器人记录转成更容易判断振动现象的图和指标。
    它不连接相机，也不连接机器人。
    """

    # 本段是“入口转交”。analysis_file 不传时，analyze.py 会自己寻找最新记录。
    from analyze import run_analysis

    return run_analysis(analysis_file)


def run_relative_motion_experiment_mode(
    selected_mode: str,
    arguments: argparse.Namespace,
) -> Path:
    """三个相对运动实验共用的主进程协调入口。"""

    if selected_mode not in RELATIVE_MOTION_MODES:
        raise ValueError(f"不是相对运动实验模式：{selected_mode}")

    if not config.ROBOT_RELATIVE_MOTION_ENABLED:
        raise PermissionError(
            "ROBOT_RELATIVE_MOTION_ENABLED=False。请在实验室完成通信测试和现场安全确认后再改为 True。"
        )

    parameters = _relative_parameters_from_args(arguments, selected_mode)
    stop_request_path = arguments.stop_request_path
    if stop_request_path is not None and not stop_request_path.is_absolute():
        stop_request_path = (config.PROJECT_DIR / stop_request_path).resolve()
    _clear_stop_request_file(stop_request_path)

    if not arguments.ui_confirmed:
        from robot import require_operator_confirmation

        require_operator_confirmation(f"{selected_mode} 相对运动实验")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = config.OUTPUT_ROOT / f"{selected_mode}_{timestamp}"
    run_dir.mkdir(parents=True, exist_ok=True)
    events_path = run_dir / "experiment_events.txt"
    summary_path = run_dir / "experiment_summary.json"

    context = mp.get_context("spawn")
    record_queue = context.Queue(maxsize=config.RECORD_QUEUE_MAXSIZE)
    error_queue = context.Queue(maxsize=config.ERROR_QUEUE_MAXSIZE)

    camera_ready = context.Event()
    robot_ready = context.Event()
    capture_start = context.Event()
    vision_recovered = context.Event()
    motion_start = context.Event()
    motion_done = context.Event()
    camera_stop = context.Event()
    camera_finished = context.Event()
    stop_requested = context.Event()

    from camera import relative_motion_raw_camera_worker
    from robot import build_relative_motion_trajectory, relative_motion_robot_worker

    # 纯计算预检只验证 UI/CLI 数字，不连接机器人；真实 A 点会在 robot worker 中重算。
    build_relative_motion_trajectory(
        selected_mode,
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        parameters,
    )

    writer_process = context.Process(
        target=record_writer_worker,
        args=(record_queue, events_path),
        name="relative-event-writer",
    )
    camera_process = context.Process(
        target=relative_motion_raw_camera_worker,
        args=(
            record_queue,
            error_queue,
            run_dir,
            stop_requested,
            camera_ready,
            capture_start,
            vision_recovered,
            camera_stop,
            camera_finished,
        ),
        name="relative-raw-camera",
    )
    robot_process = context.Process(
        target=relative_motion_robot_worker,
        args=(
            record_queue,
            error_queue,
            selected_mode,
            parameters,
            run_dir,
            stop_requested,
            robot_ready,
            motion_start,
            motion_done,
        ),
        name="relative-robot",
    )
    processes = [camera_process, robot_process]
    success = False
    failure_message: str | None = None

    writer_process.start()
    record_queue.put(
        {
            "kind": "META",
            "host_ns": time.perf_counter_ns(),
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "mode": selected_mode,
            "robot_host": config.ROBOT_HOST,
            "stop_request_path": None if stop_request_path is None else str(stop_request_path),
        },
        timeout=1.0,
    )

    try:
        _record_event(record_queue, "hardware_preparation_started", mode=selected_mode)
        print("[状态] 正在准备工业相机", flush=True)
        camera_process.start()
        robot_process.start()

        _wait_event_or_error(
            camera_ready,
            "工业相机 ready",
            error_queue,
            stop_requested,
            stop_request_path,
            timeout_s=config.WORKER_READY_TIMEOUT_S,
        )
        _wait_event_or_error(
            robot_ready,
            "机械臂 ready",
            error_queue,
            stop_requested,
            stop_request_path,
            timeout_s=config.WORKER_READY_TIMEOUT_S,
        )

        capture_start.set()
        _wait_event_or_error(
            vision_recovered,
            "手电筒同步和视野恢复",
            error_queue,
            stop_requested,
            stop_request_path,
            timeout_s=(
                config.BRIGHTNESS_BASELINE_SECONDS
                + config.FLASH_WAIT_TIMEOUT_SECONDS
                + config.FLASH_RECOVERY_TIMEOUT_SECONDS
                + config.VISION_RECOVERY_STABLE_SECONDS
                + 2.0
            ),
        )

        if stop_requested.is_set():
            raise RuntimeError("运动前收到停止请求。")
        motion_start.set()
        _wait_event_or_error(
            motion_done,
            "机械臂运动完成",
            error_queue,
            stop_requested,
            stop_request_path,
            timeout_s=config.ROBOT_MOTION_TIMEOUT_S + 10.0,
        )

        _record_event(record_queue, "camera_post_record_started")
        print("[状态] 工业相机后记录1秒", flush=True)
        _sleep_with_stop_checks(
            float(config.POST_MOTION_RECORD_SECONDS),
            error_queue,
            stop_requested,
            stop_request_path,
        )
        camera_stop.set()
        _wait_event_or_error(
            camera_finished,
            "工业相机封口",
            error_queue,
            stop_requested,
            stop_request_path,
            timeout_s=config.WORKER_JOIN_TIMEOUT_S + 10.0,
        )
        _record_event(record_queue, "experiment_completed")
        success = True
        print("[状态] 实验完成", flush=True)
    except Exception as exc:
        failure_message = f"{type(exc).__name__}: {exc}"
        stop_requested.set()
        camera_stop.set()
        try:
            _record_event(record_queue, "experiment_aborted", message=failure_message)
        except Exception:
            pass
        print("[状态] 实验失败", flush=True)
        raise
    finally:
        stop_requested.set()
        camera_stop.set()
        for process in processes:
            if process.pid is not None:
                _join_or_terminate(process)
        record_queue.put(None, timeout=2.0)
        _join_or_terminate(writer_process)
        record_queue.close()
        error_queue.close()
        _clear_stop_request_file(stop_request_path)

        _update_experiment_parameters_with_camera_fps(run_dir)
        summary = {
            "kind": "RELATIVE_MOTION_EXPERIMENT_SUMMARY",
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "mode": selected_mode,
            "success": success,
            "failure_message": failure_message,
            "run_dir": str(run_dir),
            "camera_dir": str(run_dir / "camera"),
            "robot_log": str(run_dir / "robot_log.txt"),
            "events": str(events_path),
        }
        summary_path.write_text(
            json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=True),
            encoding="utf-8",
        )

    return run_dir


class _StatusInbox:
    """Match acknowledgements from a shared multiprocessing status queue."""

    def __init__(self, status_queue: Any) -> None:
        self.queue = status_queue
        self.pending: list[dict[str, Any]] = []

    def wait(
        self,
        source: str,
        event: str,
        error_queue: Any,
        stop_event: Any,
        stop_request_path: Path | None,
        *,
        segment_base: str | None = None,
        timeout_s: float = 30.0,
    ) -> dict[str, Any]:
        deadline = time.perf_counter() + timeout_s
        while True:
            for index, item in enumerate(self.pending):
                if (
                    item.get("source") == source
                    and item.get("event") == event
                    and (segment_base is None or item.get("segment_base") == segment_base)
                ):
                    return self.pending.pop(index)
            worker_error = _pop_worker_error(error_queue)
            if worker_error:
                raise RuntimeError(worker_error)
            external_stop = _external_stop_requested(stop_request_path)
            if external_stop:
                stop_event.set()
                raise RuntimeError(f"等待 {source}/{event} 时收到用户停止请求。")
            if stop_event.is_set():
                worker_error = _wait_for_worker_error(error_queue)
                raise RuntimeError(worker_error or f"等待 {source}/{event} 时收到停止请求。")
            if time.perf_counter() >= deadline:
                raise TimeoutError(f"等待 {source}/{event} 超时。")
            try:
                self.pending.append(self.queue.get(timeout=0.05))
            except queue.Empty:
                pass


def _batch_safe_sleep(
    seconds: float,
    error_queue: Any,
    stop_event: Any,
    stop_request_path: Path | None,
) -> None:
    deadline = time.perf_counter() + float(seconds)
    while time.perf_counter() < deadline:
        worker_error = _pop_worker_error(error_queue)
        if worker_error:
            raise RuntimeError(worker_error)
        external_stop = _external_stop_requested(stop_request_path)
        if external_stop:
            stop_event.set()
            raise RuntimeError("批量状态机收到用户停止请求。")
        if stop_event.wait(min(0.05, max(0.0, deadline - time.perf_counter()))):
            worker_error = _wait_for_worker_error(error_queue)
            raise RuntimeError(worker_error or "批量状态机收到停止请求。")


def _batch_segment_meta(
    path: Path,
    batch_id: str,
    row: dict[str, Any],
    segment: dict[str, Any],
    flash: dict[str, Any],
) -> None:
    payload = {
        "kind": "BATCH_SEGMENT_META",
        "batch_id": batch_id,
        "condition_id": row["condition_id"],
        "trajectory_type": row["trajectory_type"],
        "preset_id": row["preset_id"],
        "repeat_index": row["repeat_index"],
        "speed_mm_s": row["speed_mm_s"],
        "one_way_time_s": row["one_way_time_s"],
        "nominal_one_way_distance_mm": row["nominal_one_way_distance_mm"],
        "blend_radius_mm": (
            config.ROBOT_RELATIVE_BLEND_MM if row["trajectory_type"] == "l_shape" else 0.0
        ),
        "corner_mode": "BL01" if row["trajectory_type"] == "l_shape" else "STOP",
        "acceleration_m_s2": config.ROBOT_EXPERIMENT_ACCELERATION_M_S2,
        "flash": flash,
        "segment": segment,
        "vision_processing_status": "PENDING_OFFLINE",
    }
    with path.open("x", encoding="utf-8") as file:
        file.write(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=True))


def run_batch_experiment_mode(arguments: argparse.Namespace) -> Path:
    """Run the editable plan with one camera connection and one UR connection."""

    from batch_plan import (
        allocate_batch,
        assert_outputs_available,
        enabled_plan,
        read_plan,
        segment_output_paths,
        segment_stem,
        write_segments_csv,
    )
    from camera import batch_camera_worker
    from robot import batch_robot_worker, build_relative_motion_trajectory

    if not config.ROBOT_RELATIVE_MOTION_ENABLED:
        raise PermissionError("ROBOT_RELATIVE_MOTION_ENABLED=False，批量实验被锁定。")
    if arguments.batch_plan_file is None:
        raise ValueError("batch_experiment 必须提供 --batch-plan-file。")
    if not arguments.ui_confirmed:
        from robot import require_operator_confirmation

        require_operator_confirmation("完整批量实验")

    plan = enabled_plan(read_plan(arguments.batch_plan_file))
    if not plan:
        raise ValueError("当前批量计划没有任何启用行。")
    # Pure numeric preflight: start pose is deliberately synthetic and local; no old A/B/C
    # point is imported or sent to hardware.  The worker repeats checks around the real A.
    synthetic_a = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    for row in plan:
        if row["trajectory_type"] == "static":
            continue
        build_relative_motion_trajectory(
            str(row["trajectory_type"]),
            synthetic_a,
            {
                "speed_mm_s": row["speed_mm_s"],
                "one_way_time_s": row["one_way_time_s"],
                "angle_deg": row.get("angle_deg", 45.0),
                "x_direction": row.get("x_direction", "+X"),
                "y_direction": row.get("y_direction", "+Y"),
                "blend_mm": config.ROBOT_RELATIVE_BLEND_MM,
                "acceleration_m_s2": config.ROBOT_EXPERIMENT_ACCELERATION_M_S2,
            },
        )
    naming_keys: set[tuple[str, str, int]] = set()
    for row in plan:
        key = (
            str(row["trajectory_type"]),
            str(row["condition_id"]),
            int(row["repeat_index"]),
        )
        if key in naming_keys:
            raise ValueError(
                "计划中有两行会生成相同的轨迹/条件/重复编号文件："
                f"{key}。请修改数值、重复序号或禁用其中一行。"
            )
        naming_keys.add(key)

    stop_request_path = arguments.stop_request_path
    if stop_request_path is not None and not stop_request_path.is_absolute():
        stop_request_path = (config.PROJECT_DIR / stop_request_path).resolve()
    _clear_stop_request_file(stop_request_path)
    batch_id, batch_dir = allocate_batch(config.OUTPUT_ROOT, arguments.batch_manual_label)
    all_paths: dict[int, dict[str, Path]] = {}
    planned_files: set[Path] = set()
    for row in plan:
        paths = segment_output_paths(batch_dir, batch_id, row)
        assert_outputs_available(paths)
        duplicates = planned_files.intersection(paths.values())
        if duplicates:
            duplicate_text = ", ".join(str(path.name) for path in sorted(duplicates))
            raise ValueError(
                "计划中存在会生成同名文件的条件/重复序号，请修改后再运行："
                + duplicate_text
            )
        planned_files.update(paths.values())
        all_paths[int(row["execution_order"])] = paths
    (batch_dir / "plan.json").write_text(
        json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    context = mp.get_context("spawn")
    record_queue = context.Queue(maxsize=config.RECORD_QUEUE_MAXSIZE)
    error_queue = context.Queue(maxsize=config.ERROR_QUEUE_MAXSIZE)
    camera_commands = context.Queue(maxsize=16)
    robot_commands = context.Queue(maxsize=16)
    status_queue = context.Queue(maxsize=64)
    stop_event = context.Event()
    writer = context.Process(
        target=segmented_record_writer_worker,
        args=(record_queue, batch_dir),
        name="batch-segment-writer",
    )
    camera = context.Process(
        target=batch_camera_worker,
        args=(record_queue, error_queue, camera_commands, status_queue, stop_event),
        name="batch-continuous-camera",
    )
    robot = context.Process(
        target=batch_robot_worker,
        args=(record_queue, error_queue, robot_commands, status_queue, stop_event),
        name="batch-continuous-robot",
    )
    inbox = _StatusInbox(status_queue)
    segment_rows: list[dict[str, Any]] = []
    current_row: dict[str, Any] | None = None
    flash: dict[str, Any] = {}
    batch_status = "RUNNING"
    failure_message: str | None = None
    robot_start_pose: list[float] | None = None

    writer.start()
    # 先让CB3独占完成Control/Receive初始化，再启动132 fps相机进程。
    # 这样RTDE握手不与相机预览、取流和OpenCV初始化争用CPU/网络调度；
    # 此时机器人只建立连接和读取静止位姿，尚未收到任何运动命令。
    print("[状态] 正在建立UR10控制和状态连接（此阶段不会运动）", flush=True)
    robot.start()
    try:
        robot_ready = inbox.wait(
            "robot", "READY", error_queue, stop_event, stop_request_path,
            timeout_s=config.WORKER_READY_TIMEOUT_S,
        )
        robot_start_pose = robot_ready["start_pose"]
        print("[状态] UR10已连接并确认静止，正在启动工业相机", flush=True)
        camera.start()
        camera_ready = inbox.wait(
            "camera", "READY", error_queue, stop_event, stop_request_path,
            timeout_s=config.WORKER_READY_TIMEOUT_S,
        )
        flash_ready = inbox.wait(
            "camera",
            "FLASH_READY",
            error_queue,
            stop_event,
            stop_request_path,
            timeout_s=(
                config.BRIGHTNESS_BASELINE_SECONDS
                + config.FLASH_WAIT_TIMEOUT_SECONDS
                + config.FLASH_RECOVERY_TIMEOUT_SECONDS
                + config.VISION_RECOVERY_STABLE_SECONDS
                + 2.0
            ),
        )
        flash = {
            "flash_system_ns": int(flash_ready["flash_system_ns"]),
            "flash_system_time": flash_ready["flash_system_time"],
            "flash_frame_id": int(flash_ready["frame_id"]),
            "camera_actual_fps": camera_ready.get("actual_camera_fps"),
        }
        flash_zero_ns = int(flash_ready["flash_system_ns"])
        print(f"[状态] 批次 {batch_id} 开始，硬件在整批期间保持连接", flush=True)

        for current_row in plan:
            paths = all_paths[int(current_row["execution_order"])]
            segment_base = segment_stem(batch_id, current_row)

            camera_commands.put(
                {
                    "action": "OPEN_SEGMENT",
                    "segment_base": segment_base,
                    "video_path": str(paths["video"]),
                    "vision_path": str(paths["vision"]),
                },
                timeout=1.0,
            )
            robot_commands.put(
                {
                    "action": "OPEN_SEGMENT",
                    "segment_base": segment_base,
                    "robot_path": str(paths["robot"]),
                },
                timeout=1.0,
            )
            inbox.wait(
                "camera", "SEGMENT_OPENED", error_queue, stop_event, stop_request_path,
                segment_base=segment_base,
            )
            inbox.wait(
                "robot", "SEGMENT_OPENED", error_queue, stop_event, stop_request_path,
                segment_base=segment_base,
            )
            record_queue.put(
                {
                    "kind": "EVENT",
                    "name": "segment_opened",
                    "host_ns": time.perf_counter_ns(),
                    "segment_base": segment_base,
                },
                timeout=1.0,
            )

            motion_started: dict[str, Any] | None = None
            motion_finished: dict[str, Any] | None = None
            if current_row["trajectory_type"] == "static":
                print("[状态] 正在记录5秒静止基线", flush=True)
                _batch_safe_sleep(
                    config.BATCH_STATIC_BASELINE_SECONDS,
                    error_queue,
                    stop_event,
                    stop_request_path,
                )
            else:
                print("[状态] 当前分段先记录1秒运动前静止画面", flush=True)
                _batch_safe_sleep(
                    config.BATCH_PRE_MOTION_SECONDS,
                    error_queue,
                    stop_event,
                    stop_request_path,
                )
                robot_commands.put(
                    {"action": "RUN_TRAJECTORY", "segment_base": segment_base, "row": current_row},
                    timeout=1.0,
                )
                motion_started = inbox.wait(
                    "robot", "MOTION_STARTED", error_queue, stop_event, stop_request_path,
                    segment_base=segment_base,
                )
                print(
                    f"[状态] 执行计划顺序 {current_row['execution_order']:02d}；"
                    f"本批启用 {len(plan)} 段；"
                    f"{current_row['trajectory_type']} {current_row['condition_id']} "
                    f"R{current_row['repeat_index']:02d}",
                    flush=True,
                )
                motion_finished = inbox.wait(
                    "robot",
                    "MOTION_FINISHED",
                    error_queue,
                    stop_event,
                    stop_request_path,
                    segment_base=segment_base,
                    timeout_s=config.ROBOT_MOTION_TIMEOUT_S + 10.0,
                )
                print("[状态] 已回到A点，继续记录1秒残余振动", flush=True)
                _batch_safe_sleep(
                    config.BATCH_POST_MOTION_SECONDS,
                    error_queue,
                    stop_event,
                    stop_request_path,
                )

            camera_commands.put(
                {"action": "CLOSE_SEGMENT", "segment_base": segment_base}, timeout=1.0
            )
            robot_commands.put(
                {"action": "CLOSE_SEGMENT", "segment_base": segment_base}, timeout=1.0
            )
            camera_closed = inbox.wait(
                "camera", "SEGMENT_CLOSED", error_queue, stop_event, stop_request_path,
                segment_base=segment_base,
            )
            inbox.wait(
                "robot", "SEGMENT_CLOSED", error_queue, stop_event, stop_request_path,
                segment_base=segment_base,
            )
            flash_wall_time = datetime.fromisoformat(str(flash["flash_system_time"]))
            camera_start_ns = int(camera_closed["system_start_ns"])
            camera_end_ns = int(camera_closed["system_end_ns"])
            system_start_time = (
                flash_wall_time
                + timedelta(seconds=(camera_start_ns - flash_zero_ns) / 1_000_000_000.0)
            ).isoformat(timespec="milliseconds")
            system_end_time = (
                flash_wall_time
                + timedelta(seconds=(camera_end_ns - flash_zero_ns) / 1_000_000_000.0)
            ).isoformat(timespec="milliseconds")
            actual_start_pose = (
                motion_started["actual_start_pose"] if motion_started else robot_start_pose
            )
            actual_end_pose = (
                motion_finished["actual_end_pose"] if motion_finished else robot_start_pose
            )
            segment = {
                "batch_id": batch_id,
                "execution_order": current_row["execution_order"],
                "condition_id": current_row["condition_id"],
                "trajectory_type": current_row["trajectory_type"],
                "preset_id": current_row["preset_id"],
                "repeat_index": current_row["repeat_index"],
                "speed_mm_s": current_row["speed_mm_s"],
                "one_way_time_s": current_row["one_way_time_s"],
                "nominal_one_way_distance_mm": current_row["nominal_one_way_distance_mm"],
                "actual_start_pose": actual_start_pose,
                "actual_end_pose": actual_end_pose,
                "system_start_time": system_start_time,
                "system_end_time": system_end_time,
                "batch_elapsed_start_s": (
                    camera_start_ns - flash_zero_ns
                ) / 1_000_000_000.0,
                "batch_elapsed_end_s": (
                    camera_end_ns - flash_zero_ns
                ) / 1_000_000_000.0,
                "first_frame_id": camera_closed["first_frame_id"],
                "last_frame_id": camera_closed["last_frame_id"],
                "flash_system_time": flash["flash_system_time"],
                "status": "COMPLETED",
                "output_video": str(paths["video"]),
                "manual_label": current_row["manual_label"],
            }
            segment_rows.append(segment)
            _batch_segment_meta(paths["meta"], batch_id, current_row, segment, flash)
            write_segments_csv(batch_dir / "segments.csv", segment_rows)

        batch_status = "COMPLETED"
        print("[状态] 批量运动与录像采集完成，机械臂停在A点", flush=True)
    except Exception as exc:
        failure_message = f"{type(exc).__name__}: {exc}"
        batch_status = "ABORTED" if _external_stop_requested(stop_request_path) else "FAILED"
        stop_event.set()
        completed_orders = {int(item["execution_order"]) for item in segment_rows}
        for row in plan:
            if int(row["execution_order"]) in completed_orders:
                continue
            paths = all_paths[int(row["execution_order"])]
            status = (
                "FAILED"
                if current_row is not None
                and int(row["execution_order"]) == int(current_row["execution_order"])
                else "ABORTED"
            )
            segment_rows.append(
                {
                    "batch_id": batch_id,
                    **{key: row.get(key) for key in (
                        "execution_order", "condition_id", "trajectory_type", "preset_id",
                        "repeat_index", "speed_mm_s", "one_way_time_s",
                        "nominal_one_way_distance_mm", "manual_label",
                    )},
                    "actual_start_pose": robot_start_pose,
                    "actual_end_pose": None,
                    "system_start_time": "",
                    "system_end_time": "",
                    "batch_elapsed_start_s": "",
                    "batch_elapsed_end_s": "",
                    "first_frame_id": "",
                    "last_frame_id": "",
                    "flash_system_time": flash.get("flash_system_time", ""),
                    "status": status,
                    "output_video": str(paths["video"]),
                }
            )
        write_segments_csv(batch_dir / "segments.csv", segment_rows)
        print(f"[状态] 批量实验{batch_status}：{failure_message}", flush=True)
        raise
    finally:
        stop_event.set()
        for command_queue in (camera_commands, robot_commands):
            try:
                command_queue.put({"action": "SHUTDOWN"}, timeout=0.2)
            except Exception:
                pass
        for process in (camera, robot):
            if process.pid is not None:
                _join_or_terminate(process)
        try:
            record_queue.put(None, timeout=2.0)
        except Exception:
            pass
        _join_or_terminate(writer)
        summary = {
            "kind": "BATCH_SUMMARY",
            "batch_id": batch_id,
            "status": batch_status,
            "failure_message": failure_message,
            "manual_label": arguments.batch_manual_label,
            "flash": flash,
            "sony_target_file": f"{batch_id}_SONY.mp4",
            "segment_count": len(plan),
            "completed_count": sum(item.get("status") == "COMPLETED" for item in segment_rows),
            "camera_restarted_between_segments": False,
            "vision_processing_status": (
                "PENDING_OFFLINE" if batch_status == "COMPLETED" else "NOT_STARTED"
            ),
        }
        (batch_dir / "batch_META.json").write_text(
            json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        _clear_stop_request_file(stop_request_path)

    return batch_dir


def run_micro_motion_experiment_mode(arguments: argparse.Namespace) -> Path:
    """
    一键执行 XY 最小微动标定。

    输入：命令行参数（可选 --micro-levels 限制档位、--ui-confirmed、--stop-request-path）。
    输出：本次运行目录 Path。

    流程：设备检查 → 相机预热 → 1 mm 单点 moveL 路径验证 → 磁盘/编码探测
    → 5 s 全分辨率静止基线 → X/Y × seq/alt × 各档位微动 → 自动收尾。

    与 run_batch_experiment_mode 的关系：只复用它的骨架
    （_StatusInbox、_batch_safe_sleep、_join_or_terminate、停止请求文件、
    先机器人后相机的启动顺序）和 config 参数，不共享任何录制或运动实现。

    本模式**不使用手电筒门禁**：`time.perf_counter_ns()` 是
    Windows QueryPerformanceCounter()，全机跨进程共享，实测子进程时间戳
    落在父进程窗口内，因此相机帧与机械臂步可以直接按时间戳对齐。
    """

    from micro_motion import (
        ROBOT_LOG_COLUMNS,
        STEP_COLUMNS,
        TIMELINE_COLUMNS,
        allocate_micro_run,
        build_plan,
        build_probe_move_result,
        calibrate_camera_clock,
        crop_box_for_frame,
        disk_free_bytes,
        estimate_run,
        format_gib,
        join_frames_to_steps,
        levels_from_text,
        load_frame_rows,
        micro_motion_camera_worker,
        micro_motion_robot_worker,
        probe_paths,
        read_rows_csv,
        segment_paths,
        static_paths,
        validate_probe,
        write_join_csv,
        write_rows_csv,
    )
    from robot import require_operator_confirmation

    if not config.ROBOT_RELATIVE_MOTION_ENABLED:
        raise PermissionError("ROBOT_RELATIVE_MOTION_ENABLED=False，XY 最小微动测试被锁定。")
    if not arguments.ui_confirmed:
        require_operator_confirmation("XY 最小微动一键测试")

    levels = levels_from_text(arguments.micro_levels)
    plan = build_plan(levels=levels)
    if not plan:
        raise ValueError("微动计划为空。")

    # 本段是纯软件预检：先按相机已知全幅和配置里的裁剪框估算数据量，
    # 并和磁盘可用空间比较。未压缩 RAW 是本实验最紧的现实约束，
    # 必须在接触硬件之前就把“够不够写”算清楚——也要在创建运行目录之前，
    # 否则被拒绝的运行会在 outputs 里留下一个空目录。
    planned_estimate = estimate_run(
        plan,
        camera_fps=float(config.EXPECTED_VISION_FPS or 132.0),
        frame_width=int(config.MICRO_CROP_WIDTH),
        frame_height=int(config.MICRO_CROP_HEIGHT),
        full_width=int(config.MICRO_FULL_FRAME_WIDTH),
        full_height=int(config.MICRO_FULL_FRAME_HEIGHT),
    )
    free_bytes = disk_free_bytes(config.OUTPUT_ROOT)
    print(
        f"[状态] 预计录制 {planned_estimate['wall_seconds'] / 60.0:.1f} 分钟，"
        f"未压缩 RAW 约 {format_gib(planned_estimate['bytes'])}；"
        f"磁盘可用 {format_gib(free_bytes)}",
        flush=True,
    )
    if free_bytes < planned_estimate["bytes"] * 1.15:
        raise RuntimeError(
            f"磁盘可用空间不足：需要约 {format_gib(planned_estimate['bytes'] * 1.15)}"
            f"（含 15% 余量），当前只有 {format_gib(free_bytes)}。"
            "请先清理 outputs，或减少档位（--micro-levels）。"
        )

    run_id, run_dir = allocate_micro_run(config.OUTPUT_ROOT)
    wall_anchor_ns = time.perf_counter_ns()
    wall_anchor_time = datetime.now()

    print(f"[状态] 微动实验运行目录：{run_dir}")
    print(
        f"[状态] 档位 {list(levels)} μm；{len(plan)} 段、"
        f"{sum(int(item['step_count']) for item in plan)} 步；"
        f"顺序：X连续 → X换向 → Y连续 → Y换向",
        flush=True,
    )

    timeline_rows: list[dict[str, Any]] = []
    steps_rows: list[dict[str, Any]] = []
    telemetry: dict[str, Any] = {
        "kind": "MICRO_MOTION_CONFIG",
        "run_id": run_id,
        "created_at": wall_anchor_time.isoformat(timespec="seconds"),
        "robot_host": config.ROBOT_HOST,
        "levels_um": list(levels),
        "segment_count": len(plan),
        "step_count": int(sum(int(item["step_count"]) for item in plan)),
        "plan": [
            {
                "execution_order": item["execution_order"],
                "segment_base": item["segment_base"],
                "axis": item["axis"],
                "motion_kind": item["motion_kind"],
                "level_um": item["level_um"],
                "step_count": item["step_count"],
                "directions": [step["direction"] for step in item["steps"]],
            }
            for item in plan
        ],
        "parameters": {
            key: getattr(config, key)
            for key in dir(config)
            if key.startswith("MICRO_")
        },
        "estimate": planned_estimate,
        "disk_free_bytes_before": free_bytes,
        "flash_gate": "DISABLED_BY_DESIGN (perf_counter_ns 全机共享，跨进程可直接对齐)",
        "bandwidth_note": (
            f"CB3 RTDE {config.ROBOT_RECORD_HZ:g} Hz、相机约 132.23 fps，"
            f"Nyquist 约 63–66 Hz；关注频带上限 {config.MICRO_ANALYSIS_BANDWIDTH_HZ:g} Hz。"
            "14 ms 三角运动的能量主要在高频，超出该频带的成分不能声称被测到。"
        ),
        "metrology_note": (
            "UR10 CB3 重复定位精度 ±0.1 mm（100 μm）。5–50 μm 的指令位移低于该指标，"
            "机械臂可能完全不动或不可重复；这正是本实验要标定的最小可靠微动，"
            "但指令值与实际值在约 100 μm 以下会显著分离，必须以相机测量为准。"
            "每步的 achieved 断言会把这种现象标成 INVALID，而不是伪装成数据。"
        ),
        "robot_log_columns": list(ROBOT_LOG_COLUMNS),
        "step_columns": list(STEP_COLUMNS),
        "deliverable_join_rule": (
            "每帧交付 CSV 按各步的 command_start 切分：帧属于"
            "“最后一个 command_start ≤ 该帧时间”的步，早于第一步的帧 step_id 留空。"
            "区间内再用 command_end 分 during / post。"
        ),
    }

    def write_telemetry() -> None:
        (run_dir / "experiment_config.json").write_text(
            json.dumps(telemetry, ensure_ascii=False, indent=2, allow_nan=True),
            encoding="utf-8",
        )

    def add_timeline(phase: str, segment_base: str = "", detail: str = "") -> None:
        """记录并立即落盘一个阶段节点。"""

        now_ns = time.perf_counter_ns()
        timeline_rows.append(
            {
                "phase": phase,
                "segment_base": segment_base,
                "host_ns": int(now_ns),
                "wall_time": datetime.fromtimestamp(
                    wall_anchor_time.timestamp()
                    + (now_ns - wall_anchor_ns) / 1_000_000_000.0
                ).isoformat(timespec="milliseconds"),
                "wall_elapsed_s": (now_ns - wall_anchor_ns) / 1_000_000_000.0,
                "detail": detail,
            }
        )
        write_rows_csv(run_dir / "master_timeline.csv", timeline_rows, TIMELINE_COLUMNS)

    def write_progress(stage: str, **extra: Any) -> None:
        """把当前进度写进 progress.json，崩溃后仍能看出跑到哪里。"""

        (run_dir / "progress.json").write_text(
            json.dumps(
                {
                    "stage": stage,
                    "host_ns": time.perf_counter_ns(),
                    "wall_time": datetime.now().isoformat(timespec="milliseconds"),
                    "completed_segments": len(
                        {row["segment_base"] for row in steps_rows}
                    ),
                    "planned_segments": len(plan),
                    "completed_steps": len(steps_rows),
                    "planned_steps": telemetry["step_count"],
                    "invalid_steps": sum(
                        row["status"] != "VALID" for row in steps_rows
                    ),
                    **extra,
                },
                ensure_ascii=False,
                indent=2,
                allow_nan=True,
            ),
            encoding="utf-8",
        )

    write_telemetry()
    add_timeline("run_start", detail=run_id)
    write_progress("run_start")

    stop_request_path = arguments.stop_request_path
    if stop_request_path is not None and not stop_request_path.is_absolute():
        stop_request_path = (config.PROJECT_DIR / stop_request_path).resolve()
    _clear_stop_request_file(stop_request_path)

    context = mp.get_context("spawn")
    error_queue = context.Queue(maxsize=config.ERROR_QUEUE_MAXSIZE)
    camera_commands = context.Queue(maxsize=16)
    robot_commands = context.Queue(maxsize=16)
    status_queue = context.Queue(maxsize=64)
    stop_event = context.Event()
    camera = context.Process(
        target=micro_motion_camera_worker,
        args=(error_queue, camera_commands, status_queue, stop_event),
        name="micro-motion-camera",
    )
    robot = context.Process(
        target=micro_motion_robot_worker,
        args=(error_queue, robot_commands, status_queue, stop_event, run_dir),
        name="micro-motion-robot",
    )
    inbox = _StatusInbox(status_queue)
    run_status = "RUNNING"
    failure_message: str | None = None
    final_drift_mm: float | None = None

    camera_ready: dict[str, Any] = {}
    robot_ready: dict[str, Any] = {}
    crop_box: tuple[int, int, int, int] | None = None
    actual_fps = float(config.EXPECTED_VISION_FPS or 132.0)

    try:
        # 与批量实验相同的启动顺序：先让 CB3 独占完成 Control/Receive 初始化，
        # 再启动 132 fps 相机进程，避免 RTDE 握手与相机取流、OpenCV 初始化争用调度。
        # 此阶段机器人只建立连接、读静止位姿，不收任何运动命令。
        print("[状态] 正在建立UR10控制和状态连接（此阶段不会运动）", flush=True)
        robot.start()
        robot_ready = inbox.wait(
            "robot", "READY", error_queue, stop_event, stop_request_path,
            timeout_s=config.WORKER_READY_TIMEOUT_S,
        )
        robot_start_pose = [float(value) for value in robot_ready["start_pose"]]
        print("[状态] UR10已连接并确认静止，正在启动工业相机", flush=True)
        camera.start()
        camera_ready = inbox.wait(
            "camera", "READY", error_queue, stop_event, stop_request_path,
            timeout_s=config.WORKER_READY_TIMEOUT_S,
        )
        actual_fps = float(
            camera_ready.get("actual_camera_fps") or config.EXPECTED_VISION_FPS or 132.0
        )
        full_width = int(camera_ready["full_width"])
        full_height = int(camera_ready["full_height"])
        crop_box = crop_box_for_frame(full_width, full_height)
        telemetry["camera"] = {
            "actual_fps": actual_fps,
            "full_width": full_width,
            "full_height": full_height,
            "crop_box": list(crop_box) if crop_box else None,
            "crop_note": (
                "00_static 以全分辨率录制，裁剪框可由离线重新推导；"
                "正式段按此裁剪，像元尺寸与测量分辨率不变。"
            ),
        }
        write_telemetry()
        add_timeline(
            "camera_ready",
            detail=f"{actual_fps:.3f} fps, {full_width}x{full_height}, crop={crop_box}",
        )
        print(
            f"[状态] 工业相机就绪：{actual_fps:.3f} fps，{full_width}×{full_height}，"
            f"录制裁剪框 {crop_box}",
            flush=True,
        )

        nyquist_hz = 0.5 * min(actual_fps, float(config.ROBOT_RECORD_HZ))
        if float(config.MICRO_ANALYSIS_BANDWIDTH_HZ) >= nyquist_hz:
            raise RuntimeError(
                f"关注频带上限 {config.MICRO_ANALYSIS_BANDWIDTH_HZ:g} Hz 不低于"
                f"本套硬件的 Nyquist 频率 {nyquist_hz:.2f} Hz"
                f"（相机 {actual_fps:.3f} fps，RTDE {config.ROBOT_RECORD_HZ:g} Hz）。"
            )
        telemetry["nyquist_hz"] = nyquist_hz

        # 本段先用一次 1 mm 的安全移动验证“单点 moveL”这条代码路径。
        # 现有实验模式都发 ≥2 个路径点，而微动只发 1 点
        # （execute_trajectory 发送 trajectory[1:]）；这条路径必须先验证，
        # 否则 5 μm 档的结果无从判断是真走了还是命令被丢了。
        print(
            f"[状态] 正在用 {config.MICRO_PROBE_MOVE_UM / 1000.0:g} mm 安全移动验证"
            "单点 moveL 路径（往返各一次）",
            flush=True,
        )
        add_timeline("probe_move_start")
        robot_commands.put(
            {"action": "PROBE_MOVE", "axis": "X", "sign": 1.0}, timeout=1.0
        )
        probe_move_msg = inbox.wait(
            "robot", "PROBE_MOVE_DONE", error_queue, stop_event, stop_request_path,
            timeout_s=(
                config.MICRO_STEP_TIMEOUT_S * 2.0 + config.MICRO_STABLE_TIMEOUT_S * 4.0 + 20.0
            ),
        )
        probe_move_result = build_probe_move_result(probe_move_msg)
        telemetry["probe_move"] = probe_move_result
        write_telemetry()
        add_timeline("probe_move_done", detail=str(probe_move_result.get("detail", "")))
        print(f"[状态] 单点路径验证：{probe_move_result['detail']}", flush=True)

        # 本段是磁盘/编码探测：用与正式段完全相同的写入路径和裁剪，
        # 实拍一段未压缩 RAW，核对帧率、帧号连续性、缺帧率和字节数。
        probe = probe_paths(run_dir)
        probe["directory"].mkdir(parents=True, exist_ok=True)
        print(
            f"[状态] 正在做 {config.MICRO_PROBE_SECONDS:g} 秒磁盘/编码探测"
            "（与正式段相同的写入路径和裁剪）",
            flush=True,
        )
        add_timeline("disk_probe_start")
        camera_commands.put(
            {
                "action": "OPEN_SEGMENT",
                "segment_base": "disk_probe",
                "raw_path": str(probe["raw"]),
                "frames_csv_path": str(probe["frames"]),
                "meta_path": str(probe["meta"]),
                "crop": list(crop_box) if crop_box else None,
            },
            timeout=1.0,
        )
        inbox.wait(
            "camera", "SEGMENT_OPENED", error_queue, stop_event, stop_request_path,
            segment_base="disk_probe",
        )
        _batch_safe_sleep(
            config.MICRO_PROBE_SECONDS, error_queue, stop_event, stop_request_path
        )
        camera_commands.put({"action": "CLOSE_SEGMENT", "segment_base": "disk_probe"}, timeout=1.0)
        probe_closed = inbox.wait(
            "camera", "SEGMENT_CLOSED", error_queue, stop_event, stop_request_path,
            segment_base="disk_probe",
        )
        probe_meta = json.loads(Path(probe_closed["meta_path"]).read_text(encoding="utf-8"))
        probe_frames = load_frame_rows(probe["frames"])
        calibration = calibrate_camera_clock(probe_frames)
        probe_report = validate_probe(
            meta=probe_meta,
            closed=probe_closed,
            expected_fps=actual_fps,
            probe_move=probe_move_result,
            calibration=calibration,
        )
        probe["csv"].write_text(
            json.dumps(probe_report, ensure_ascii=False, indent=2, allow_nan=True),
            encoding="utf-8",
        )
        telemetry["disk_probe"] = probe_report
        telemetry["camera_clock_calibration"] = calibration
        write_telemetry()
        add_timeline(
            "disk_probe_done",
            detail=f"passed={probe_report['passed']} fps={probe_report['effective_fps']:.3f}",
        )
        for item in probe_report["checks"]:
            print(
                f"[状态] 探测检查·{item['name']}："
                f"{'通过' if item['passed'] else '未通过'} — {item['detail']}",
                flush=True,
            )
        if not probe_report["passed"]:
            failed = "；".join(
                f"{item['name']}（{item['detail']}）"
                for item in probe_report["checks"]
                if not item["passed"]
            )
            raise RuntimeError(
                "磁盘/编码探测未通过，已中止，且不会降级到有损编码："
                + failed
                + "。请检查磁盘写入性能，或减少档位后重试。"
            )
        print("[状态] 磁盘/编码探测通过，开始正式微动测试", flush=True)

        # 本段是静止基线。刻意用**全分辨率**录制：裁剪框是在定位到目标之前
        # 就固定下来的，保留一张全幅画面才能让离线分析重新推导裁剪框。
        static = static_paths(run_dir)
        static["directory"].mkdir(parents=True, exist_ok=True)
        camera_commands.put(
            {
                "action": "OPEN_SEGMENT",
                "segment_base": "static",
                "raw_path": str(static["raw"]),
                "frames_csv_path": str(static["frames"]),
                "meta_path": str(static["meta"]),
                "crop": None,
            },
            timeout=1.0,
        )
        inbox.wait(
            "camera", "SEGMENT_OPENED", error_queue, stop_event, stop_request_path,
            segment_base="static",
        )
        print(
            f"[状态] 正在记录 {config.MICRO_STATIC_BASELINE_SECONDS:g} 秒静止基线（全分辨率）",
            flush=True,
        )
        _batch_safe_sleep(
            config.MICRO_STATIC_BASELINE_SECONDS, error_queue, stop_event, stop_request_path
        )
        camera_commands.put({"action": "CLOSE_SEGMENT", "segment_base": "static"}, timeout=1.0)
        static_closed = inbox.wait(
            "camera", "SEGMENT_CLOSED", error_queue, stop_event, stop_request_path,
            segment_base="static",
        )
        static_frames = load_frame_rows(static["frames"])
        write_join_csv(
            static["csv"],
            join_frames_to_steps(
                static_frames,
                [],
                segment_base="static",
                wall_anchor_ns=wall_anchor_ns,
                wall_anchor_time=wall_anchor_time,
                phase_for_unassigned="static",
            ),
        )
        telemetry["static_baseline"] = {
            "raw_path": str(static["raw"]),
            "frame_count": int(static_closed["frame_count"]),
            "width": int(static_closed["width"]),
            "height": int(static_closed["height"]),
            "missing_frames": int(static_closed["missing_frames"]),
            "full_resolution": True,
        }
        write_telemetry()
        add_timeline("static_done", detail=f"{static_closed['frame_count']} frames full-res")
        write_progress("static_done")

        # 本段是主循环：逐段开录像、逐步发微动、逐段封口并把帧号标到步号上。
        for segment in plan:
            base = str(segment["segment_base"])
            paths = segment_paths(run_dir, base)
            paths["directory"].mkdir(parents=True, exist_ok=True)
            add_timeline("segment_open", base)
            write_progress("segment_running", current_segment=base)

            camera_commands.put(
                {
                    "action": "OPEN_SEGMENT",
                    "segment_base": base,
                    "raw_path": str(paths["raw"]),
                    "frames_csv_path": str(paths["frames"]),
                    "meta_path": str(paths["meta"]),
                    "crop": list(crop_box) if crop_box else None,
                },
                timeout=1.0,
            )
            robot_commands.put(
                {"action": "OPEN_SEGMENT", "segment_base": base}, timeout=1.0
            )
            inbox.wait(
                "camera", "SEGMENT_OPENED", error_queue, stop_event, stop_request_path,
                segment_base=base,
            )
            inbox.wait(
                "robot", "SEGMENT_OPENED", error_queue, stop_event, stop_request_path,
                segment_base=base,
            )

            print(
                f"[状态] 顺序 {int(segment['execution_order']):02d}/{len(plan)}："
                f"{base}（{segment['axis']} 轴 {segment['level_um']} μm，"
                f"{'连续同向' if segment['motion_kind'] == 'seq' else '频繁换向'}，"
                f"{segment['step_count']} 步）",
                flush=True,
            )

            segment_step_rows: list[dict[str, Any]] = []
            for step in segment["steps"]:
                _batch_safe_sleep(
                    config.MICRO_PRE_RECORD_SECONDS, error_queue, stop_event, stop_request_path
                )
                robot_commands.put(
                    {
                        "action": "STEP",
                        "segment_base": base,
                        "step_id": step["step_id"],
                        "axis": step["axis"],
                        "delta_um": step["delta_um"],
                        "timeout_s": config.MICRO_STEP_TIMEOUT_S,
                    },
                    timeout=1.0,
                )
                finished = inbox.wait(
                    "robot", "STEP_FINISHED", error_queue, stop_event, stop_request_path,
                    segment_base=base,
                    timeout_s=(
                        config.MICRO_STABLE_TIMEOUT_S * 2.0
                        + config.MICRO_STEP_TIMEOUT_S
                        + 20.0
                    ),
                )
                row = {
                    "segment_base": base,
                    "axis": step["axis"],
                    "motion_kind": step["motion_kind"],
                    "level_um": step["level_um"],
                    "step_index": step["step_index"],
                    "step_id": step["step_id"],
                    "direction": step["direction"],
                    "command_um": step["command_um"],
                    "delta_um": step["delta_um"],
                    "command_start_ns": int(finished["command_start_ns"]),
                    "command_end_ns": int(finished["command_end_ns"]),
                    "tcp_before": ";".join(
                        f"{float(value):.9f}" for value in finished["tcp_before"]
                    ),
                    "tcp_after": ";".join(
                        f"{float(value):.9f}" for value in finished["tcp_after"]
                    ),
                    "tcp_axis_before_um": f"{float(finished['tcp_axis_before_um']):.3f}",
                    "tcp_axis_after_um": f"{float(finished['tcp_axis_after_um']):.3f}",
                    "achieved_um": f"{float(finished['achieved_um']):+.3f}",
                    "expected_um": f"{float(finished['expected_um']):+.3f}",
                    "transverse_um": f"{float(finished['transverse_um']):.3f}",
                    "status": str(finished["status"]),
                    "note": str(finished.get("note", "")),
                }
                segment_step_rows.append(row)
                steps_rows.append(row)
                if row["status"] != "VALID":
                    print(
                        f"[状态警告] {step['step_id']} 指令 "
                        f"{step['delta_um']:+d} μm，实测 "
                        f"{float(finished['achieved_um']):+.2f} μm，"
                        f"状态 {row['status']}：{row['note']}",
                        flush=True,
                    )
                _batch_safe_sleep(
                    config.MICRO_POST_RECORD_SECONDS, error_queue, stop_event, stop_request_path
                )

            camera_commands.put({"action": "CLOSE_SEGMENT", "segment_base": base}, timeout=1.0)
            robot_commands.put({"action": "CLOSE_SEGMENT", "segment_base": base}, timeout=1.0)
            segment_closed = inbox.wait(
                "camera", "SEGMENT_CLOSED", error_queue, stop_event, stop_request_path,
                segment_base=base,
            )
            robot_closed = inbox.wait(
                "robot", "SEGMENT_CLOSED", error_queue, stop_event, stop_request_path,
                segment_base=base,
            )
            final_drift_mm = float(robot_closed["global_drift_mm"])

            # 相机只写 frame_id / 时间戳；步号由这里按 command_start/command_end
            # 离线 join 得到。相机侧打标要等每帧才排空一次命令队列，
            # 边界精度只有 1–2 帧，而那恰好是微动前后最关键的帧。
            segment_frames = load_frame_rows(paths["frames"])
            write_join_csv(
                paths["csv"],
                join_frames_to_steps(
                    segment_frames,
                    segment_step_rows,
                    segment_base=base,
                    wall_anchor_ns=wall_anchor_ns,
                    wall_anchor_time=wall_anchor_time,
                ),
            )
            write_rows_csv(run_dir / "steps.csv", steps_rows, STEP_COLUMNS)
            invalid = sum(row["status"] != "VALID" for row in segment_step_rows)
            add_timeline(
                "segment_close",
                base,
                detail=(
                    f"frames={segment_closed['frame_count']} "
                    f"missing={segment_closed['missing_frames']} "
                    f"max_gap={segment_closed['max_frame_gap']} "
                    f"invalid_steps={invalid} "
                    f"segment_return_mm={float(robot_closed['segment_return_mm']):.4f} "
                    f"global_drift_mm={final_drift_mm:.4f}"
                ),
            )
            write_progress("segment_done", last_segment=base)
            _batch_safe_sleep(
                config.MICRO_INTER_SEGMENT_SECONDS, error_queue, stop_event, stop_request_path
            )

        run_status = "COMPLETED"
        print(
            f"[状态] 全部 {len(plan)} 段微动完成。机械臂全程净位移为 0，"
            f"当前相对实验起点偏差 {final_drift_mm if final_drift_mm is not None else 0.0:.4f} mm。",
            flush=True,
        )
    except Exception as exc:
        failure_message = f"{type(exc).__name__}: {exc}"
        run_status = "ABORTED" if _external_stop_requested(stop_request_path) else "FAILED"
        stop_event.set()
        print(f"[状态] 微动实验{run_status}：{failure_message}", flush=True)
        raise
    finally:
        stop_event.set()
        for command_queue in (camera_commands, robot_commands):
            try:
                command_queue.put({"action": "SHUTDOWN"}, timeout=0.2)
            except Exception:
                pass
        for process in (camera, robot):
            if process.pid is not None:
                _join_or_terminate(process)

        add_timeline("run_end", detail=f"status={run_status}")
        telemetry["status"] = run_status
        telemetry["failure_message"] = failure_message
        telemetry["finished_at"] = datetime.now().isoformat(timespec="seconds")
        telemetry["disk_free_bytes_after"] = disk_free_bytes(config.OUTPUT_ROOT)
        telemetry["final_global_drift_mm"] = final_drift_mm
        telemetry["invalid_step_count"] = sum(
            row["status"] != "VALID" for row in steps_rows
        )
        telemetry["valid_step_count"] = sum(
            row["status"] == "VALID" for row in steps_rows
        )
        if steps_rows:
            telemetry["steps_csv"] = str(run_dir / "steps.csv")
            telemetry["master_timeline_csv"] = str(run_dir / "master_timeline.csv")
            telemetry["robot_log_csv"] = str(run_dir / "robot_log.csv")
        write_telemetry()
        write_progress("run_end", status=run_status)

        # 逐步统计：按 (轴, 类型, 档位) 汇总有效率和实测位移，
        # 让操作者不必打开 44 个 CSV 就能看出“最小可靠微动”大致落在哪一档。
        if steps_rows:
            summary: dict[str, dict[str, Any]] = {}
            for row in steps_rows:
                key = row["segment_base"].rsplit("_", 1)[0]
                bucket = summary.setdefault(
                    key,
                    {
                        "axis": row["axis"],
                        "motion_kind": row["motion_kind"],
                        "level_um": row["level_um"],
                        "steps": 0,
                        "valid": 0,
                        "mean_abs_achieved_um": 0.0,
                        "max_transverse_um": 0.0,
                    },
                )
                bucket["steps"] += 1
                if row["status"] == "VALID":
                    bucket["valid"] += 1
                bucket["mean_abs_achieved_um"] += abs(float(row["achieved_um"]))
                bucket["max_transverse_um"] = max(
                    bucket["max_transverse_um"], float(row["transverse_um"])
                )
            for bucket in summary.values():
                bucket["mean_abs_achieved_um"] = round(
                    bucket["mean_abs_achieved_um"] / max(1, bucket["steps"]), 3
                )
                bucket["valid_ratio"] = round(bucket["valid"] / max(1, bucket["steps"]), 3)
                bucket["max_transverse_um"] = round(bucket["max_transverse_um"], 3)
            write_rows_csv(
                run_dir / "summary_by_level.csv",
                [
                    {"group": key, **value}
                    for key, value in summary.items()
                ],
                (
                    "group", "axis", "motion_kind", "level_um", "steps", "valid",
                    "valid_ratio", "mean_abs_achieved_um", "max_transverse_um",
                ),
            )
        _clear_stop_request_file(stop_request_path)

    return run_dir


def run_boundary_check_mode(arguments: argparse.Namespace) -> Path:
    """Run the low-speed, no-flash, operator-observed envelope route."""

    from batch_plan import compute_plan_envelope, enabled_plan, read_plan
    from camera import boundary_camera_preview_worker
    from robot import boundary_check_robot_worker

    if arguments.batch_plan_file is None:
        raise ValueError("boundary_check 必须提供 --batch-plan-file。")
    if not arguments.ui_confirmed:
        from robot import require_operator_confirmation

        require_operator_confirmation("计算并检查视野边界")
    plan = enabled_plan(read_plan(arguments.batch_plan_file))
    envelope = compute_plan_envelope(plan)
    if not envelope:
        raise ValueError("当前启用计划没有运动轨迹，无法执行边界检查。")
    stop_request_path = arguments.stop_request_path
    if stop_request_path is not None and not stop_request_path.is_absolute():
        stop_request_path = (config.PROJECT_DIR / stop_request_path).resolve()
    _clear_stop_request_file(stop_request_path)
    output_dir = config.OUTPUT_ROOT / f"boundary_check_{datetime.now():%Y%m%d_%H%M%S}"
    output_dir.mkdir(parents=True, exist_ok=False)
    (output_dir / "envelope.json").write_text(
        json.dumps(envelope, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    context = mp.get_context("spawn")
    error_queue = context.Queue(maxsize=config.ERROR_QUEUE_MAXSIZE)
    status_queue = context.Queue(maxsize=32)
    stop_event = context.Event()
    camera = context.Process(
        target=boundary_camera_preview_worker,
        args=(error_queue, status_queue, stop_event),
        name="boundary-camera-preview",
    )
    robot = context.Process(
        target=boundary_check_robot_worker,
        args=(error_queue, status_queue, envelope, stop_event),
        name="boundary-robot",
    )
    inbox = _StatusInbox(status_queue)
    camera.start()
    try:
        inbox.wait(
            "camera", "READY", error_queue, stop_event, stop_request_path,
            timeout_s=config.WORKER_READY_TIMEOUT_S,
        )
        robot.start()
        ready = inbox.wait(
            "robot", "READY", error_queue, stop_event, stop_request_path,
            timeout_s=config.WORKER_READY_TIMEOUT_S,
        )
        print(f"[状态] 边界检查A点：{ready['start_pose']}", flush=True)
        finished = inbox.wait(
            "robot", "FINISHED", error_queue, stop_event, stop_request_path,
            timeout_s=config.ROBOT_MOTION_TIMEOUT_S * max(1, len(envelope)),
        )
        (output_dir / "result.json").write_text(
            json.dumps({"status": "COMPLETED", **finished}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        print("[状态] 视野边界检查完成，已回到A点；不会自动开始正式实验", flush=True)
    finally:
        stop_event.set()
        for process in (robot, camera):
            if process.pid is not None:
                _join_or_terminate(process)
        _clear_stop_request_file(stop_request_path)
    return output_dir


def run_batch_vision_offline_mode(arguments: argparse.Namespace) -> Path:
    """Explicitly process a finished batch; this mode never opens camera or UR."""

    from camera import write_batch_segment_vision

    batch_dir = arguments.batch_dir
    if batch_dir is None:
        candidates = sorted(
            (
                path
                for path in config.OUTPUT_ROOT.iterdir()
                if path.is_dir() and (path / "segments.csv").exists()
            ),
            key=lambda path: path.stat().st_mtime,
            reverse=True,
        )
        if not candidates:
            raise FileNotFoundError("outputs 中没有包含 segments.csv 的批次目录。")
        batch_dir = candidates[0]
    if not batch_dir.is_absolute():
        batch_dir = (config.PROJECT_DIR / batch_dir).resolve()
    segments_path = batch_dir / "segments.csv"
    if not segments_path.exists():
        raise FileNotFoundError(f"批次目录缺少 segments.csv：{segments_path}")
    with segments_path.open("r", encoding="utf-8-sig", newline="") as file:
        segments = list(csv.DictReader(file))

    processed_segments = 0
    skipped_segments = 0
    try:
        for segment in segments:
            if segment.get("status") != "COMPLETED":
                continue
            video_path = Path(segment["output_video"])
            if not video_path.is_absolute():
                video_path = batch_dir / video_path
            elif not video_path.exists():
                # Allow an intact batch folder to be copied to another computer.
                video_path = batch_dir / video_path.name
            vision_path = video_path.with_name(video_path.name.replace("_HIK.avi", "_VISION.txt"))
            timestamp_path = video_path.with_name(
                video_path.name.replace("_HIK.avi", "_FRAME_TIMESTAMPS.csv")
            )
            if vision_path.exists():
                print(f"[离线识别] 已存在，跳过且不覆盖：{vision_path.name}", flush=True)
                skipped_segments += 1
                continue
            segment_base = video_path.name.removesuffix("_HIK.avi")
            count = write_batch_segment_vision(
                video_path, timestamp_path, vision_path, segment_base
            )
            meta_path = video_path.with_name(video_path.name.replace("_HIK.avi", "_META.json"))
            if meta_path.exists():
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
                meta["vision_processing"] = {
                    "mode": "explicit_batch_vision_offline",
                    "processed_at": datetime.now().isoformat(timespec="seconds"),
                    "frame_count": count,
                    "timestamp_sidecar": str(timestamp_path),
                    "uses_original_hardware_frame_id_and_host_ns": True,
                }
                meta["vision_processing_status"] = "COMPLETED"
                meta_path.write_text(
                    json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
                )
            processed_segments += 1
            print(
                f"[离线识别] {processed_segments} 段完成：{vision_path.name}，{count} 帧",
                flush=True,
            )
    except Exception:
        batch_meta_path = batch_dir / "batch_META.json"
        if batch_meta_path.exists():
            batch_meta = json.loads(batch_meta_path.read_text(encoding="utf-8"))
            batch_meta["vision_processing_status"] = "FAILED"
            batch_meta_path.write_text(
                json.dumps(batch_meta, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        raise

    batch_meta_path = batch_dir / "batch_META.json"
    if batch_meta_path.exists():
        batch_meta = json.loads(batch_meta_path.read_text(encoding="utf-8"))
        batch_meta["vision_processing_status"] = "COMPLETED"
        batch_meta["vision_processed_at"] = datetime.now().isoformat(timespec="seconds")
        batch_meta["vision_processed_segments"] = processed_segments
        batch_meta["vision_skipped_existing_segments"] = skipped_segments
        batch_meta_path.write_text(
            json.dumps(batch_meta, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    print(
        f"[状态] 批次离线视觉完成：新生成 {processed_segments} 段，跳过 {skipped_segments} 段",
        flush=True,
    )
    return batch_dir


def run_experiment_mode() -> Path:
    """
    用户选择 experiment 后进入这里，这是完整预实验的总流程。

    输入：
    - config.py 中的视觉来源、机器人轨迹、安全开关、记录时长；
    - 操作者在终端中的最后确认。

    输出：
    - experiment_时间戳 文件夹；
    - run_log.txt，其中混合保存 META、EVENT、VISION、ROBOT、ERROR 等记录。

    实验作用：
    - 相机进程负责取图和视觉计算；
    - 机器人进程负责连接 UR、执行轨迹和记录状态；
    - 写日志进程负责把两边数据按到达顺序落盘；
    - 主进程负责等 ready、发 start、等运动完成、保留后记录时间并统一收尾。
    只有这个模式使用多进程；单模块测试保持单进程，便于读代码和定位报错。
    """

    # 本段选择 Windows 友好的子进程启动方式。
    # 输入：三个 worker 函数；输出：独立 Python 子进程。
    # 可以把 spawn 理解为“重新启动一个 Python，再让它执行指定函数”。
    context = mp.get_context("spawn")

    # 本段建立两条跨进程消息通道。
    # record_queue 输出到 run_log.txt；error_queue 输出到主程序异常处理。
    # 实验数据走 record_queue，故障信息走 error_queue，二者分开能让主程序更快响应错误。
    record_queue = context.Queue(maxsize=config.RECORD_QUEUE_MAXSIZE)
    error_queue = context.Queue(maxsize=config.ERROR_QUEUE_MAXSIZE)

    # 本段建立完整实验的流程信号。
    # 输入/输出都是跨进程 Event：某一方置位，其他进程就能读到。
    # start_event：主进程通知相机和机器人同时进入正式阶段。
    # stop_event：主进程或异常路径通知所有子进程尽快收尾。
    # camera_ready / robot_ready：子进程告诉主进程“我已经准备好”。
    # motion_done：机器人告诉主进程“运动阶段已经结束”。
    start_event = context.Event()
    stop_event = context.Event()
    camera_ready = context.Event()
    robot_ready = context.Event()
    motion_done = context.Event()

    # 本段创建本次实验的输出目录。
    # 输入：当前日期时间；输出：experiment_时间戳 文件夹和其中的 run_log.txt 路径。
    # 实验作用：每次正式实验单独存档，避免日志互相覆盖。
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = config.OUTPUT_ROOT / f"experiment_{timestamp}"
    run_dir.mkdir(parents=True, exist_ok=True)
    log_path = run_dir / "run_log.txt"

    # 本段加载完整实验真正需要的相机和机器人入口。
    # 延迟导入让普通帮助、配置检查或分析模式不会被硬件依赖提前卡住。
    from camera import camera_worker
    from robot import (
        build_trajectory,
        require_operator_confirmation,
        robot_worker,
        validate_trajectory,
    )

    # 本段在启动硬件子进程前做轨迹安全检查。
    # 输入：config.py 中生成的轨迹；输出：允许继续或直接抛错。
    # 实验作用：示例位姿、越界轨迹或过长线段会在这里停止，不让它进入真机流程。
    validate_trajectory(build_trajectory(), for_real_robot=True)

    # 本段定义三个长期运行的子进程。
    # 输入：队列和事件信号；输出：三个还未 start 的 Process 对象。
    # 实验作用：把写文件、取图识别、机器人控制分开，避免某一类工作阻塞另一类工作。
    writer_process = context.Process(
        target=record_writer_worker,
        args=(record_queue, log_path),
        name="record-writer",
    )
    camera_process = context.Process(
        target=camera_worker,
        args=(
            record_queue,
            error_queue,
            start_event,
            stop_event,
            camera_ready,
        ),
        name="camera-worker",
    )
    robot_process = context.Process(
        target=robot_worker,
        args=(
            record_queue,
            error_queue,
            start_event,
            stop_event,
            robot_ready,
            motion_done,
        ),
        name="robot-worker",
    )
    processes = [camera_process, robot_process]

    # 本段先启动写日志进程，并写入本次实验的 META。
    # 输入：config.py 中关键实验参数；输出：run_log.txt 第一类说明性记录。
    # 实验作用：后续即使只拿到日志文件，也能知道当时用的是哪种视觉来源、轨迹和坐标配置。
    writer_process.start()
    meta = {
        "kind": "META",
        "host_ns": time.perf_counter_ns(),
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "mode": "experiment",
        "vision_source": config.VISION_SOURCE,
        "vision_method": config.VISION_METHOD,
        "expected_vision_fps": config.EXPECTED_VISION_FPS,
        "save_point_coordinates": config.SAVE_POINT_COORDINATES,
        "spatial_coordinates_enabled": config.SPATIAL_COORDINATES_ENABLED,
        "spatial_coordinate_mode": config.SPATIAL_COORDINATE_MODE,
        "trajectory_type": config.TRAJECTORY_TYPE,
        "control_mode": config.CONTROL_MODE,
        "executor_mode": config.EXECUTOR_MODE,
        "pre_record_seconds": config.PRE_RECORD_SECONDS,
        "post_record_seconds": config.POST_RECORD_SECONDS,
        "robot_record_hz": config.ROBOT_RECORD_HZ,
    }
    record_queue.put(meta, timeout=1.0)

    try:
        # 本段启动相机和机器人，但暂不开始正式运动。
        # 输入：两个子进程；输出：camera_ready 和 robot_ready 最终都被置位。
        # 实验作用：确保相机能取图、机器人能连接并通过起点/轨迹检查后，再进入人工确认。
        camera_process.start()
        robot_process.start()
        _wait_ready(camera_ready, robot_ready, error_queue, stop_event)
        _record_event(record_queue, "all_workers_ready")

        # 本段是正式开始前的最后人工闸门。
        # 输入：操作者在终端输入的确认文本；输出：start_event 置位。
        # 实验作用：只有人确认现场安全后，相机和机器人才同时进入正式实验阶段。
        require_operator_confirmation("相机 + UR10 正式振动预实验")
        _record_event(record_queue, "experiment_started")
        start_event.set()

        # 本段等待机器人完成运动阶段。
        # 输入：robot_worker 置位的 motion_done；输出：进入 post 后记录阶段或因错误停止。
        # 实验作用：主程序不插手每个运动采样点，只监督运动阶段是否结束。
        _wait_motion_done(motion_done, error_queue, stop_event)
        print(
            f"[主程序] 运动阶段完成，继续记录 {config.POST_RECORD_SECONDS:.2f} s 残余振动。"
        )

        # 本段保持相机和机器人状态记录继续运行一小段时间。
        # 输入：POST_RECORD_SECONDS；输出：run_log.txt 中的后记录段。
        # 实验作用：观察机械臂运动结束后的残余振动如何衰减。
        post_deadline = time.perf_counter() + config.POST_RECORD_SECONDS
        while time.perf_counter() < post_deadline:
            worker_error = _pop_worker_error(error_queue)
            if worker_error:
                raise RuntimeError(worker_error)
            if stop_event.is_set():
                raise RuntimeError("后记录期间某个子进程异常停止。")
            time.sleep(0.05)

        _record_event(record_queue, "experiment_finished")
        stop_event.set()
    except Exception as exc:
        # 本段是完整实验的统一失败出口。
        # 输入：ready、运动、后记录、写队列等任意阶段抛出的异常。
        # 输出：stop_event 置位，并尽量把 ERROR 记录写进 run_log.txt。
        # 实验作用：出现问题时优先让硬件相关子进程收尾，日志里也留下失败原因。
        stop_event.set()
        try:
            record_queue.put(
                {
                    "kind": "ERROR",
                    "host_ns": time.perf_counter_ns(),
                    "message": f"{type(exc).__name__}: {exc}",
                },
                timeout=1.0,
            )
        except queue.Full:
            pass
        raise
    finally:
        # 本段是完整实验的统一收尾出口。
        # 输入：当前仍存在的子进程、队列和 stop_event；输出：子进程退出，队列关闭。
        # 实验作用：无论成功还是失败，都尽量避免留下后台取图、机器人连接或写文件进程。
        stop_event.set()

        # 只回收已经成功 start 的进程；pid 非空说明这个 Process 确实启动过。
        for process in processes:
            if process.pid is not None:
                _join_or_terminate(process)

        # 所有生产者停止后再发 None，保证队列中排在它前面的记录先全部落盘。
        record_queue.put(None, timeout=2.0)
        _join_or_terminate(writer_process)

        record_queue.close()
        error_queue.close()

    print(f"[主程序] 正式实验完成，原始记录：{log_path}")
    print("[主程序] 把 RUN_MODE 改为 analyze，即可生成时域、频域和摘要结果。")
    return run_dir


# =============================================================================
# 3. 命令行与总分流：程序启动后最先经过的用户选择入口
# =============================================================================

def _parse_arguments() -> argparse.Namespace:
    """
    读取用户在终端里临时补充的运行选项。

    输入：终端命令，例如 python main.py --mode robot_dry_run。
    输出：arguments 对象，其中包含 mode、analysis_file 等字段。

    实验作用：命令行参数是临时覆盖，不会改写 config.py 文件本身。
    例如你可以临时跑一次 robot_dry_run，而不用把 RUN_MODE 来回改动。
    """

    # 本段创建命令行解析器。输入是用户敲的参数；输出是可读的 Python 字段。
    # argparse 还会自动生成 --help 页面，并帮忙检查 mode 是否在允许列表中。
    parser = argparse.ArgumentParser(
        description="UR10 末端振动预实验：视觉、轨迹、真机、完整实验与离线分析。"
    )

    # 本段给用户一个临时改模式的入口。
    # 输入：--mode 后面的字符串；输出：arguments.mode。
    # 实验作用：同一份 config.py 不变，也能临时切到视觉测试、干跑或分析模式。
    parser.add_argument(
        "--mode",
        choices=sorted(config.VALID_RUN_MODES),
        default=None,
        help="临时覆盖 config.py 的 RUN_MODE。",
    )

    # 本段给 analyze 模式一个临时指定日志文件的入口。
    # 输入：--analysis-file 后面的路径；输出：arguments.analysis_file。
    # 实验作用：可以复查某一次指定实验，而不是总分析 outputs 里最新的一次。
    parser.add_argument(
        "--analysis-file",
        type=Path,
        default=None,
        help="analyze 模式下临时指定 run_log.txt 或 vision_results.txt。",
    )

    parser.add_argument("--speed-mm-s", type=float, default=config.ROBOT_EXPERIMENT_DEFAULT_SPEED_MM_S)
    parser.add_argument(
        "--one-way-time-s",
        type=float,
        default=None,
        help=(
            "A 到最远点的单程时间；省略时按轨迹使用缩短后的 X/D 或已验证的 L 默认值。"
        ),
    )
    parser.add_argument("--total-time-s", type=float, default=config.ROBOT_EXPERIMENT_DEFAULT_TOTAL_TIME_S)
    parser.add_argument("--angle-deg", type=float, default=config.ROBOT_EXPERIMENT_DEFAULT_ANGLE_DEG)
    parser.add_argument("--x-direction", choices=["+X", "-X"], default="+X")
    parser.add_argument("--y-direction", choices=["+Y", "-Y"], default="+Y")
    parser.add_argument("--x-speed-mm-s", type=float, default=config.ROBOT_EXPERIMENT_DEFAULT_SPEED_MM_S)
    parser.add_argument(
        "--x-one-way-time-s",
        type=float,
        default=config.ROBOT_EXPERIMENT_DEFAULT_X_ONE_WAY_TIME_S,
    )
    parser.add_argument("--y-speed-mm-s", type=float, default=config.ROBOT_EXPERIMENT_DEFAULT_SPEED_MM_S)
    parser.add_argument(
        "--y-one-way-time-s",
        type=float,
        default=config.ROBOT_EXPERIMENT_DEFAULT_Y_ONE_WAY_TIME_S,
    )
    parser.add_argument("--blend-mm", type=float, default=config.ROBOT_RELATIVE_BLEND_MM)
    parser.add_argument(
        "--batch-plan-file",
        type=Path,
        default=None,
        help="batch_experiment / boundary_check 使用的已编辑计划 JSON。",
    )
    parser.add_argument(
        "--batch-manual-label",
        default="",
        help="批次基础名称末尾的可选人工标签。",
    )
    parser.add_argument(
        "--batch-dir",
        type=Path,
        default=None,
        help="batch_vision_offline 要处理的已完成批次目录；省略时取最新批次。",
    )
    parser.add_argument(
        "--micro-levels",
        default=None,
        help=(
            "micro_motion_experiment 的档位列表，例如 200,100,50；"
            "省略时使用 config.MICRO_LEVELS_UM 的全部档位。"
        ),
    )
    parser.add_argument(
        "--ui-confirmed",
        action="store_true",
        help="启动器已完成索尼录像、路径方向、无人区和急停确认。",
    )
    parser.add_argument(
        "--stop-request-path",
        type=Path,
        default=None,
        help="启动器为本次运动实验写入的 run 级停止请求文件。",
    )

    # 本段真正读取终端参数，并把字符串转换成 Python 可用的对象。
    return parser.parse_args()


def main() -> Path:
    """
    用户启动程序后真正执行的总流程。

    输入：
    - config.py 中的默认配置；
    - 可选命令行参数，例如 --mode 或 --analysis-file。

    输出：
    - 被选中模式创建的输出目录 Path。

    实验作用：
    - 它是全项目唯一的总分流点；
    - 它先确认“这次到底要跑什么”，再做配置检查，最后只进入一个模式入口；
    - 视觉、机器人、分析的具体工作都不在这里完成，而是在对应模块里完成。
    """

    # 本段读取用户启动程序时附加的临时选择。
    # 没有命令行参数时，arguments 中相关字段就是 None。
    arguments = _parse_arguments()

    # 本段决定最终模式。命令行 --mode 优先级更高，但不会修改 config.py。
    # 输入：arguments.mode 和 config.RUN_MODE；输出：selected_mode。
    selected_mode = arguments.mode or config.RUN_MODE

    # 本段是所有模式共同经过的启动前检查。
    # 输入：最终模式和 config.py 中的全部相关参数；输出：继续运行或抛出清晰错误。
    # 实验作用：在接触相机、机器人或分析文件前，先拦住明显错误配置。
    config.validate_config(selected_mode)

    print(f"[主程序] 当前模式：{selected_mode}")

    # 本段是用户模式到代码入口的一对一映射。
    # 输入：selected_mode；输出：调用对应 run_*_mode，并返回该模式输出目录。
    # 实验作用：保证一次运行只做一类事情，不会同时误跑视觉测试和真机实验。
    if selected_mode == "vision_test":
        return run_vision_test_mode()

    if selected_mode == "vision_capture":
        return run_vision_capture_mode()

    if selected_mode == "vision_offline":
        return run_vision_offline_mode()

    if selected_mode == "robot_dry_run":
        return run_robot_dry_run_mode()

    if selected_mode == "robot_connection_test":
        return run_robot_connection_test_mode()

    if selected_mode == "robot_test":
        return run_robot_test_mode()

    if selected_mode == "experiment":
        return run_experiment_mode()

    if selected_mode in RELATIVE_MOTION_MODES:
        return run_relative_motion_experiment_mode(selected_mode, arguments)

    if selected_mode == "batch_experiment":
        return run_batch_experiment_mode(arguments)

    if selected_mode == "micro_motion_experiment":
        return run_micro_motion_experiment_mode(arguments)

    if selected_mode == "batch_vision_offline":
        return run_batch_vision_offline_mode(arguments)

    if selected_mode == "boundary_check":
        return run_boundary_check_mode(arguments)

    if selected_mode == "analyze":
        return run_analysis_mode(arguments.analysis_file)

    # 本段是未来维护用的兜底检查。
    # 如果以后新增模式时只改了 config.py、忘了改 main.py，会在这里得到明确错误。
    raise RuntimeError(f"RUN_MODE={selected_mode!r} 通过了配置检查，但 main.py 没有对应分支。")


if __name__ == "__main__":
    # 本段只在“用户直接运行 main.py”时触发。
    # Windows 子进程会重新导入 main.py；这层保护防止子进程再次启动整套实验。
    mp.freeze_support()
    main()
