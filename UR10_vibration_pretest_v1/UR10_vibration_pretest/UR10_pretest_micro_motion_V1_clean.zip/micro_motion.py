"""
XY 最小微动一键测试（micro_motion_experiment）的纯计算层与两个子进程 worker。

为什么单独建一个模块，而不是改 camera.py / robot.py：
- `camera.batch_camera_worker` 把编解码器写死成 `config.BATCH_VIDEO_CODEC`（目前 MJPG），
  并用字面量 `"_HIK.avi"` 推导侧车文件名。本实验要求“完全取消 MJPG”，
  在共享函数里加分支会同时改动已经稳定的批量实验行为，风险大于收益。
- `robot.batch_robot_worker` 只接受 `build_relative_motion_trajectory` 生成的
  A→B→A 三点往返轨迹，按 speed×time 反推距离；微动需要的是
  “读一次当前位姿 → 沿单轴精确偏移 Δ” 的两点轨迹，位移必须等于指令值。
因此本模块 **只 import 复用** 两边的公开能力，不修改它们：
  - 复用：`HikCameraSource` / `FramePacket` / `_resize_for_preview`、
          `URRobot` / `Waypoint` / `validate_trajectory` 及既有安全闸。
  - 不复用：上面两个 worker 本身。

分层（沿用 batch_plan.py 的风格）：
1. 纯计算层：档位表、步序生成、时长/容量估算、帧号-步号离线 join、
   实际位移判定。不 import 相机 SDK、不 import ur_rtde，可离线单测。
2. `micro_motion_camera_worker`：未压缩 RAW + 逐帧 CSV，无编码器、无手电筒门禁。
3. `micro_motion_robot_worker`：单点 moveL 微动、基于位置的稳定判据、
   每步断言实际位移与方向。

关键测量学说明（写入运行日志，避免结论被过度解读）：
- UR10 CB3 重复定位精度 ±0.1 mm（100 μm）。5–50 μm 的 **指令** 位移低于该指标，
  机械臂可能完全不动或不可重复。这正是本实验要标定的“最小可靠微动”，
  但指令值与实际值在 ~100 μm 以下会显著分离，必须以相机测量为准。
  每步的 `achieved` 断言会把这种现象明确标成 INVALID，而不是伪装成数据。
- 1.0 mm/s + 0.10 m/s² 时加速段本身就覆盖约 5 μm，因此 5/10 μm 档
  全程处于加减速斜坡内、达不到指令速度；5 μm 运动峰值速度约 0.7 mm/s、历时约 14 ms。
- 机器人 125 Hz 采样对 14 ms 运动只能取到约 2 个点，因此
  `robot_tcp_before/after` 只能作为准静态读数，**不得当作动态测量**。
- 相机 132.23 fps、RTDE 125 Hz，Nyquist 约 63–66 Hz。
"""

from __future__ import annotations

import csv
import json
import math
import time
from collections import deque
from datetime import datetime
from pathlib import Path
from queue import Empty
from typing import Any, Callable, Iterator

import numpy as np

import config


# =============================================================================
# 1. 常量与命名
# =============================================================================

# 单轴索引：微动只沿一个轴偏移，因此“投影到指令方向”就是取该轴分量。
AXIS_INDEX: dict[str, int] = {"X": 0, "Y": 1}

# 实际位移断言的状态码。VALID 之外的任何值都表示该步不能当测量结果使用。
STATUS_VALID = "VALID"
STATUS_INVALID_SMALL = "INVALID_SMALL"   # 幅值不足：指令被执行了但没走够，或根本没走
STATUS_INVALID_LARGE = "INVALID_LARGE"   # 幅值过大：超调或目标点被误解
STATUS_INVALID_SIGN = "INVALID_SIGN"     # 方向相反：基座/工具坐标系写反，最危险的一类
STATUS_INVALID_TIMEOUT = "INVALID_TIMEOUT"

# 逐帧交付 CSV 的列顺序。前 8 列是操作者明确要求的字段，顺序保持不变；
# 其后是离线分析必需的补充列，不影响前面的读取。
DELIVERABLE_COLUMNS: tuple[str, ...] = (
    "frame_id",
    "timestamp",
    "step_id",
    "command_um",
    "direction",
    "command_start",
    "command_end",
    "robot_tcp_before",
    "robot_tcp_after",
    # ---- 以下是补充列 ----
    "phase",
    "axis",
    "motion_kind",
    "level_um",
    "segment_base",
    "segment_frame_index",
    "timestamp_ns",
    "camera_timestamp_raw",
    "tcp_axis_before_um",
    "tcp_axis_after_um",
    "achieved_um",
    "status",
)

# 相机自己写的逐帧原始 CSV（`{stem}_frames.csv`）。
FRAME_COLUMNS: tuple[str, ...] = (
    "segment_frame_index",
    "frame_id",
    "host_ns",
    "camera_timestamp_raw",
)

# 全速率机器人状态日志。
ROBOT_LOG_COLUMNS: tuple[str, ...] = (
    "host_ns",
    "robot_timestamp_s",
    "segment_base",
    "step_id",
    "x",
    "y",
    "z",
    "rx",
    "ry",
    "rz",
    "vx",
    "vy",
    "vz",
    "speed_scaling",
    "robot_mode",
    "safety_mode",
)

# 逐步记录（steps.csv）。
STEP_COLUMNS: tuple[str, ...] = (
    "segment_base",
    "axis",
    "motion_kind",
    "level_um",
    "step_index",
    "step_id",
    "direction",
    "command_um",
    "delta_um",
    "command_start_ns",
    "command_end_ns",
    "tcp_before",
    "tcp_after",
    "tcp_axis_before_um",
    "tcp_axis_after_um",
    "achieved_um",
    "expected_um",
    "transverse_um",
    "status",
    "note",
)

# 阶段时间线（master_timeline.csv）。
TIMELINE_COLUMNS: tuple[str, ...] = (
    "phase",
    "segment_base",
    "host_ns",
    "wall_time",
    "wall_elapsed_s",
    "detail",
)


# =============================================================================
# 2. 纯计算层：档位、步序、命名
# =============================================================================

def levels_from_text(text: str | None) -> tuple[int, ...]:
    """
    解析操作者给出的档位列表，例如 "200,100,50"。

    输入：逗号/分号/空格分隔的整数文本，或 None。
    输出：按从大到小去重后的档位元组。

    实验作用：首次实机联调时先只跑 200/100/50 三个较大档位验证全流程，
    再放开全部档位；不需要改 config.py。
    """

    if text is None or not str(text).strip():
        return tuple(config.MICRO_LEVELS_UM)

    raw_parts = str(text).replace(";", ",").replace(" ", ",").split(",")
    levels: list[int] = []
    for part in raw_parts:
        part = part.strip()
        if not part:
            continue
        try:
            value = int(part)
        except ValueError as exc:
            raise ValueError(f"档位 {part!r} 不是整数（单位 μm）。") from exc
        if value < 5:
            raise ValueError(
                f"档位 {value} μm 低于 5 μm 下限。robot.validate_trajectory 的"
                "最小线段是 1 μm，5 μm 已经是 5 倍余量；再低必须改 robot.py。"
            )
        if value not in config.MICRO_LEVELS_UM:
            raise ValueError(
                f"档位 {value} μm 不在允许列表 {list(config.MICRO_LEVELS_UM)} 中。"
            )
        if value not in levels:
            levels.append(value)

    if not levels:
        raise ValueError("档位列表为空。")
    return tuple(sorted(levels, reverse=True))


def level_label(level_um: int) -> str:
    """把档位变成 3 位补零标签：200 -> "200um"，5 -> "005um"。"""

    return f"{int(level_um):03d}um"


def segment_base(axis: str, kind: str, level_um: int) -> str:
    """段/文件名主干，例如 "X_seq_200um"、"Y_alt_005um"。"""

    if axis not in AXIS_INDEX:
        raise ValueError(f"未知轴 {axis!r}，只能是 X 或 Y。")
    if kind not in config.MICRO_MOTION_KINDS:
        raise ValueError(f"未知运动类型 {kind!r}，只能是 {config.MICRO_MOTION_KINDS}。")
    return f"{axis}_{kind}_{level_label(level_um)}"


def build_steps(
    axis: str,
    kind: str,
    level_um: int,
    repeats: int | None = None,
) -> list[dict[str, Any]]:
    """
    生成一个段内部的步序。

    输入：轴、运动类型、档位、每档重复次数。
    输出：逐步字典列表，每项含 step_id / direction / command_um / delta_um。

    seq：连续 N 步 +Δ，再连续 N 步 −Δ（“连续同向”）。
    alt：+Δ、−Δ 交替 2N 步（“频繁换向”）。

    两种形状都是 2N 步且净位移为 0，所以每段结束时机械臂按构造回到段起点，
    不需要额外的回位运动。
    """

    repeats = int(config.MICRO_REPEATS if repeats is None else repeats)
    if repeats < 1:
        raise ValueError("repeats 必须至少为 1。")

    base = segment_base(axis, kind, level_um)
    deltas: list[int] = []
    if kind == "seq":
        deltas = [int(level_um)] * repeats + [-int(level_um)] * repeats
    else:
        for _ in range(repeats):
            deltas.extend((int(level_um), -int(level_um)))

    steps: list[dict[str, Any]] = []
    for index, delta in enumerate(deltas):
        steps.append(
            {
                "segment_base": base,
                "axis": axis,
                "motion_kind": kind,
                "level_um": int(level_um),
                "step_index": index,
                "step_id": f"{base}_S{index + 1:02d}",
                "direction": f"+{axis}" if delta > 0 else f"-{axis}",
                "command_um": int(level_um),
                "delta_um": int(delta),
            }
        )
    return steps


def build_plan(
    levels: tuple[int, ...] | None = None,
    repeats: int | None = None,
    axes: tuple[str, ...] | None = None,
    kinds: tuple[str, ...] | None = None,
) -> list[dict[str, Any]]:
    """
    生成整个实验的段序表。

    输入：档位、重复次数、轴、运动类型（默认取 config）。
    输出：段字典列表，每项含顺序号、段名、轴、类型、档位和 steps。

    实验作用：默认顺序是“X连续 → X换向 → Y连续 → Y换向”，每类里档位从大到小，
    与操作者描述的流程一致；每段的净位移都是 0。
    """

    levels = tuple(config.MICRO_LEVELS_UM if levels is None else levels)
    axes = tuple(config.MICRO_AXES if axes is None else axes)
    kinds = tuple(config.MICRO_MOTION_KINDS if kinds is None else kinds)
    repeats = int(config.MICRO_REPEATS if repeats is None else repeats)

    plan: list[dict[str, Any]] = []
    order = 0
    for axis in axes:
        for kind in kinds:
            for level_um in levels:
                order += 1
                steps = build_steps(axis, kind, int(level_um), repeats)
                plan.append(
                    {
                        "execution_order": order,
                        "segment_base": segment_base(axis, kind, int(level_um)),
                        "axis": axis,
                        "motion_kind": kind,
                        "level_um": int(level_um),
                        "repeat_count": repeats,
                        "step_count": len(steps),
                        "steps": steps,
                    }
                )
    return plan


def step_motion_seconds(distance_m: float, speed_m_s: float, acceleration_m_s2: float) -> float:
    """
    用梯形速度模型估算一段直线运动耗时（秒）。

    输入：位移（m）、速度（m/s）、加速度（m/s²）。
    输出：估算耗时。

    实验作用：5 μm 档会落进“三角形速度曲线”分支——全程在加减速斜坡内，
    达不到指令速度。用它估算录制时长和数据量，不是控制参数。
    """

    distance_m = abs(float(distance_m))
    if distance_m <= 0:
        return 0.0
    t_ramp = float(speed_m_s) / float(acceleration_m_s2)
    d_ramp = 0.5 * float(acceleration_m_s2) * t_ramp * t_ramp
    if distance_m <= 2.0 * d_ramp:
        return 2.0 * math.sqrt(distance_m / float(acceleration_m_s2))
    return 2.0 * t_ramp + (distance_m - 2.0 * d_ramp) / float(speed_m_s)


def estimate_segment(segment: dict[str, Any]) -> dict[str, float]:
    """
    估算一个段的录制时长与帧数。

    每步被录制的时间 = 前静止窗 + (运动与稳定) + 后静止窗。
    运动与稳定 = 运动耗时 + 2×稳定保持 + 固定开销（读位姿、断言、状态写入）。
    """

    motion_s = step_motion_seconds(
        float(segment["level_um"]) / 1e6,
        config.MICRO_SPEED_MM_S / 1000.0,
        config.MICRO_ACCELERATION_M_S2,
    )
    per_step_record = (
        float(config.MICRO_PRE_RECORD_SECONDS)
        + motion_s
        + 2.0 * float(config.MICRO_STABLE_HOLD_SECONDS)
        + 0.2
        + float(config.MICRO_POST_RECORD_SECONDS)
    )
    recorded_s = per_step_record * int(segment["step_count"])
    return {
        "motion_seconds": motion_s,
        "recorded_seconds": recorded_s,
        "wall_seconds": recorded_s
        + 2.0 * float(config.MICRO_STABLE_HOLD_SECONDS)
        + float(config.MICRO_INTER_SEGMENT_SECONDS),
    }


def estimate_run(
    plan: list[dict[str, Any]],
    *,
    camera_fps: float,
    frame_width: int,
    frame_height: int,
    full_width: int,
    full_height: int,
) -> dict[str, Any]:
    """
    估算整套实验的时长、帧数和磁盘占用。

    输入：段序表、相机实际 fps、裁剪后与全幅的宽高。
    输出：含 wall_seconds / frames / bytes / 分项明细的字典。

    实验作用：未压缩 RAW 的数据量是本实验最紧的现实约束，
    所以启动前就把它算清楚并打印出来，而不是跑到一半才发现磁盘不够。
    """

    cropped_bytes_per_frame = int(frame_width) * int(frame_height)
    full_bytes_per_frame = int(full_width) * int(full_height)

    static_frames = int(
        math.ceil(float(config.MICRO_STATIC_BASELINE_SECONDS) * float(camera_fps))
    ) + 8
    probe_frames = int(
        math.ceil(float(config.MICRO_PROBE_SECONDS) * float(camera_fps))
    ) + 8

    segments: list[dict[str, Any]] = []
    segment_frames_total = 0
    segment_seconds_total = 0.0
    for segment in plan:
        estimate = estimate_segment(segment)
        frames = int(math.ceil(estimate["recorded_seconds"] * float(camera_fps))) + 8
        segment_frames_total += frames
        segment_seconds_total += estimate["wall_seconds"]
        segments.append(
            {
                "segment_base": segment["segment_base"],
                "recorded_seconds": estimate["recorded_seconds"],
                "wall_seconds": estimate["wall_seconds"],
                "frames": frames,
                "bytes": frames * cropped_bytes_per_frame,
                "motion_seconds_per_step": estimate["motion_seconds"],
            }
        )

    segment_bytes = segment_frames_total * cropped_bytes_per_frame
    static_bytes = static_frames * full_bytes_per_frame
    probe_bytes = probe_frames * cropped_bytes_per_frame

    return {
        "segments": segments,
        "segment_count": len(plan),
        "step_count": sum(int(segment["step_count"]) for segment in plan),
        "segment_frames": segment_frames_total,
        "segment_seconds": segment_seconds_total,
        "static_frames": static_frames,
        "probe_frames": probe_frames,
        "bytes": segment_bytes + static_bytes + probe_bytes,
        "segment_bytes": segment_bytes,
        "static_bytes": static_bytes,
        "probe_bytes": probe_bytes,
        "wall_seconds": (
            segment_seconds_total
            + float(config.MICRO_STATIC_BASELINE_SECONDS)
            + float(config.MICRO_PROBE_SECONDS)
            + 20.0  # 连接、预热、探测校验、收尾
        ),
    }


def allocate_micro_run(output_root: Path, now: datetime | None = None) -> tuple[str, Path]:
    """
    创建本次运行的输出目录，绝不覆盖已有目录。

    输入：输出根目录和可选时间戳。
    输出：(运行 id, 运行目录)。目录已存在时依次追加 _02、_03。
    """

    output_root = Path(output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    stamp = (now or datetime.now()).strftime("%Y%m%d_%H%M%S")
    run_id = f"micro_motion_test_{stamp}"
    candidate = output_root / run_id
    counter = 2
    while candidate.exists():
        run_id = f"micro_motion_test_{stamp}_{counter:02d}"
        candidate = output_root / run_id
        counter += 1
    candidate.mkdir(parents=True)
    return run_id, candidate


def segment_dir_name(segment_base: str) -> str:
    """段名到子目录名：X_seq_200um -> X_seq。"""

    parts = segment_base.split("_")
    return "_".join(parts[:2])


def segment_paths(run_dir: Path, segment_base: str) -> dict[str, Path]:
    """
    一个段的全部输出路径。

    输入：运行目录和段名。
    输出：raw / frames / meta / csv 四个路径。

    实验作用：主程序负责在段开始前用这些路径建目录并发给相机进程，
    相机进程负责写 raw / frames / meta，主程序在段结束后写 csv（按时间戳 join）。
    """

    directory = Path(run_dir) / segment_dir_name(segment_base)
    return {
        "directory": directory,
        "raw": directory / f"{segment_base}.raw",
        "frames": directory / f"{segment_base}_frames.csv",
        "meta": directory / f"{segment_base}_raw_meta.json",
        "csv": directory / f"{segment_base}.csv",
    }


def static_paths(run_dir: Path) -> dict[str, Path]:
    """静止基线段的输出路径（全分辨率）。"""

    directory = Path(run_dir) / "00_static"
    return {
        "directory": directory,
        "raw": directory / "static.raw",
        "frames": directory / "static_frames.csv",
        "meta": directory / "static_raw_meta.json",
        "csv": directory / "static.csv",
    }


def probe_paths(run_dir: Path) -> dict[str, Path]:
    """磁盘/编码探测段的输出路径。"""

    directory = Path(run_dir) / "disk_probe"
    return {
        "directory": directory,
        "raw": directory / "probe.raw",
        "frames": directory / "probe_frames.csv",
        "meta": directory / "probe_raw_meta.json",
        "csv": directory / "probe_checks.json",
    }


def crop_box_for_frame(width: int, height: int) -> tuple[int, int, int, int] | None:
    """
    计算居中的录制裁剪框，返回 (x, y, w, h)；无法容纳时返回 None（用全幅）。

    输入：相机实际帧宽高。
    输出：裁剪框，或 None 表示不裁剪。

    实验作用：裁剪只缩小视野，像元尺寸和测量分辨率不变；
    裁剪框会被写进 experiment_config.json，而 00_static 以全分辨率录制，
    因此裁剪框可以离线重新推导。
    """

    crop_width = int(config.MICRO_CROP_WIDTH)
    crop_height = int(config.MICRO_CROP_HEIGHT)
    if width < crop_width or height < crop_height:
        return None
    x = (int(width) - crop_width) // 2
    y = (int(height) - crop_height) // 2
    return (x, y, crop_width, crop_height)


# =============================================================================
# 3. 纯计算层：实际位移判定与帧号-步号离线 join
# =============================================================================

def evaluate_achieved(delta_um: float, achieved_um: float) -> tuple[str, str]:
    """
    判断一步微动是否真的按指令执行了。

    输入：指令的有符号位移 delta_um，和实测的有符号位移 achieved_um。
    输出：(状态码, 人类可读说明)。

    为什么必须有这一步：`URRobot.motion_in_progress()` 有固定 200 ms 宽限期，
    而 5 μm 运动全程只有约 14 ms——控制器如果静默忽略了命令，
    现有的“运动开始了/运动结束了”护栏会全部通过，该档位会被当成测到了。
    所以每一步都独立断言幅值和方向，不通过就标 INVALID 并保留 achieved_um 原值。
    """

    magnitude = abs(float(delta_um))
    got = abs(float(achieved_um))
    if magnitude <= 0:
        return STATUS_INVALID_SMALL, "指令位移为 0。"

    low = max(float(config.MICRO_ACHIEVED_SIGN_FLOOR_UM),
              float(config.MICRO_ACHIEVED_MIN_RATIO) * magnitude)
    high = float(config.MICRO_ACHIEVED_MAX_RATIO) * magnitude + float(
        config.MICRO_ACHIEVED_SLACK_UM
    )

    if got < low:
        return (
            STATUS_INVALID_SMALL,
            f"实测位移 {achieved_um:+.2f} μm 低于下限 {low:.2f} μm，本步未被执行或未走够。",
        )
    if got > high:
        return (
            STATUS_INVALID_LARGE,
            f"实测位移 {achieved_um:+.2f} μm 高于上限 {high:.2f} μm，超调或被误解。",
        )
    if got >= float(config.MICRO_ACHIEVED_SIGN_FLOOR_UM) and (
        (float(achieved_um) > 0.0) != (float(delta_um) > 0.0)
    ):
        return (
            STATUS_INVALID_SIGN,
            f"指令 {delta_um:+.2f} μm 但实测 {achieved_um:+.2f} μm，方向相反；"
            "检查基座/工具坐标系或轴符号。",
        )
    return STATUS_VALID, ""


def _format_pose(pose: list[float] | None) -> str:
    """把六位位姿压成一列文本，保证单列可读又能被拆分。"""

    if not pose:
        return ""
    return ";".join(f"{float(value):.9f}" for value in pose)


def join_frames_to_steps(
    frame_rows: list[dict[str, Any]],
    step_rows: list[dict[str, Any]],
    *,
    segment_base: str,
    wall_anchor_ns: int,
    wall_anchor_time: datetime,
    phase_for_unassigned: str = "lead_in",
) -> list[dict[str, Any]]:
    """
    把相机逐帧记录按时间戳标注到步号上，生成交付 CSV 的行。

    输入：相机的逐帧行、本段的逐步行、段名和单调→墙钟锚点。
    输出：每帧一行的交付记录。

    划分规则（唯一且可离线重算）：**按各步的 command_start_ns 切分**，
    每帧属于“最后一个 command_start_ns ≤ 该帧时间”的步；
    早于第一步的帧 step_id 留空（段前引导）。
    这样每个步的区间是 [本步 command_start, 下一步 command_start)，
    连续无空洞，正好对应操作者要的“第 315–380 帧是第 1 次 +50 μm”。
    区间内再用 command_end_ns 进一步区分：
    - 帧时间 ≤ command_end_ns → phase="during"（运动与稳定过程）
    - 帧时间 >  command_end_ns → phase="post"（本步结束后的静止窗，
      同时也是下一步的前静止窗）
    step_id 由主程序离线 join 得到，相机进程不做任何打标——
    相机每帧才排空一次命令队列，边界精度只有 1–2 帧，
    而那恰好是微动前后最关键的帧，打标会比不打标更不可靠。
    """

    ordered = sorted(step_rows, key=lambda row: int(row["command_start_ns"]))
    joined: list[dict[str, Any]] = []
    step_cursor = -1

    for frame in frame_rows:
        timestamp_ns = int(frame["host_ns"])
        while (
            step_cursor + 1 < len(ordered)
            and int(ordered[step_cursor + 1]["command_start_ns"]) <= timestamp_ns
        ):
            step_cursor += 1

        step = ordered[step_cursor] if step_cursor >= 0 else None
        if step is None:
            phase = str(phase_for_unassigned)
            row = {
                "step_id": "",
                "command_um": "",
                "direction": "",
                "command_start": "",
                "command_end": "",
                "robot_tcp_before": "",
                "robot_tcp_after": "",
                "axis": "",
                "motion_kind": "",
                "level_um": "",
                "tcp_axis_before_um": "",
                "tcp_axis_after_um": "",
                "achieved_um": "",
                "status": "",
            }
        else:
            within = timestamp_ns <= int(step["command_end_ns"])
            phase = "during" if within else "post"
            row = {
                "step_id": step["step_id"],
                "command_um": step["command_um"],
                "direction": step["direction"],
                "command_start": _wall_iso(step["command_start_ns"], wall_anchor_ns, wall_anchor_time),
                "command_end": _wall_iso(step["command_end_ns"], wall_anchor_ns, wall_anchor_time),
                "robot_tcp_before": _format_pose(step.get("tcp_before")),
                "robot_tcp_after": _format_pose(step.get("tcp_after")),
                "axis": step["axis"],
                "motion_kind": step["motion_kind"],
                "level_um": step["level_um"],
                "tcp_axis_before_um": f"{float(step['tcp_axis_before_um']):.3f}",
                "tcp_axis_after_um": f"{float(step['tcp_axis_after_um']):.3f}",
                "achieved_um": f"{float(step['achieved_um']):+.3f}",
                "status": step["status"],
            }

        joined.append(
            {
                "frame_id": int(frame["frame_id"]),
                "timestamp": _wall_iso(timestamp_ns, wall_anchor_ns, wall_anchor_time),
                **row,
                "phase": phase,
                "segment_base": segment_base,
                "segment_frame_index": int(frame["segment_frame_index"]),
                "timestamp_ns": timestamp_ns,
                "camera_timestamp_raw": frame.get("camera_timestamp_raw", ""),
            }
        )

    return joined


def _wall_iso(host_ns: int, anchor_ns: int, anchor_time: datetime) -> str:
    """把单调时钟纳秒换算成墙钟 ISO 字符串（只用本进程记录的锚点对）。"""

    offset_s = (int(host_ns) - int(anchor_ns)) / 1_000_000_000.0
    return datetime.fromtimestamp(anchor_time.timestamp() + offset_s).isoformat(
        timespec="milliseconds"
    )


def load_frame_rows(path: Path) -> list[dict[str, Any]]:
    """读取相机写的逐帧 CSV。"""

    rows: list[dict[str, Any]] = []
    with Path(path).open("r", encoding="utf-8-sig", newline="") as file:
        for raw in csv.DictReader(file):
            rows.append(
                {
                    "segment_frame_index": int(raw["segment_frame_index"]),
                    "frame_id": int(raw["frame_id"]),
                    "host_ns": int(raw["host_ns"]),
                    "camera_timestamp_raw": raw.get("camera_timestamp_raw", ""),
                }
            )
    return rows


def write_join_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    """写出交付 CSV（每帧一行）。"""

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8-sig", newline="", buffering=262_144) as file:
        writer = csv.DictWriter(file, fieldnames=DELIVERABLE_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def write_rows_csv(
    path: Path,
    rows: list[dict[str, Any]],
    columns: tuple[str, ...],
    *,
    overwrite: bool = True,
) -> None:
    """写一个通用 CSV；steps.csv / master_timeline.csv 每段之后重写一次以便崩溃后仍有数据。"""

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    mode = "w" if overwrite else "x"
    with path.open(mode, encoding="utf-8-sig", newline="", buffering=65_536) as file:
        writer = csv.DictWriter(file, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def read_rows_csv(path: Path) -> list[dict[str, str]]:
    """读取一个通用 CSV，返回字符串行。"""

    with Path(path).open("r", encoding="utf-8-sig", newline="") as file:
        return [dict(row) for row in csv.DictReader(file)]


# =============================================================================
# 4. 相机进程：未压缩 RAW + 逐帧 CSV（无编码器、无手电筒门禁）
# =============================================================================

def _micro_camera_status(status_queue: Any, event: str, **extra: Any) -> None:
    """向主进程发一条相机状态确认。"""

    status_queue.put(
        {"source": "camera", "event": event, "host_ns": time.perf_counter_ns(), **extra},
        timeout=1.0,
    )


def _update_micro_frame_gap_stats(
    frame_id: int,
    previous_frame_id: int | None,
    received_frames: int,
    missing_frames: int,
) -> tuple[int, int, int, int]:
    """
    微动实验专用的严格缺帧统计。

    输入：当前帧号、上一帧号、已接收帧数、累计缺失帧数。
    输出：(当前帧号, 已接收, 累计缺失, 本次跨越)。

    与批量实验的 `camera._update_batch_frame_gap_stats` 相比，阈值严得多：
    132.23 fps 下单帧间隔为 1，这里允许的最大 frame_id 跨越是
    `MICRO_MAX_FRAME_ID_GAP`（3，即连续丢 2 帧），累计缺帧率上限
    `MICRO_MAX_MISSING_RATIO`（0.5%）。原因是 14 ms 量级的微动
    只有约 2 个相机采样，丢掉相邻帧会直接改变测得的位移。
    """

    current_frame_id = int(frame_id)
    received_frames += 1
    gap = 0
    if previous_frame_id is not None:
        gap = current_frame_id - int(previous_frame_id) - 1
        if gap > 0:
            missing_frames += gap
            if gap > int(config.MICRO_MAX_FRAME_ID_GAP):
                raise RuntimeError(
                    f"微动实验要求帧号连续：本段连续缺失 {gap} 帧"
                    f"（上一帧 {previous_frame_id}，当前帧 {current_frame_id}），"
                    f"超过允许上限 {int(config.MICRO_MAX_FRAME_ID_GAP)} 帧。"
                    "微动的运动全程只有约 14 ms，丢相邻帧会直接改变测得的位移，"
                    "因此这里不降级、不继续，直接中止。"
                )
    return current_frame_id, received_frames, missing_frames, max(gap, 0)


def micro_motion_camera_worker(
    error_queue: Any,
    command_queue: Any,
    status_queue: Any,
    stop_event: Any,
) -> None:
    """
    微动实验的相机子进程：一次连接，按段写未压缩 RAW。

    输入：错误队列、命令队列、状态队列、停止事件。
    输出：每个段一个 `{stem}.raw` + `{stem}_frames.csv` + `{stem}_raw_meta.json`。

    与 `camera.batch_camera_worker` 的关键差异：
    - 写**未压缩 RAW**（直写二进制，没有编码器，因此不可能有 MJPG 类有损伪影）；
    - **没有手电筒门禁**：不调用 `_FlashGate.update`，也不检查 `gate.state`；
    - 裁剪在写盘前完成，并对每帧断言裁剪结果形状不变；
    - 逐帧 CSV 由相机自己写文件，不走 record_queue。
      `multiprocessing.Queue` 的每个元素只交给一个消费者，而 record_queue
      已被 main.segmented_record_writer_worker 独占；status_queue 只有 64 槽，
      132 行/秒会立刻打满并让相机进程崩溃。写文件是唯一安全的做法。

    复刻了 batch worker 的三个必需细节：
    (a) 开关分段后把 previous_frame_id 置 None，避免建/关文件的阻塞被误判成丢帧；
    (b) `start_on_next_frame` 跳过建文件时抓到的那一帧；
    (c) SEGMENT_OPENED / SEGMENT_CLOSED 带 system_start_ns / system_end_ns。
    """

    import cv2

    from camera import HikCameraSource, _resize_for_preview

    active: dict[str, Any] | None = None
    previous_frame_id: int | None = None
    received_frames = 0
    missing_frames = 0
    preview_last_ns = 0
    preview_period_ns = int(1_000_000_000 / float(config.MICRO_PREVIEW_FPS))
    preview_window_name = "UR10 micro-motion camera"

    def close_segment() -> None:
        """封口当前段：关闭文件、核对字节数、写 meta、回报主程序。"""

        nonlocal active, previous_frame_id
        if active is None:
            raise RuntimeError("没有可关闭的相机分段。")

        active["raw"].close()
        active["frames"].close()

        raw_path = active["raw_path"]
        bytes_written = int(raw_path.stat().st_size)
        width = int(active["width"])
        height = int(active["height"])
        expected_bytes = int(active["frame_count"]) * width * height
        if bytes_written != expected_bytes:
            raise RuntimeError(
                f"RAW 文件大小与帧数不一致：{raw_path.name} 实际 {bytes_written} 字节，"
                f"按 {active['frame_count']} 帧 × {width}×{height} 应为 {expected_bytes} 字节。"
                "这通常意味着写盘失败或被截断，本段数据不可用。"
            )

        ratio = float(active["missing_frames"]) / max(
            1, int(active["missing_frames"]) + int(active["frame_count"])
        )
        meta = {
            "kind": "MICRO_SEGMENT_RAW_META",
            "segment_base": active["segment_base"],
            "raw_path": str(raw_path),
            "width": width,
            "height": height,
            "dtype": "uint8",
            "crop_box": active["crop_box"],
            "full_resolution": bool(active["full_resolution"]),
            "frame_count": int(active["frame_count"]),
            "bytes_written": bytes_written,
            "expected_bytes": expected_bytes,
            "missing_frames": int(active["missing_frames"]),
            "missing_ratio": ratio,
            "max_frame_gap": int(active["max_frame_gap"]),
            "first_frame_id": active["first_frame_id"],
            "last_frame_id": active["last_frame_id"],
            "system_start_ns": active["system_start_ns"],
            "system_end_ns": active["system_end_ns"],
            "camera_actual_fps": active["camera_fps"],
            "readme": (
                "离线读取：np.memmap(raw_path, dtype=np.uint8, mode='r', "
                f"shape=(frame_count, {height}, {width}))。"
                "逐帧时间戳见同目录的 _frames.csv。本文件为未压缩位精确数据，"
                "不含任何有损编码。"
            ),
        }
        Path(active["meta_path"]).write_text(
            json.dumps(meta, ensure_ascii=False, indent=2, allow_nan=True), encoding="utf-8"
        )

        if ratio > float(config.MICRO_MAX_MISSING_RATIO):
            raise RuntimeError(
                f"相机累计缺帧率 {ratio:.3%} 超过微动实验上限 "
                f"{float(config.MICRO_MAX_MISSING_RATIO):.3%}"
                f"（已接收 {active['frame_count']} 帧，累计缺失 {active['missing_frames']} 帧）。"
                "微动实验不静默降级，本段数据不可用。"
            )

        _micro_camera_status(
            status_queue,
            "SEGMENT_CLOSED",
            segment_base=active["segment_base"],
            first_frame_id=active["first_frame_id"],
            last_frame_id=active["last_frame_id"],
            system_start_ns=active["system_start_ns"],
            system_end_ns=active["system_end_ns"],
            frame_count=active["frame_count"],
            width=width,
            height=height,
            bytes_written=bytes_written,
            missing_frames=int(active["missing_frames"]),
            missing_ratio=ratio,
            max_frame_gap=int(active["max_frame_gap"]),
            raw_path=str(raw_path),
            meta_path=str(active["meta_path"]),
        )
        active = None
        # 关闭文件可能短暂阻塞；下一帧属于段间空闲期，不把封口耗时误判成丢帧。
        previous_frame_id = None

    try:
        # OpenCV 首次创建窗口可能阻塞上百毫秒，先于取流创建，避免落进帧号连续性检查。
        if config.SHOW_PREVIEW:
            cv2.namedWindow(preview_window_name)

        with HikCameraSource() as source:
            iterator = iter(source)
            fps = float(source.actual_camera_fps or config.EXPECTED_VISION_FPS or 30.0)

            warmup_start_ns: int | None = None
            first = None
            warmup_frames = 0
            print(
                f"[状态] 工业相机正在预热 {config.MICRO_CAMERA_WARMUP_SECONDS:g} 秒，"
                "初始化预览并排空启动帧",
                flush=True,
            )
            while first is None:
                packet = next(iterator)
                if stop_event.is_set():
                    return
                warmup_frames += 1
                if warmup_start_ns is None:
                    warmup_start_ns = int(packet.host_ns)
                if (
                    config.SHOW_PREVIEW
                    and int(packet.host_ns) - preview_last_ns >= preview_period_ns
                ):
                    preview_last_ns = int(packet.host_ns)
                    cv2.imshow(
                        preview_window_name,
                        _resize_for_preview(
                            packet.frame,
                            max_width=int(config.MICRO_PREVIEW_MAX_WIDTH),
                        ),
                    )
                    if cv2.waitKey(1) & 0xFF in (27, ord("q")):
                        raise RuntimeError("相机预览窗口收到 q/Esc。")
                if (
                    int(packet.host_ns) - warmup_start_ns
                    >= int(float(config.MICRO_CAMERA_WARMUP_SECONDS) * 1_000_000_000)
                ):
                    first = packet

            full_height, full_width = int(first.frame.shape[0]), int(first.frame.shape[1])
            _micro_camera_status(
                status_queue,
                "READY",
                actual_camera_fps=fps,
                full_width=full_width,
                full_height=full_height,
                warmup_frames=warmup_frames,
            )
            print(
                f"[状态] 工业相机预热完成（排空 {warmup_frames} 帧），"
                f"实际帧率约 {fps:.3f} fps，全幅 {full_width}×{full_height}",
                flush=True,
            )

            for packet in (item for pair in ((first,), iterator) for item in pair):
                if stop_event.is_set():
                    break
                frame = packet.frame
                previous_frame_id, received_frames, missing_frames, gap = (
                    _update_micro_frame_gap_stats(
                        int(packet.frame_id),
                        previous_frame_id,
                        received_frames,
                        missing_frames,
                    )
                )
                if active is not None:
                    active["max_frame_gap"] = max(int(active["max_frame_gap"]), int(gap))

                while True:
                    try:
                        command = command_queue.get_nowait()
                    except Empty:
                        break
                    action = str(command.get("action", ""))
                    if action == "SHUTDOWN":
                        stop_event.set()
                        break
                    if action == "OPEN_SEGMENT":
                        if active is not None:
                            raise RuntimeError("上一段相机记录尚未关闭。")
                        raw_path = Path(command["raw_path"])
                        frames_path = Path(command["frames_csv_path"])
                        meta_path = Path(command["meta_path"])
                        for path in (raw_path, frames_path, meta_path):
                            if path.exists():
                                raise FileExistsError(f"拒绝覆盖相机输出：{path}")
                            path.parent.mkdir(parents=True, exist_ok=True)

                        crop = command.get("crop")
                        if crop is None:
                            crop_box = None
                            width, height = full_width, full_height
                        else:
                            crop_box = tuple(int(value) for value in crop)
                            x, y, crop_w, crop_h = crop_box
                            if x < 0 or y < 0 or x + crop_w > full_width or y + crop_h > full_height:
                                raise ValueError(
                                    f"裁剪框 {crop_box} 超出实际帧 {full_width}×{full_height}。"
                                )
                            width, height = crop_w, crop_h

                        raw_file = raw_path.open("xb", buffering=0)
                        frames_file = frames_path.open(
                            "x", encoding="utf-8-sig", newline="", buffering=262_144
                        )
                        frames_writer = csv.DictWriter(frames_file, fieldnames=FRAME_COLUMNS)
                        frames_writer.writeheader()
                        active = {
                            "segment_base": str(command["segment_base"]),
                            "raw": raw_file,
                            "raw_path": raw_path,
                            "frames": frames_file,
                            "frames_writer": frames_writer,
                            "frames_path": frames_path,
                            "meta_path": meta_path,
                            "crop_box": crop_box,
                            "full_resolution": crop_box is None,
                            "width": width,
                            "height": height,
                            "camera_fps": fps,
                            "first_frame_id": None,
                            "last_frame_id": None,
                            "system_start_ns": None,
                            "system_end_ns": None,
                            "frame_count": 0,
                            "missing_frames": 0,
                            "max_frame_gap": 0,
                            "start_on_next_frame": True,
                        }
                        # 建文件发生在刚取到当前帧之后，可能占用数个相机周期。
                        # 当前帧不写入新段，从下一帧重建连续性基准。
                        previous_frame_id = None
                        _micro_camera_status(
                            status_queue,
                            "SEGMENT_OPENED",
                            segment_base=active["segment_base"],
                            width=width,
                            height=height,
                            crop_box=crop_box,
                        )
                    elif action == "CLOSE_SEGMENT":
                        close_segment()
                    else:
                        raise ValueError(f"未知相机命令：{action!r}")

                if active is not None:
                    if active.pop("start_on_next_frame", False):
                        # 下一轮才是第一帧正式数据；跳过刚取到的这一帧，
                        # 把建文件的延迟排除在 RAW 之外。
                        pass
                    else:
                        source_frame = frame
                        if source_frame.ndim == 2:
                            gray = source_frame
                        else:
                            gray = cv2.cvtColor(source_frame, cv2.COLOR_BGR2GRAY)
                        if gray.dtype != np.uint8:
                            raise RuntimeError(
                                f"微动实验只支持 uint8 帧，实际 dtype={gray.dtype}。"
                            )
                        crop_box = active["crop_box"]
                        if crop_box is None:
                            cropped = gray
                        else:
                            x, y, crop_w, crop_h = crop_box
                            cropped = gray[y : y + crop_h, x : x + crop_w]
                        if cropped.shape != (int(active["height"]), int(active["width"])):
                            raise RuntimeError(
                                f"裁剪结果形状 {cropped.shape} 与预期 "
                                f"({active['height']}, {active['width']}) 不一致；"
                                "裁剪框在实验中途发生变化，数据不可用。"
                            )
                        # 裁剪得到的是视图，不连续；必须连续化后才能直接写二进制。
                        if not cropped.flags.c_contiguous:
                            cropped = np.ascontiguousarray(cropped)
                        active["raw"].write(memoryview(cropped).cast("B"))
                        active["frames_writer"].writerow(
                            {
                                "segment_frame_index": active["frame_count"],
                                "frame_id": int(packet.frame_id),
                                "host_ns": int(packet.host_ns),
                                "camera_timestamp_raw": packet.camera_timestamp_raw,
                            }
                        )
                        if active["first_frame_id"] is None:
                            active["first_frame_id"] = int(packet.frame_id)
                            active["system_start_ns"] = int(packet.host_ns)
                        active["last_frame_id"] = int(packet.frame_id)
                        active["system_end_ns"] = int(packet.host_ns)
                        active["frame_count"] += 1

                if (
                    config.SHOW_PREVIEW
                    and int(packet.host_ns) - preview_last_ns >= preview_period_ns
                ):
                    preview_last_ns = int(packet.host_ns)
                    cv2.imshow(
                        preview_window_name,
                        _resize_for_preview(
                            frame,
                            max_width=int(config.MICRO_PREVIEW_MAX_WIDTH),
                        ),
                    )
                    if cv2.waitKey(1) & 0xFF in (27, ord("q")):
                        raise RuntimeError("相机预览窗口收到 q/Esc。")
    except StopIteration:
        try:
            error_queue.put("微动相机没有返回任何图像。", timeout=1.0)
        except Exception:
            pass
        stop_event.set()
    except Exception as exc:
        try:
            error_queue.put(f"微动相机进程异常：{type(exc).__name__}: {exc}", timeout=1.0)
        except Exception:
            pass
        stop_event.set()
    finally:
        if active is not None:
            for key in ("raw", "frames"):
                try:
                    active[key].close()
                except Exception:
                    pass
        cv2.destroyAllWindows()


# =============================================================================
# 5. 机器人进程：单点 moveL 微动 + 基于位置的稳定判据
# =============================================================================

def _micro_robot_status(status_queue: Any, event: str, **extra: Any) -> None:
    """向主进程发一条机器人状态确认。"""

    status_queue.put(
        {"source": "robot", "event": event, "host_ns": time.perf_counter_ns(), **extra},
        timeout=1.0,
    )


def _wait_until_position_stable(
    robot: Any,
    stop_event: Any,
    write_state: Callable[[dict[str, Any]], None],
    *,
    timeout_s: float,
    description: str,
) -> dict[str, Any]:
    """
    基于位置的稳定判据，取代 `robot._wait_until_tcp_stopped`。

    输入：机器人、停止事件、状态写盘回调、超时、描述。
    输出：判定稳定后的最后一条状态。

    为什么不能复用既有函数：`ROBOT_EXPERIMENT_STOP_SPEED_MM_S` 是 0.2 mm/s，
    也就是 200 μm/s，比本实验最小步长 5 μm 粗 40 倍，而且只判速度不判位置。
    在 1 s 的“静止”记录窗内，机械臂最多可以爬行 200 μm —— 正好会把爬行
    写进本该是静止基线的数据里。这里改为同时要求：
      1) 最近 `MICRO_STABLE_WINDOW_MS`（100 ms）内所有采样点相对当前点
         偏差都小于 `MICRO_STABLE_WINDOW_UM`（1 μm）；
      2) TCP 线速度低于 `MICRO_STABLE_SPEED_MM_S`（0.01 mm/s）；
      3) 上述条件连续保持 `MICRO_STABLE_HOLD_SECONDS`（0.4 s）。
    1 μm 阈值是 UR10 CB3 重复定位精度（100 μm）的 1/100，
    足以把“还在爬行”和“已经停住”区分开。
    """

    window_ns = int(float(config.MICRO_STABLE_WINDOW_MS) * 1_000_000)
    window_m = float(config.MICRO_STABLE_WINDOW_UM) / 1_000_000.0
    speed_limit_m_s = float(config.MICRO_STABLE_SPEED_MM_S) / 1000.0
    hold_ns = int(float(config.MICRO_STABLE_HOLD_SECONDS) * 1_000_000_000)

    samples: deque[tuple[int, np.ndarray]] = deque()
    stable_since: int | None = None
    deadline = time.perf_counter() + float(timeout_s)
    last_quiet_gap_um = math.inf

    while True:
        if stop_event.is_set():
            raise RuntimeError(f"{description}期间收到停止请求。")
        if time.perf_counter() >= deadline:
            raise TimeoutError(
                f"等待位置稳定超时（{timeout_s:g} s，{description}）；"
                f"最后 100 ms 内最大位置漂移约 {last_quiet_gap_um:.3f} μm。"
            )

        state = robot.read_state()
        write_state(state)
        now_ns = int(state["host_ns"])
        position = np.asarray(state["actual_tcp_pose"][:3], dtype=float)
        samples.append((now_ns, position))
        while samples and samples[0][0] < now_ns - window_ns:
            samples.popleft()

        gap_m = max(
            (float(np.linalg.norm(position - other)) for _, other in samples),
            default=0.0,
        )
        last_quiet_gap_um = gap_m * 1_000_000.0
        speed_m_s = 0.0
        speed_values = state.get("actual_tcp_speed") or []
        if len(speed_values) >= 3:
            speed_m_s = float(np.linalg.norm(np.asarray(speed_values[:3], dtype=float)))
        else:
            speed_m_s = math.inf

        if gap_m <= window_m and speed_m_s <= speed_limit_m_s:
            if stable_since is None:
                stable_since = now_ns
            elif now_ns - stable_since >= hold_ns:
                return state
        else:
            stable_since = None

        time.sleep(0.002)


def micro_motion_robot_worker(
    error_queue: Any,
    command_queue: Any,
    status_queue: Any,
    stop_event: Any,
    run_dir: Path,
) -> None:
    """
    微动实验的机器人子进程：一次连接，按步执行单轴精确微动。

    输入：错误/命令/状态队列、停止事件、运行目录。
    输出：`robot_log.csv`（125 Hz 全速率状态）和每一步的确认消息。

    命令（由 main.py 的状态机发来）：
    - OPEN_SEGMENT / CLOSE_SEGMENT：本段的记录边界，CLOSE 时核对本段净位移；
    - STEP：执行一步微动并断言实际位移与方向；
    - PROBE_MOVE：用 1 mm 的安全移动验证“单点 moveL”这条代码路径；
    - SHUTDOWN：收尾退出。

    为什么不用 `build_relative_motion_trajectory`：它按 speed×time 生成
    A→B→A 三点往返，位移是“速度乘时间”反推出来的，不适合“精确走 Δ”。
    这里直接读一次当前位姿，构造 [当前, 当前+Δ] 两点轨迹，
    位移恰好等于指令值（只读一次位姿很关键：读两次会让实际位移不等于 Δ）。
    """

    from robot import (
        URRobot,
        Waypoint,
        _dashboard_safety_status_is_normal,
        _rtde_safety_mode_is_normal,
        _tcp_speed_norm_m_s,
        validate_trajectory,
    )

    robot = URRobot()
    start_pose: list[float] | None = None
    active_file: Any = None
    active_segment: str | None = None
    active_step_id: str | None = None
    segment_start_pose: list[float] | None = None
    motion_started = False
    motion_finished = True
    joint_speed_limit_m_s = float(config.ROBOT_EXPERIMENT_STOP_SPEED_MM_S) / 1000.0
    period = 1.0 / float(config.ROBOT_RECORD_HZ)

    def write_state(state: dict[str, Any]) -> None:
        """把一条 125 Hz 状态写进 robot_log.csv。"""

        if active_file is None:
            return
        pose = list(state.get("actual_tcp_pose") or [None] * 6)
        speed = list(state.get("actual_tcp_speed") or [None] * 6)
        active_file.write(
            ",".join(
                str(value)
                for value in (
                    int(state["host_ns"]),
                    state.get("robot_timestamp_s"),
                    active_segment or "",
                    active_step_id or "",
                    *pose[:6],
                    *speed[:3],
                    state.get("speed_scaling"),
                    state.get("robot_mode"),
                    state.get("safety_mode"),
                )
            )
            + "\n"
        )

    def read_pose() -> list[float]:
        """读一次当前位姿（单次读取，保证实际位移就等于 Δ）。"""

        return [float(value) for value in robot.current_tcp_pose()]

    def run_step(axis: str, delta_um: float, timeout_s: float) -> dict[str, Any]:
        """
        执行一步单轴微动，返回含实测位移和状态的字典。

        时间结构：等位置稳定 → 读 tcp_before → 记录 command_start_ns →
        发命令 → 等位置稳定 → 读 tcp_after → 记录 command_end_ns → 断言。
        """

        nonlocal motion_started, motion_finished

        axis_index = AXIS_INDEX[axis]
        delta_m = float(delta_um) / 1_000_000.0
        if abs(delta_m) <= 0.0:
            raise ValueError("单步位移不能为 0。")

        _wait_until_position_stable(
            robot,
            stop_event,
            write_state,
            timeout_s=float(config.MICRO_STABLE_TIMEOUT_S),
            description="单步微动前的稳定等待",
        )
        # 只读一次位姿，它同时充当三件事：记录用的 tcp_before、轨迹起点的来源、
        # 以及 achieved 断言的基线。读两次会让“实际位移”不等于指令 Δ——
        # 两次 RTDE 读之间有几十微秒，而本实验的步长只有 5 μm。
        before_state = robot.read_state()
        write_state(before_state)
        tcp_before = [float(value) for value in before_state["actual_tcp_pose"]]

        # 以同一个位姿构造两点轨迹：姿态完全不变，只在目标轴上偏移 Δ。
        current = list(tcp_before)
        target = list(current)
        target[axis_index] = current[axis_index] + delta_m
        trajectory = [
            Waypoint("P0", current, float(config.MICRO_SPEED_MM_S) / 1000.0,
                     float(config.MICRO_ACCELERATION_M_S2), 0.0),
            Waypoint("P1", target, float(config.MICRO_SPEED_MM_S) / 1000.0,
                     float(config.MICRO_ACCELERATION_M_S2), 0.0),
        ]
        validate_trajectory(trajectory, for_real_robot=True, pose_source="relative")
        robot.verify_controller_safety_limits(trajectory)

        command_start_ns = time.perf_counter_ns()
        robot.execute_trajectory(trajectory)
        motion_started = True
        motion_finished = False

        # 等异步运动结束。motion_in_progress() 有 200 ms 宽限期，
        # 对 14 ms 的微动只能保证“命令发出后至少等 200 ms”，
        # 真正判断是否走够由后面的位置判据和 achieved 断言负责。
        deadline = time.perf_counter() + float(timeout_s)
        while robot.motion_in_progress():
            if stop_event.is_set():
                robot.stop_motion()
                motion_finished = True
                raise RuntimeError("微动实验收到停止请求，已调用 stopL。")
            if time.perf_counter() >= deadline:
                robot.stop_motion()
                motion_finished = True
                raise TimeoutError("单步微动超过超时上限，已调用 stopL。")
            write_state(robot.read_state())
            time.sleep(period)

        settled = _wait_until_position_stable(
            robot,
            stop_event,
            write_state,
            timeout_s=float(config.MICRO_STABLE_TIMEOUT_S),
            description="单步微动后的稳定等待",
        )
        motion_finished = True
        command_end_ns = int(settled["host_ns"])
        tcp_after = [float(value) for value in settled["actual_tcp_pose"]]

        achieved_um = (tcp_after[axis_index] - tcp_before[axis_index]) * 1_000_000.0
        status, note = evaluate_achieved(float(delta_um), achieved_um)

        # 横向分量：直接测量操作者在批量实验里已经发现的
        # “+X 走时 Y 偏向一侧、回程偏向另一侧”这一类串轴现象。
        transverse = [
            tcp_after[index] - tcp_before[index]
            for index in range(3)
            if index != axis_index
        ]
        transverse_um = float(np.linalg.norm(np.asarray(transverse, dtype=float))) * 1_000_000.0

        return {
            "command_start_ns": command_start_ns,
            "command_end_ns": command_end_ns,
            "tcp_before": tcp_before,
            "tcp_after": tcp_after,
            "tcp_axis_before_um": tcp_before[axis_index] * 1_000_000.0,
            "tcp_axis_after_um": tcp_after[axis_index] * 1_000_000.0,
            "achieved_um": achieved_um,
            "expected_um": float(delta_um),
            "transverse_um": transverse_um,
            "status": status,
            "note": note,
        }

    def check_global_drift(pose: list[float], where: str) -> float:
        """相对本次实验起点的全局漂移护栏，超限即中止。"""

        if start_pose is None:
            return 0.0
        drift_mm = float(
            np.linalg.norm(np.asarray(pose[:3], dtype=float)
                           - np.asarray(start_pose[:3], dtype=float))
            * 1000.0
        )
        if drift_mm > float(config.MICRO_GLOBAL_DRIFT_ABORT_MM):
            raise RuntimeError(
                f"{where}：机械臂相对实验起点漂移 {drift_mm:.3f} mm，"
                f"超过兜底上限 {float(config.MICRO_GLOBAL_DRIFT_ABORT_MM):.3f} mm，已中止。"
            )
        return drift_mm

    try:
        if not config.ROBOT_RELATIVE_MOTION_ENABLED:
            raise PermissionError(
                "ROBOT_RELATIVE_MOTION_ENABLED=False，XY 最小微动测试被锁定。"
            )
        robot.connect(require_control=True)
        first_state = robot.read_state()
        if _dashboard_safety_status_is_normal(robot.dashboard_info) is False:
            raise RuntimeError("Dashboard 报告机器人安全状态不是 NORMAL。")
        if _rtde_safety_mode_is_normal(first_state) is False:
            raise RuntimeError("RTDE 报告机器人安全状态不是 NORMAL。")
        if _tcp_speed_norm_m_s(first_state) > joint_speed_limit_m_s:
            raise RuntimeError("当前 TCP 尚未静止，拒绝把当前位置定义为实验起点。")
        start_pose = [float(value) for value in first_state["actual_tcp_pose"]]

        # robot_log.csv 整场只开一次，覆盖全部段和段间间隔，
        # 不随段开关，避免“关文件”把状态记录切碎。
        log_path = Path(run_dir) / "robot_log.csv"
        if log_path.exists():
            raise FileExistsError(f"拒绝覆盖机器人日志：{log_path}")
        log_path.parent.mkdir(parents=True, exist_ok=True)
        active_file = log_path.open("x", encoding="utf-8", newline="", buffering=1)
        active_file.write(",".join(ROBOT_LOG_COLUMNS) + "\n")

        _micro_robot_status(
            status_queue, "READY", start_pose=start_pose, dashboard=robot.dashboard_info
        )

        next_sample = time.perf_counter()
        while not stop_event.is_set():
            try:
                command = command_queue.get(timeout=max(0.001, period))
            except Empty:
                command = None

            if command is not None:
                action = str(command.get("action", ""))
                if action == "SHUTDOWN":
                    break
                if action == "OPEN_SEGMENT":
                    if active_segment is not None:
                        raise RuntimeError("上一段机器人记录尚未关闭。")
                    active_segment = str(command["segment_base"])
                    active_step_id = None
                    segment_start_pose = read_pose()
                    check_global_drift(segment_start_pose, "分段开始")
                    _micro_robot_status(
                        status_queue,
                        "SEGMENT_OPENED",
                        segment_base=active_segment,
                        segment_start_pose=segment_start_pose,
                    )
                elif action == "CLOSE_SEGMENT":
                    if active_segment is None:
                        raise RuntimeError("没有可关闭的机器人分段记录。")
                    closing_segment = active_segment
                    end_pose = read_pose()
                    segment_return_mm = float(
                        np.linalg.norm(
                            np.asarray(end_pose[:3], dtype=float)
                            - np.asarray(segment_start_pose[:3], dtype=float)
                        )
                        * 1000.0
                    )
                    global_drift_mm = check_global_drift(end_pose, "分段结束")
                    # seq / alt 的净位移都是 0，所以段结束时机械臂应当已经回到段起点。
                    # 这是“是否真的按构造回到原地”的直接检验，会随步数累积而不是互相抵消。
                    if segment_return_mm > float(config.MICRO_SEGMENT_RETURN_MM):
                        raise RuntimeError(
                            f"{closing_segment} 段结束没有回到段起点，偏差 "
                            f"{segment_return_mm:.3f} mm，超过 "
                            f"{float(config.MICRO_SEGMENT_RETURN_MM):.3f} mm。"
                        )
                    active_segment = None
                    active_step_id = None
                    _micro_robot_status(
                        status_queue,
                        "SEGMENT_CLOSED",
                        segment_base=closing_segment,
                        segment_return_mm=segment_return_mm,
                        global_drift_mm=global_drift_mm,
                    )
                elif action == "STEP":
                    if active_segment is None or active_segment != str(command["segment_base"]):
                        raise RuntimeError("机器人微动命令与当前分段记录不匹配。")
                    active_step_id = str(command["step_id"])
                    result = run_step(
                        str(command["axis"]),
                        float(command["delta_um"]),
                        float(command.get("timeout_s", config.MICRO_STEP_TIMEOUT_S)),
                    )
                    _micro_robot_status(
                        status_queue,
                        "STEP_FINISHED",
                        segment_base=active_segment,
                        step_id=active_step_id,
                        **result,
                    )
                    active_step_id = None
                elif action == "PROBE_MOVE":
                    # 用一次“大而安全”的 1 mm 移动验证单点 moveL 这条路径。
                    # 现有实验模式都发送 ≥2 个路径点，而微动只发 1 点
                    # （execute_trajectory 发送的是 trajectory[1:]），
                    # 这条路径必须先验证过，5 μm 档的结果才可信。
                    axis = str(command.get("axis", "X"))
                    delta_um = float(config.MICRO_PROBE_MOVE_UM) * float(command["sign"])
                    tolerance_um = float(config.MICRO_PROBE_MOVE_TOLERANCE_UM)
                    forward = run_step(axis, delta_um, float(config.MICRO_STEP_TIMEOUT_S) * 2.0)
                    if forward["status"] != STATUS_VALID or abs(
                        forward["achieved_um"] - delta_um
                    ) > tolerance_um:
                        raise RuntimeError(
                            f"探测移动失败：指令 {delta_um:+.1f} μm，实测 "
                            f"{forward['achieved_um']:+.1f} μm，状态 {forward['status']}"
                            f"（{forward['note']}）。单点 moveL 路径不可信，已中止实验。"
                        )
                    backward = run_step(axis, -delta_um, float(config.MICRO_STEP_TIMEOUT_S) * 2.0)
                    if backward["status"] != STATUS_VALID or abs(
                        backward["achieved_um"] + delta_um
                    ) > tolerance_um:
                        raise RuntimeError(
                            f"探测回程失败：指令 {-delta_um:+.1f} μm，实测 "
                            f"{backward['achieved_um']:+.1f} μm，状态 {backward['status']}"
                            f"（{backward['note']}）。已中止实验。"
                        )
                    _micro_robot_status(
                        status_queue,
                        "PROBE_MOVE_DONE",
                        axis=axis,
                        forward_um=forward["achieved_um"],
                        backward_um=backward["achieved_um"],
                        forward_status=forward["status"],
                        backward_status=backward["status"],
                        transverse_um=max(
                            forward["transverse_um"], backward["transverse_um"]
                        ),
                    )
                else:
                    raise ValueError(f"未知机器人命令：{action!r}")

            if active_file is not None and time.perf_counter() >= next_sample:
                write_state(robot.read_state())
                next_sample = time.perf_counter() + period
    except Exception as exc:
        try:
            error_queue.put(f"微动机器人进程异常：{type(exc).__name__}: {exc}", timeout=1.0)
        except Exception:
            pass
        stop_event.set()
    finally:
        if motion_started and not motion_finished:
            robot.stop_motion()
        if active_file is not None:
            active_file.close()
        robot.disconnect()


# =============================================================================
# 6. 时间戳标定（探测阶段使用）
# =============================================================================

def calibrate_camera_clock(frame_rows: list[dict[str, Any]]) -> dict[str, Any]:
    """
    用最小二乘拟合相机硬件时间戳与主机单调时钟的关系。

    输入：逐帧行（含 host_ns 与 camera_timestamp_raw）。
    输出：斜率、截距、残差统计。

    实验作用：`host_ns` 是在 `MV_CC_GetOneFrameTimeout` 返回之后才取的，
    不是曝光时刻；SDK 延迟抖动会直接落在时间轴上，而本实验关心的正是
    14 ms 量级的瞬态。所以离线分析应以硬件时间戳 `camera_timestamp_raw` 为主时基，
    这里的拟合残差就是“主机时间轴相对硬件时间轴有多不准”的量化。
    """

    pairs = [
        (float(row["camera_timestamp_raw"]), float(row["host_ns"]))
        for row in frame_rows
        if row.get("camera_timestamp_raw") not in (None, "", "None")
    ]
    if len(pairs) < 3:
        return {
            "available": False,
            "reason": "有效 (camera_timestamp_raw, host_ns) 对少于 3 个，无法拟合。",
        }

    raw = np.asarray([item[0] for item in pairs], dtype=float)
    host = np.asarray([item[1] for item in pairs], dtype=float)
    if float(np.ptp(raw)) <= 0.0:
        return {"available": False, "reason": "camera_timestamp_raw 无变化，无法拟合。"}

    slope, intercept = np.polyfit(raw, host, 1)
    predicted = slope * raw + intercept
    residual_ns = host - predicted
    return {
        "available": True,
        "pair_count": len(pairs),
        "slope_ns_per_tick": float(slope),
        "intercept_ns": float(intercept),
        "residual_max_ms": float(np.max(np.abs(residual_ns))) / 1e6,
        "residual_rms_ms": float(np.sqrt(np.mean(residual_ns**2))) / 1e6,
        "note": (
            "host_ns 在取帧返回后才记录，不是曝光时刻；离线分析请以 "
            "camera_timestamp_raw 为主时基，再用本拟合换算到主机时间轴。"
        ),
    }


def validate_probe(
    *,
    meta: dict[str, Any],
    closed: dict[str, Any],
    expected_fps: float,
    probe_move: dict[str, Any],
    calibration: dict[str, Any],
) -> dict[str, Any]:
    """
    校验磁盘/编码探测结果。任一项不通过就返回 passed=False，由主程序中止。

    输入：相机的 meta 与 SEGMENT_CLOSED 统计、期望帧率、探测移动结果、时钟标定。
    输出：含逐项检查结果的报告字典。

    实验作用：未压缩 RAW 是本实验唯一敢用的实时录制格式，
    但它的前提是“磁盘真的能持续写入 132 fps”。这个探测就是用与正式段
    完全相同的写入路径和裁剪实测一遍，而不是假设。
    """

    checks: list[dict[str, Any]] = []

    frame_count = int(meta.get("frame_count", 0) or 0)
    start_ns = int(meta.get("system_start_ns") or 0)
    end_ns = int(meta.get("system_end_ns") or 0)
    duration_s = (end_ns - start_ns) / 1e9
    effective_fps = frame_count / duration_s if duration_s > 0 else 0.0

    checks.append(
        {
            "name": "有效帧率",
            "passed": effective_fps >= float(config.MICRO_PROBE_MIN_FPS),
            "detail": (
                f"{effective_fps:.3f} fps（{frame_count} 帧 / {duration_s:.3f} s），"
                f"要求 ≥ {float(config.MICRO_PROBE_MIN_FPS):.3f} fps"
            ),
        }
    )
    checks.append(
        {
            "name": "最大帧号跨越",
            "passed": int(meta.get("max_frame_gap", 0)) <= int(config.MICRO_MAX_FRAME_ID_GAP),
            "detail": (
                f"最大跨越 {int(meta.get('max_frame_gap', 0))} 帧，"
                f"要求 ≤ {int(config.MICRO_MAX_FRAME_ID_GAP)}"
            ),
        }
    )
    checks.append(
        {
            "name": "累计缺帧率",
            "passed": float(meta.get("missing_ratio", 1.0)) < float(config.MICRO_MAX_MISSING_RATIO),
            "detail": (
                f"{float(meta.get('missing_ratio', 1.0)):.4%}，"
                f"要求 < {float(config.MICRO_MAX_MISSING_RATIO):.4%}"
            ),
        }
    )
    checks.append(
        {
            "name": "RAW 字节数",
            "passed": int(meta.get("bytes_written", -1)) == int(meta.get("expected_bytes", -2)),
            "detail": (
                f"实际 {int(meta.get('bytes_written', -1))} 字节，"
                f"应为 {int(meta.get('expected_bytes', -2))} 字节"
            ),
        }
    )
    checks.append(
        {
            "name": "单点 moveL 探测移动",
            "passed": bool(probe_move.get("passed", False)),
            "detail": str(probe_move.get("detail", "探测移动未执行。")),
        }
    )
    checks.append(
        {
            "name": "相机-主机时钟标定",
            "passed": bool(calibration.get("available", False)),
            "detail": (
                f"残差最大 {float(calibration.get('residual_max_ms', 0.0)):.3f} ms，"
                f"RMS {float(calibration.get('residual_rms_ms', 0.0)):.3f} ms"
                if calibration.get("available")
                else str(calibration.get("reason", "标定不可用。"))
            ),
        }
    )
    checks.append(
        {
            "name": "期望帧率一致性",
            "passed": abs(effective_fps - float(expected_fps)) <= max(
                1.0, 0.03 * float(expected_fps)
            ),
            "detail": f"相机报告 {float(expected_fps):.3f} fps，探测实测 {effective_fps:.3f} fps",
        }
    )

    return {
        "passed": all(item["passed"] for item in checks),
        "checks": checks,
        "effective_fps": effective_fps,
        "probe_seconds": duration_s,
        "frame_count": frame_count,
        "expected_fps": float(expected_fps),
        "closed": closed,
    }


def build_probe_move_result(status_message: dict[str, Any] | None) -> dict[str, Any]:
    """把机器人的 PROBE_MOVE_DONE 消息整理成探测报告的检查项。"""

    if not status_message:
        return {"passed": False, "detail": "机器人没有回报探测移动结果。"}
    if str(status_message.get("forward_status")) != STATUS_VALID or str(
        status_message.get("backward_status")
    ) != STATUS_VALID:
        return {
            "passed": False,
            "detail": (
                f"去程状态 {status_message.get('forward_status')}，"
                f"回程状态 {status_message.get('backward_status')}。"
            ),
        }
    return {
        "passed": True,
        "detail": (
            f"{status_message.get('axis', 'X')} 轴：去程实测 "
            f"{float(status_message.get('forward_um', 0.0)):+.1f} μm，回程实测 "
            f"{float(status_message.get('backward_um', 0.0)):+.1f} μm"
            f"（指令 ±{float(config.MICRO_PROBE_MOVE_UM):.1f} μm），"
            f"横向分量最大 {float(status_message.get('transverse_um', 0.0)):.2f} μm。"
        ),
        "forward_um": float(status_message.get("forward_um", 0.0)),
        "backward_um": float(status_message.get("backward_um", 0.0)),
        "transverse_um": float(status_message.get("transverse_um", 0.0)),
    }


def disk_free_bytes(path: Path) -> int:
    """返回给定路径所在卷的可用字节数。"""

    import shutil

    return int(shutil.disk_usage(str(path)).free)


def format_gib(value: int | float) -> str:
    """把字节数格式化成 GiB 字符串。"""

    return f"{float(value) / (1024 ** 3):.2f} GiB"
