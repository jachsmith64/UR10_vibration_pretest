from __future__ import annotations

import tempfile
import unittest
from datetime import datetime
from pathlib import Path

from micro_motion import (
    AXIS_INDEX,
    DELIVERABLE_COLUMNS,
    STATUS_INVALID_LARGE,
    STATUS_INVALID_SIGN,
    STATUS_INVALID_SMALL,
    STATUS_VALID,
    allocate_micro_run,
    build_plan,
    build_steps,
    calibrate_camera_clock,
    crop_box_for_frame,
    estimate_run,
    evaluate_achieved,
    join_frames_to_steps,
    level_label,
    levels_from_text,
    probe_paths,
    segment_base,
    segment_paths,
    static_paths,
    step_motion_seconds,
    validate_probe,
)


class MicroMotionPlanTests(unittest.TestCase):
    def test_default_plan_has_44_segments_in_expected_order(self) -> None:
        plan = build_plan()
        self.assertEqual(len(plan), 44)
        self.assertEqual(
            [item["segment_base"] for item in plan[:4]],
            ["X_seq_200um", "X_seq_150um", "X_seq_100um", "X_seq_080um"],
        )
        self.assertEqual(
            [item["segment_base"] for item in plan[-4:]],
            ["Y_alt_030um", "Y_alt_020um", "Y_alt_010um", "Y_alt_005um"],
        )
        self.assertEqual(sum(item["motion_kind"] == "seq" for item in plan), 22)
        self.assertEqual(sum(item["motion_kind"] == "alt" for item in plan), 22)
        self.assertEqual(sum(item["axis"] == "X" for item in plan), 22)
        self.assertEqual(sum(item["axis"] == "Y" for item in plan), 22)

    def test_every_segment_has_six_steps_and_zero_net_displacement(self) -> None:
        for segment in build_plan():
            deltas = [step["delta_um"] for step in segment["steps"]]
            self.assertEqual(len(deltas), 6)
            self.assertEqual(sum(deltas), 0, segment["segment_base"])
            self.assertEqual(
                [step["step_id"] for step in segment["steps"]][0],
                f"{segment['segment_base']}_S01",
            )

    def test_seq_is_three_same_direction_then_three_reversed(self) -> None:
        steps = build_steps("X", "seq", 50)
        self.assertEqual(
            [step["delta_um"] for step in steps], [50, 50, 50, -50, -50, -50]
        )
        self.assertEqual(
            [step["direction"] for step in steps],
            ["+X", "+X", "+X", "-X", "-X", "-X"],
        )

    def test_alt_alternates_direction_every_step(self) -> None:
        steps = build_steps("Y", "alt", 20)
        self.assertEqual(
            [step["delta_um"] for step in steps], [20, -20, 20, -20, 20, -20]
        )
        self.assertEqual(
            [step["direction"] for step in steps],
            ["+Y", "-Y", "+Y", "-Y", "+Y", "-Y"],
        )

    def test_repeats_change_step_count(self) -> None:
        self.assertEqual(len(build_steps("X", "seq", 200, repeats=1)), 2)
        self.assertEqual(len(build_steps("X", "alt", 200, repeats=5)), 10)

    def test_level_label_pads_to_three_digits(self) -> None:
        self.assertEqual(level_label(200), "200um")
        self.assertEqual(level_label(5), "005um")
        self.assertEqual(level_label(50), "050um")

    def test_segment_base_rejects_unknown_axis_or_kind(self) -> None:
        self.assertEqual(segment_base("X", "seq", 5), "X_seq_005um")
        with self.assertRaises(ValueError):
            segment_base("Z", "seq", 5)
        with self.assertRaises(ValueError):
            segment_base("X", "ramp", 5)


class MicroMotionLevelParsingTests(unittest.TestCase):
    def test_empty_text_uses_all_configured_levels(self) -> None:
        self.assertEqual(levels_from_text(None), (200, 150, 100, 80, 60, 50, 40, 30, 20, 10, 5))
        self.assertEqual(levels_from_text("  "), (200, 150, 100, 80, 60, 50, 40, 30, 20, 10, 5))

    def test_explicit_subset_is_sorted_descending_and_deduplicated(self) -> None:
        self.assertEqual(levels_from_text("50,200,100,50"), (200, 100, 50))
        self.assertEqual(levels_from_text("200;100 50"), (200, 100, 50))

    def test_level_below_five_microns_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            levels_from_text("1")
        with self.assertRaises(ValueError):
            levels_from_text("4")

    def test_level_outside_configured_ladder_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            levels_from_text("123")

    def test_non_integer_level_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            levels_from_text("abc")


class MicroMotionAchievedTests(unittest.TestCase):
    def test_exact_command_is_valid(self) -> None:
        self.assertEqual(evaluate_achieved(50.0, 50.0)[0], STATUS_VALID)
        self.assertEqual(evaluate_achieved(-50.0, -50.0)[0], STATUS_VALID)

    def test_slight_undershoot_and_overshoot_are_valid(self) -> None:
        self.assertEqual(evaluate_achieved(200.0, 120.0)[0], STATUS_VALID)
        self.assertEqual(evaluate_achieved(200.0, 280.0)[0], STATUS_VALID)

    def test_ignored_command_is_invalid_small(self) -> None:
        self.assertEqual(evaluate_achieved(200.0, 0.4)[0], STATUS_INVALID_SMALL)
        self.assertEqual(evaluate_achieved(5.0, 0.0)[0], STATUS_INVALID_SMALL)

    def test_wildly_large_result_is_invalid_large(self) -> None:
        self.assertEqual(evaluate_achieved(20.0, 400.0)[0], STATUS_INVALID_LARGE)

    def test_reversed_direction_is_invalid_sign(self) -> None:
        self.assertEqual(evaluate_achieved(200.0, -200.0)[0], STATUS_INVALID_SIGN)
        self.assertEqual(evaluate_achieved(-200.0, 200.0)[0], STATUS_INVALID_SIGN)

    def test_sign_is_not_judged_below_the_noise_floor(self) -> None:
        # 幅值足够通过幅值判据、但小于符号可信下限时，不能因为方向就报警。
        status, _ = evaluate_achieved(5.0, -1.5)
        self.assertEqual(status, STATUS_INVALID_SMALL)

    def test_zero_command_is_rejected(self) -> None:
        self.assertEqual(evaluate_achieved(0.0, 0.0)[0], STATUS_INVALID_SMALL)


class MicroMotionJoinTests(unittest.TestCase):
    def _steps(self) -> list[dict]:
        return [
            {
                "step_id": "X_alt_050um_S01",
                "command_um": 50,
                "direction": "+X",
                "command_start_ns": 1_000,
                "command_end_ns": 1_100,
                "axis": "X",
                "motion_kind": "alt",
                "level_um": 50,
                "tcp_before": [0.1, 0.2, 0.3, 0.0, 0.0, 0.0],
                "tcp_after": [0.10005, 0.2, 0.3, 0.0, 0.0, 0.0],
                "tcp_axis_before_um": 100000.0,
                "tcp_axis_after_um": 100050.0,
                "achieved_um": 50.0,
                "status": STATUS_VALID,
            },
            {
                "step_id": "X_alt_050um_S02",
                "command_um": 50,
                "direction": "-X",
                "command_start_ns": 2_000,
                "command_end_ns": 2_100,
                "axis": "X",
                "motion_kind": "alt",
                "level_um": 50,
                "tcp_before": [0.10005, 0.2, 0.3, 0.0, 0.0, 0.0],
                "tcp_after": [0.1, 0.2, 0.3, 0.0, 0.0, 0.0],
                "tcp_axis_before_um": 100050.0,
                "tcp_axis_after_um": 100000.0,
                "achieved_um": -50.0,
                "status": STATUS_VALID,
            },
        ]

    def _frames(self, host_ns_values: list[int]) -> list[dict]:
        return [
            {
                "segment_frame_index": index,
                "frame_id": index,
                "host_ns": value,
                "camera_timestamp_raw": value * 10,
            }
            for index, value in enumerate(host_ns_values)
        ]

    def test_frames_are_partitioned_at_command_start(self) -> None:
        rows = join_frames_to_steps(
            self._frames([500, 900, 1_000, 1_050, 1_150, 1_500, 2_050, 2_200]),
            self._steps(),
            segment_base="X_alt_050um",
            wall_anchor_ns=0,
            wall_anchor_time=datetime(2026, 9, 17, 10, 0, 0),
        )
        self.assertEqual(
            [row["step_id"] for row in rows],
            [
                "",
                "",
                "X_alt_050um_S01",
                "X_alt_050um_S01",
                "X_alt_050um_S01",
                "X_alt_050um_S01",
                "X_alt_050um_S02",
                "X_alt_050um_S02",
            ],
        )
        self.assertEqual(
            [row["phase"] for row in rows],
            [
                "lead_in",
                "lead_in",
                "during",
                "during",
                "post",
                "post",
                "during",
                "post",
            ],
        )

    def test_blocks_are_contiguous_and_cover_every_frame(self) -> None:
        rows = join_frames_to_steps(
            self._frames(list(range(600, 2_600, 100))),
            self._steps(),
            segment_base="X_alt_050um",
            wall_anchor_ns=0,
            wall_anchor_time=datetime(2026, 9, 17, 10, 0, 0),
        )
        assigned = [row["step_id"] for row in rows]
        first = assigned.index("X_alt_050um_S01")
        self.assertTrue(all(item == "X_alt_050um_S01" for item in assigned[first : first + 10]))
        self.assertTrue(all(item == "X_alt_050um_S02" for item in assigned[first + 10 :]))

    def test_deliverable_columns_keep_the_requested_eight_first(self) -> None:
        self.assertEqual(
            DELIVERABLE_COLUMNS[:8],
            (
                "frame_id",
                "timestamp",
                "step_id",
                "command_um",
                "direction",
                "command_start",
                "command_end",
                "robot_tcp_before",
            ),
        )
        self.assertEqual(DELIVERABLE_COLUMNS[8], "robot_tcp_after")

    def test_unassigned_phase_can_be_overridden(self) -> None:
        rows = join_frames_to_steps(
            self._frames([10, 20]),
            [],
            segment_base="static",
            wall_anchor_ns=0,
            wall_anchor_time=datetime(2026, 9, 17, 10, 0, 0),
            phase_for_unassigned="static",
        )
        self.assertEqual([row["phase"] for row in rows], ["static", "static"])
        self.assertEqual([row["step_id"] for row in rows], ["", ""])


class MicroMotionEstimateTests(unittest.TestCase):
    def test_five_micron_step_is_acceleration_limited(self) -> None:
        # 1.0 mm/s + 0.10 m/s² 时加速段本身就覆盖约 5 μm：
        # 5 μm 全程处于加减速斜坡内，历时约 14 ms，达不到指令速度。
        seconds = step_motion_seconds(5e-6, 0.001, 0.10)
        self.assertAlmostEqual(seconds, 0.01414, places=4)

    def test_large_step_reaches_commanded_speed(self) -> None:
        # 200 μm 超过两倍加速段（10 μm），进入匀速段。
        seconds = step_motion_seconds(200e-6, 0.001, 0.10)
        self.assertAlmostEqual(seconds, 0.21, places=3)

    def test_zero_distance_takes_no_time(self) -> None:
        self.assertEqual(step_motion_seconds(0.0, 0.001, 0.10), 0.0)

    def test_run_estimate_covers_all_segments_and_static(self) -> None:
        plan = build_plan()
        estimate = estimate_run(
            plan,
            camera_fps=132.23,
            frame_width=640,
            frame_height=480,
            full_width=1936,
            full_height=1464,
        )
        self.assertEqual(estimate["segment_count"], 44)
        self.assertEqual(estimate["step_count"], 264)
        self.assertEqual(len(estimate["segments"]), 44)
        self.assertGreater(estimate["wall_seconds"], 0)
        # 静止基线以全分辨率录制，因此它的单帧字节数高于裁剪段。
        self.assertGreater(estimate["static_bytes"], estimate["segment_bytes"] / 44)
        self.assertEqual(
            estimate["bytes"],
            estimate["segment_bytes"] + estimate["static_bytes"] + estimate["probe_bytes"],
        )

    def test_fewer_levels_shrink_the_estimate(self) -> None:
        full = estimate_run(
            build_plan(),
            camera_fps=132.23, frame_width=640, frame_height=480,
            full_width=1936, full_height=1464,
        )
        small = estimate_run(
            build_plan(levels=(200, 100, 50)),
            camera_fps=132.23, frame_width=640, frame_height=480,
            full_width=1936, full_height=1464,
        )
        self.assertLess(small["bytes"], full["bytes"])
        self.assertEqual(small["segment_count"], 12)


class MicroMotionLayoutTests(unittest.TestCase):
    def test_crop_box_is_centered_and_matches_configured_size(self) -> None:
        self.assertEqual(crop_box_for_frame(1936, 1464), (648, 492, 640, 480))

    def test_crop_box_falls_back_to_none_when_frame_is_too_small(self) -> None:
        self.assertIsNone(crop_box_for_frame(320, 240))

    def test_segment_paths_live_in_a_shared_direction_folder(self) -> None:
        root = Path("run")
        self.assertEqual(
            segment_paths(root, "X_seq_200um")["raw"],
            root / "X_seq" / "X_seq_200um.raw",
        )
        self.assertEqual(
            segment_paths(root, "Y_alt_005um")["csv"],
            root / "Y_alt" / "Y_alt_005um.csv",
        )
        self.assertEqual(static_paths(root)["raw"], root / "00_static" / "static.raw")
        self.assertEqual(probe_paths(root)["raw"], root / "disk_probe" / "probe.raw")

    def test_run_directory_is_never_overwritten(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            first, first_dir = allocate_micro_run(root, datetime(2026, 9, 17, 10, 15, 30))
            second, second_dir = allocate_micro_run(root, datetime(2026, 9, 17, 10, 15, 30))
            self.assertEqual(first, "micro_motion_test_20260917_101530")
            self.assertEqual(second, "micro_motion_test_20260917_101530_02")
            self.assertNotEqual(first_dir, second_dir)
            self.assertTrue(first_dir.is_dir())
            self.assertTrue(second_dir.is_dir())

    def test_axis_index_covers_both_axes(self) -> None:
        self.assertEqual(AXIS_INDEX, {"X": 0, "Y": 1})


class MicroMotionProbeTests(unittest.TestCase):
    def _meta(self, **overrides) -> dict:
        meta = {
            "frame_count": 1322,
            "width": 640,
            "height": 480,
            "bytes_written": 1322 * 640 * 480,
            "expected_bytes": 1322 * 640 * 480,
            "system_start_ns": 1_000_000_000,
            "system_end_ns": 11_000_000_000,
            "missing_frames": 2,
            "missing_ratio": 0.0015,
            "max_frame_gap": 1,
        }
        meta.update(overrides)
        return meta

    def _move(self, passed: bool = True) -> dict:
        return {"passed": passed, "detail": "ok"}

    def _calibration(self, available: bool = True) -> dict:
        return {"available": available, "residual_max_ms": 0.4, "residual_rms_ms": 0.1}

    def test_healthy_probe_passes_every_check(self) -> None:
        report = validate_probe(
            meta=self._meta(),
            closed={},
            expected_fps=132.23,
            probe_move=self._move(),
            calibration=self._calibration(),
        )
        self.assertTrue(report["passed"], report["checks"])
        self.assertAlmostEqual(report["effective_fps"], 132.2, places=1)

    def test_dropped_frames_fail_the_probe(self) -> None:
        report = validate_probe(
            meta=self._meta(
                frame_count=1200,
                bytes_written=1200 * 640 * 480,
                expected_bytes=1200 * 640 * 480,
                missing_ratio=0.05,
                max_frame_gap=9,
            ),
            closed={},
            expected_fps=132.23,
            probe_move=self._move(),
            calibration=self._calibration(),
        )
        self.assertFalse(report["passed"])
        failed = {item["name"] for item in report["checks"] if not item["passed"]}
        self.assertIn("最大帧号跨越", failed)
        self.assertIn("累计缺帧率", failed)
        self.assertIn("有效帧率", failed)

    def test_truncated_raw_fails_the_probe(self) -> None:
        report = validate_probe(
            meta=self._meta(bytes_written=1322 * 640 * 480 - 4096),
            closed={},
            expected_fps=132.23,
            probe_move=self._move(),
            calibration=self._calibration(),
        )
        self.assertFalse(report["passed"])
        failed = {item["name"] for item in report["checks"] if not item["passed"]}
        self.assertIn("RAW 字节数", failed)

    def test_missing_probe_move_fails_the_probe(self) -> None:
        report = validate_probe(
            meta=self._meta(),
            closed={},
            expected_fps=132.23,
            probe_move=self._move(passed=False),
            calibration=self._calibration(),
        )
        self.assertFalse(report["passed"])

    def test_unavailable_calibration_fails_the_probe(self) -> None:
        report = validate_probe(
            meta=self._meta(),
            closed={},
            expected_fps=132.23,
            probe_move=self._move(),
            calibration=self._calibration(available=False),
        )
        self.assertFalse(report["passed"])

    def test_clock_calibration_fits_a_linear_relation(self) -> None:
        frames = [
            {
                "camera_timestamp_raw": 1000 + index * 7_562_000,
                "host_ns": 5_000_000_000 + index * 7_562_100,
            }
            for index in range(50)
        ]
        calibration = calibrate_camera_clock(frames)
        self.assertTrue(calibration["available"])
        self.assertEqual(calibration["pair_count"], 50)
        self.assertLess(calibration["residual_max_ms"], 0.01)

    def test_clock_calibration_reports_when_it_cannot_fit(self) -> None:
        self.assertFalse(calibrate_camera_clock([])["available"])
        self.assertFalse(
            calibrate_camera_clock(
                [
                    {"camera_timestamp_raw": "", "host_ns": 1},
                    {"camera_timestamp_raw": "", "host_ns": 2},
                    {"camera_timestamp_raw": "", "host_ns": 3},
                ]
            )["available"]
        )


if __name__ == "__main__":
    unittest.main()
