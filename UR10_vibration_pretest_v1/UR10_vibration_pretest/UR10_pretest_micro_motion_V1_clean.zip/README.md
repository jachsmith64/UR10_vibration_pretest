# UR10 预实验工程 — 本轮版本说明（XY 最小微动一键测试）

本包是 `UR10_vibration_pretest` 的源码交付包，供其他模型人工复核本轮新增的
**XY 最小微动一键测试（`micro_motion_experiment`）**。根目录扁平，全部源码在根下，
单测在 `tests/`。

---

## 1. 本轮完成了什么

新增一个**完全独立**的实验模式，一次点击自动跑完：

```
设备检查 → 相机预热 → 时钟标定 → 编码/磁盘探测 → 静止基线 00_static
→ X连续同向 → X频繁换向 → Y连续同向 → Y频繁换向
→ 自动回到初始位置 → 封口
```

- 档位 11 个：`200, 150, 100, 80, 60, 50, 40, 30, 20, 10, 5` μm（`MICRO_LEVELS_UM`）。
- 每档两种运动类型，各重复 3 次，共 **44 段、264 步**：
  - `seq`（连续同向）：`+Δ,+Δ,+Δ,−Δ,−Δ,−Δ`
  - `alt`（频繁换向）：`+Δ,−Δ,+Δ,−Δ,+Δ,−Δ`
  - 两者**净位移都为 0**，按构造自动回到段起点。
- **不修改 `robot.py` / `camera.py`**，也不改变任何原有实验模式的行为。

### 交付物

```
outputs/micro_motion_test_<YYYYmmdd_HHMMSS>/
├─ disk_probe/          探测段 + probe_checks.json（7 项校验）
├─ 00_static/           static.raw（**全分辨率** 1936×1464，供离线重推裁剪框）
├─ X_seq/  X_alt/  Y_seq/  Y_alt/
│    └─ <stem>.raw        未压缩 RAW（位精确）
│       <stem>_frames.csv 逐帧 frame_id / host_ns / 相机硬件时间戳
│       <stem>.csv        逐帧 + 步标签（交付列，见下）
├─ steps.csv            全部 264 步的统一记录（含 achieved_um / status）
├─ master_timeline.csv  何时进入哪个阶段
├─ robot_log.csv        全速率机器人状态（125 Hz，覆盖段间间隔）
├─ summary_by_level.csv 逐档汇总
└─ experiment_config.json 全部生效参数 + 探测结果 + 时钟标定残差
```

`<stem>.csv` 交付列（每帧一行，离线分析无需人工看视频）：

```
frame_id, timestamp, step_id, command_um, direction,
command_start, command_end, robot_tcp_before, robot_tcp_after
```

由此可离线直接回答：X 连续同向最小可靠微动 / X 频繁换向最小可靠微动 /
Y 连续同向 / Y 频繁换向，并重算无损视频下的静止抖动。

`.raw` 是主产物（用 `numpy.memmap` 直接读，比解码 AVI 更快更准）。
需要人工观看时用 `micro_motion_export.py` 离线转成无损 `.mkv`（FFV1）。

---

## 2. 为什么是未压缩 RAW，而不是 MJPG / FFV1

| 方案 | 实测能力（需 132.23 fps） | 结论 |
|---|---|---|
| MJPG 全幅（旧方案） | 49 fps | 已否决 |
| FFV1 全幅 | 17 fps | 丢 87% 帧 |
| FFV1 640×480 | **79–181 fps，随画面内容浮动** | 无法事先保证，跟不上就静默丢帧 |
| **未压缩 RAW 640×480** | 与内容无关，位精确 | **采用** |

FFV1 的吞吐**依赖画面内容**（真实传感器噪声帧 79 fps，重复内容帧 181 fps），
实时录制无法事先保证；未压缩 RAW 无编码器可掉队。

本机实测（含真实的「全幅取 ROI → 连续化拷贝 → 落盘」循环开销，磁盘已用 5.6 GB）：

```
帧预算 @132.23 fps : 7.563 ms
中位每帧           : 0.108 ms
p99                : 0.375 ms
最差每帧           : 0.534 ms      → 余量 70×
```

因为实时性靠的是 RAW，转码才放到实验结束后离线做（`micro_motion_export.py`，
默认 FFV1 无损，并做**往返像素比对**把最大像素差报出来，不只靠声称）。

---

## 3. 当前控制链与主要入口

```
launcher_ui.py  （tkinter 启动器）
   └─ 「D. XY 最小微动一键测试」按钮 → start_micro_motion()
        └─ subprocess → main.py --mode micro_motion_experiment --ui-confirmed
             └─ run_micro_motion_experiment_mode()          main.py
                  ├─ micro_motion_robot_worker()            micro_motion.py
                  │    （URRobot 公开 API + 直接构造 Waypoint）
                  └─ micro_motion_camera_worker()           micro_motion.py
                       （HikCameraSource + 未压缩 RAW 直写）
```

- 两个 worker 都是 `multiprocessing`（**spawn**）子进程，`mp.Queue` IPC。
- 子进程启动顺序沿用既有约定：**先机器人后相机**（避免 RTDE 握手与相机初始化争抢）。
- 相机 worker **自带**逐帧 CSV 落盘。这是必须的：`mp.Queue` 每个元素只交给一个
  消费者，`record_queue` 已被 `segmented_record_writer_worker` 独占，
  而 `status_queue` 只有 `maxsize=64`，132 行/秒会立刻打满并让相机进程崩溃。

### 主要入口

| 文件 | 作用 |
|---|---|
| `main.py` | `run_micro_motion_experiment_mode()` 是本轮主流程 |
| `micro_motion.py` | 新增。纯计算层 + 相机 worker + 机器人 worker |
| `micro_motion_export.py` | 新增。RAW → 无损 mkv 离线导出 |
| `config.py` | `MICRO_*` 常量段 + `validate_config` 校验 |
| `launcher_ui.py` | 启动器按钮与说明 |

`micro_motion.py` 分三层，**纯计算层不 import 相机 SDK / `ur_rtde`**，可离线单测
（沿用 `batch_plan.py` 的分层风格）。

---

## 4. 如何运行

```bat
:: 首次先装环境
setup_windows.ps1

:: 正常使用：启动器
run_launcher_ui.cmd
::  → 点「检测机械臂通信」→ 通过后按钮解锁 → 点「XY最小微动一键测试」

:: 命令行（需先设好 config，并在现场确认安全）
.venv\Scripts\python.exe main.py --mode micro_motion_experiment --ui-confirmed

:: 首次实机建议只放开 3 个较大档位，跑通全流程
.venv\Scripts\python.exe main.py --mode micro_motion_experiment --ui-confirmed ^
    --micro-levels 200,100,50

:: 实验结束后导出无损视频人工看一遍
.venv\Scripts\python.exe micro_motion_export.py ^
    --run-dir outputs\micro_motion_test_20260917_101530

:: 单测（当前 65 个，全绿）
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

**本模式不需要手电筒门禁。** 跨进程时钟已实测确认：
`time.get_clock_info('perf_counter')` → `QueryPerformanceCounter()`，全机共享，
所以相机帧与机械臂步可以用 `perf_counter_ns` 直接对齐。新 worker 中
**从不调用 `gate.update`、从不检查 `gate.state`**。

---

## 5. 安全检查（触及硬件前会拒绝的情形）

新 mode 在**四处**登记（漏登记会让真机模式跳过安全检查）：

1. `config.VALID_RUN_MODES`
2. `validate_config` 的 `robot_modes`
3. `validate_config` 的 `relative_motion_modes`
4. `launcher_ui.MOTION_MODES`

**刻意不加进 `main.RELATIVE_MOTION_MODES`** —— 那会走错分发路径。

实测拒绝行为：

| 情形 | 结果 |
|---|---|
| `CONTROL_MODE == "sfc"` | 拒绝（避免 SFC 与离线控制当场冲突） |
| `ROBOT_HOST` 为空 | 拒绝 |
| `ROBOT_RELATIVE_MOTION_ENABLED == False` | `PermissionError`，**在任何硬件操作与建目录之前** |
| 档位序列为空 / 非降序 / 含 <5 μm | 拒绝 |
| 微动速度超出 `ROBOT_EXPERIMENT_MIN/MAX_SPEED_MM_S` | 拒绝 |
| 磁盘可用 < 预计数据量 × 1.15 | 拒绝（且在建目录之前） |

另外三处运行期护栏：单步 `achieved` 位移断言、每段回归误差 ≤ `MICRO_SEGMENT_RETURN_MM`、
全局漂移 > `MICRO_GLOBAL_DRIFT_ABORT_MM` 即中止。

---

## 6. 相比上版改了什么

| 文件 | 改动 |
|---|---|
| `micro_motion.py` | **新增**（1791 行） |
| `micro_motion_export.py` | **新增**（255 行） |
| `config.py` | 新增 `MICRO_*` 常量段与校验；mode 登记进 2 处集合 |
| `main.py` | 新增 `run_micro_motion_experiment_mode()`、`--micro-levels`、分发分支 |
| `launcher_ui.py` | 新增 D 区按钮与说明；`MOTION_MODES` 登记 |
| `tests/test_micro_motion_plan.py` | **新增**（40 个单测） |
| `robot.py` / `camera.py` | **未改动**（用户硬约束） |

原有 25 个单测保持全绿，现共 **65 个**。

---

## 7. 已知问题与科学性提醒

1. **UR10 CB3 重复定位精度 ±0.1 mm（100 μm）。** 5–50 μm 的**指令**位移低于该指标，
   机械臂可能完全不动或不可重复 —— 这正是本实验要标定的「最小可靠微动」，
   但**指令值与实际值在 ~100 μm 以下会显著分离，必须以相机测量为准**。
   单步 `achieved` 断言会把这种现象标成 `INVALID_*` 而不是伪装成数据。
2. **1.0 mm/s + 0.10 m/s² 时加速段本身就覆盖约 5 μm**，故 5/10 μm 档全程处于
   加减速斜坡内、达不到指令速度（5 μm 历时仅 ~14 ms，峰值速度 0.7 mm/s）。
3. **机器人 125 Hz 采样对 14 ms 运动只能取到约 2 个点**，因此
   `tcp_before/tcp_after` 只能作为准静态读数，**不得当作动态测量**。
4. **测量带宽**：CB3 RTDE 125 Hz、相机 132.23 fps，Nyquist ≈ 63–66 Hz。
   超过 60 Hz（`MICRO_ANALYSIS_BANDWIDTH_HZ`）的成分不能声称被这套硬件测到；
   代码启动时会断言关注频带低于该值。
5. **数据量比原估算大。** 因每步要求 1.0 s 前窗 + 1.0 s 后窗（用户明确要求
   「每个小动作中间预留 1 s 而不是零点几秒」），实测为 **16.2 分钟 / 32.99 GiB**
   （原估算 13.5 分钟 / 23.2 GiB）。**未压缩 RAW 是本实验最紧的现实约束**，
   代码会在建目录前拒绝空间不足的运行，不会中途写满。
6. **尚未进行实机验证。** 本轮只完成纯计算单测、静态检查与无硬件干跑。
   建议先用 `--micro-levels 200,100,50` 跑通全流程再放开全部 11 档。

---

## 8. 未打包内容说明

以下**未**放入本包，不影响代码审查：

| 名称 | 原位置 | 为何需要 / 缺失影响 |
|---|---|---|
| `.venv/` | 工程根 | Python 虚拟环境，`requirements-lock-win-py312.txt` 已完整锁定版本 |
| `outputs/`（5.6 GB） | 工程根 | 历史运行产物，非源码 |
| `input_images/`、`input_video/` | 工程根 | 空目录 |
| `*.rar`（3 个） | 工程根 | 历史交付归档 |
| `transfer_8_27_stable/` | 工程根 | 旧稳定版副本，内容已并入根目录 `.md` |
| `.npm-cache/`、`.vscode/`、`__pycache__/` | 工程根 | 工具缓存 |

**相机内参标定文件未包含**：本工程的内参走 `calibration.py` /
`calibrate_camera_intrinsics.py` 现场生成，运行前需按 `ENVIRONMENT_SETUP.md`
在本机重新标定；缺失会影响实机运行，不影响代码逻辑审查。
