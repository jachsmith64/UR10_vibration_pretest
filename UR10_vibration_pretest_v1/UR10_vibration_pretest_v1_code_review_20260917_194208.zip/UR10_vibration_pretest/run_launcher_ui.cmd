@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" "launcher_ui.py"
pause
